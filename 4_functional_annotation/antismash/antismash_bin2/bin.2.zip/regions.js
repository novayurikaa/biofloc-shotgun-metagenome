var recordData = [
 {
  "length": 4242,
  "seq_id": "k39_78897",
  "regions": []
 },
 {
  "length": 3692,
  "seq_id": "k39_39752",
  "regions": []
 },
 {
  "length": 2871,
  "seq_id": "k39_98697",
  "regions": []
 },
 {
  "length": 5156,
  "seq_id": "k39_98743",
  "regions": []
 },
 {
  "length": 2650,
  "seq_id": "k39_99569",
  "regions": []
 },
 {
  "length": 13360,
  "seq_id": "k39_80298",
  "regions": []
 },
 {
  "length": 3632,
  "seq_id": "k39_80434",
  "regions": []
 },
 {
  "length": 3224,
  "seq_id": "k39_100380",
  "regions": []
 },
 {
  "length": 2726,
  "seq_id": "k39_139716",
  "regions": []
 },
 {
  "length": 5341,
  "seq_id": "k39_41708",
  "regions": []
 },
 {
  "length": 3224,
  "seq_id": "k39_3082",
  "regions": []
 },
 {
  "length": 3793,
  "seq_id": "k39_22930",
  "regions": []
 },
 {
  "length": 3232,
  "seq_id": "k39_140571",
  "regions": []
 },
 {
  "length": 7415,
  "seq_id": "k39_120910",
  "regions": []
 },
 {
  "length": 3726,
  "seq_id": "k39_62743",
  "regions": []
 },
 {
  "length": 3236,
  "seq_id": "k39_62942",
  "regions": []
 },
 {
  "length": 3175,
  "seq_id": "k39_4165",
  "regions": []
 },
 {
  "length": 3704,
  "seq_id": "k39_5547",
  "regions": []
 },
 {
  "length": 3393,
  "seq_id": "k39_104138",
  "regions": []
 },
 {
  "length": 2878,
  "seq_id": "k39_25815",
  "regions": []
 },
 {
  "length": 5472,
  "seq_id": "k39_26228",
  "regions": []
 },
 {
  "length": 5313,
  "seq_id": "k39_84969",
  "regions": []
 },
 {
  "length": 2592,
  "seq_id": "k39_104931",
  "regions": []
 },
 {
  "length": 3799,
  "seq_id": "k39_124716",
  "regions": []
 },
 {
  "length": 4812,
  "seq_id": "k39_28223",
  "regions": []
 },
 {
  "length": 2742,
  "seq_id": "k39_8903",
  "regions": []
 },
 {
  "length": 4622,
  "seq_id": "k39_9021",
  "regions": []
 },
 {
  "length": 6072,
  "seq_id": "k39_87170",
  "regions": []
 },
 {
  "length": 3167,
  "seq_id": "k39_10484",
  "regions": []
 },
 {
  "length": 2953,
  "seq_id": "k39_109233",
  "regions": []
 },
 {
  "length": 3207,
  "seq_id": "k39_149348",
  "regions": []
 },
 {
  "length": 6259,
  "seq_id": "k39_90294",
  "regions": []
 },
 {
  "length": 6004,
  "seq_id": "k39_110470",
  "regions": []
 },
 {
  "length": 5857,
  "seq_id": "k39_71395",
  "regions": []
 },
 {
  "length": 3515,
  "seq_id": "k39_52339",
  "regions": []
 },
 {
  "length": 2873,
  "seq_id": "k39_131408",
  "regions": []
 },
 {
  "length": 4154,
  "seq_id": "k39_111938",
  "regions": []
 },
 {
  "length": 3422,
  "seq_id": "k39_131472",
  "regions": []
 },
 {
  "length": 3891,
  "seq_id": "k39_92474",
  "regions": []
 },
 {
  "length": 5380,
  "seq_id": "k39_92596",
  "regions": []
 },
 {
  "length": 3047,
  "seq_id": "k39_14812",
  "regions": []
 },
 {
  "length": 3161,
  "seq_id": "k39_113009",
  "regions": []
 },
 {
  "length": 2537,
  "seq_id": "k39_113655",
  "regions": []
 },
 {
  "length": 3507,
  "seq_id": "k39_113928",
  "regions": []
 },
 {
  "length": 5937,
  "seq_id": "k39_114258",
  "regions": []
 },
 {
  "length": 3807,
  "seq_id": "k39_36380",
  "regions": []
 },
 {
  "length": 2711,
  "seq_id": "k39_115351",
  "regions": []
 },
 {
  "length": 6059,
  "seq_id": "k39_37758",
  "regions": []
 },
 {
  "length": 4958,
  "seq_id": "k39_18851",
  "regions": []
 },
 {
  "length": 3002,
  "seq_id": "k39_77577",
  "regions": []
 },
 {
  "length": 3261,
  "seq_id": "k39_38794",
  "regions": []
 }
];
var all_regions = {
 "order": []
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {};
