var recordData = [
 {
  "length": 2514,
  "seq_id": "k39_39389",
  "regions": []
 },
 {
  "length": 3170,
  "seq_id": "k39_137407",
  "regions": []
 },
 {
  "length": 2674,
  "seq_id": "k39_59380",
  "regions": []
 },
 {
  "length": 3336,
  "seq_id": "k39_79088",
  "regions": []
 },
 {
  "length": 2721,
  "seq_id": "k39_40001",
  "regions": []
 },
 {
  "length": 3061,
  "seq_id": "k39_118487",
  "regions": []
 },
 {
  "length": 2646,
  "seq_id": "k39_99006",
  "regions": []
 },
 {
  "length": 2616,
  "seq_id": "k39_60793",
  "regions": []
 },
 {
  "length": 4029,
  "seq_id": "k39_41133",
  "regions": []
 },
 {
  "length": 2581,
  "seq_id": "k39_100278",
  "regions": []
 },
 {
  "length": 3734,
  "seq_id": "k39_100699",
  "regions": []
 },
 {
  "length": 2769,
  "seq_id": "k39_61928",
  "regions": []
 },
 {
  "length": 3190,
  "seq_id": "k39_22868",
  "regions": []
 },
 {
  "length": 2942,
  "seq_id": "k39_42397",
  "regions": []
 },
 {
  "length": 2759,
  "seq_id": "k39_3614",
  "regions": []
 },
 {
  "length": 2532,
  "seq_id": "k39_23406",
  "regions": []
 },
 {
  "length": 2509,
  "seq_id": "k39_82134",
  "regions": []
 },
 {
  "length": 3206,
  "seq_id": "k39_102015",
  "regions": []
 },
 {
  "length": 3046,
  "seq_id": "k39_141262",
  "regions": []
 },
 {
  "length": 2888,
  "seq_id": "k39_82481",
  "regions": []
 },
 {
  "length": 2544,
  "seq_id": "k39_23958",
  "regions": []
 },
 {
  "length": 3102,
  "seq_id": "k39_121844",
  "regions": []
 },
 {
  "length": 2664,
  "seq_id": "k39_142016",
  "regions": []
 },
 {
  "length": 3008,
  "seq_id": "k39_83066",
  "regions": []
 },
 {
  "length": 2731,
  "seq_id": "k39_63802",
  "regions": []
 },
 {
  "length": 4118,
  "seq_id": "k39_142250",
  "regions": []
 },
 {
  "length": 3204,
  "seq_id": "k39_83345",
  "regions": []
 },
 {
  "length": 2625,
  "seq_id": "k39_142514",
  "regions": []
 },
 {
  "length": 2968,
  "seq_id": "k39_64087",
  "regions": []
 },
 {
  "length": 2745,
  "seq_id": "k39_64127",
  "regions": []
 },
 {
  "length": 3019,
  "seq_id": "k39_123193",
  "regions": []
 },
 {
  "length": 3094,
  "seq_id": "k39_44724",
  "regions": []
 },
 {
  "length": 4541,
  "seq_id": "k39_84217",
  "regions": []
 },
 {
  "length": 3313,
  "seq_id": "k39_124004",
  "regions": []
 },
 {
  "length": 2647,
  "seq_id": "k39_124123",
  "regions": []
 },
 {
  "length": 2803,
  "seq_id": "k39_65401",
  "regions": []
 },
 {
  "length": 2835,
  "seq_id": "k39_6572",
  "regions": []
 },
 {
  "length": 3902,
  "seq_id": "k39_45567",
  "regions": []
 },
 {
  "length": 2885,
  "seq_id": "k39_26404",
  "regions": []
 },
 {
  "length": 2638,
  "seq_id": "k39_104853",
  "regions": []
 },
 {
  "length": 2945,
  "seq_id": "k39_144340",
  "regions": []
 },
 {
  "length": 3461,
  "seq_id": "k39_27126",
  "regions": []
 },
 {
  "length": 3332,
  "seq_id": "k39_105814",
  "regions": []
 },
 {
  "length": 2522,
  "seq_id": "k39_27607",
  "regions": []
 },
 {
  "length": 2926,
  "seq_id": "k39_105921",
  "regions": []
 },
 {
  "length": 2527,
  "seq_id": "k39_106295",
  "regions": []
 },
 {
  "length": 4009,
  "seq_id": "k39_47259",
  "regions": []
 },
 {
  "length": 3025,
  "seq_id": "k39_67397",
  "regions": []
 },
 {
  "length": 2968,
  "seq_id": "k39_67736",
  "regions": []
 },
 {
  "length": 2521,
  "seq_id": "k39_146239",
  "regions": []
 },
 {
  "length": 3191,
  "seq_id": "k39_107163",
  "regions": []
 },
 {
  "length": 2785,
  "seq_id": "k39_88742",
  "regions": []
 },
 {
  "length": 2603,
  "seq_id": "k39_11304",
  "regions": []
 },
 {
  "length": 2642,
  "seq_id": "k39_128723",
  "regions": []
 },
 {
  "length": 2582,
  "seq_id": "k39_148709",
  "regions": []
 },
 {
  "length": 3386,
  "seq_id": "k39_149258",
  "regions": []
 },
 {
  "length": 2597,
  "seq_id": "k39_31586",
  "regions": []
 },
 {
  "length": 2955,
  "seq_id": "k39_129929",
  "regions": []
 },
 {
  "length": 2689,
  "seq_id": "k39_13065",
  "regions": []
 },
 {
  "length": 2650,
  "seq_id": "k39_72218",
  "regions": []
 },
 {
  "length": 3089,
  "seq_id": "k39_52849",
  "regions": []
 },
 {
  "length": 3516,
  "seq_id": "k39_73201",
  "regions": []
 },
 {
  "length": 2526,
  "seq_id": "k39_53585",
  "regions": []
 },
 {
  "length": 3308,
  "seq_id": "k39_153291",
  "regions": []
 },
 {
  "length": 3689,
  "seq_id": "k39_54958",
  "regions": []
 },
 {
  "length": 2970,
  "seq_id": "k39_115096",
  "regions": []
 },
 {
  "length": 3754,
  "seq_id": "k39_134858",
  "regions": []
 },
 {
  "length": 2522,
  "seq_id": "k39_135883",
  "regions": []
 }
];
var all_regions = {
 "order": []
};
var details_data = {
 "nrpspks": {}
};
var resultsData = {};
