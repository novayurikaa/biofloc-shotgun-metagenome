var recordData = [
 {
  "length": 8228,
  "seq_id": "k39_28",
  "regions": []
 },
 {
  "length": 6776,
  "seq_id": "k39_58770",
  "regions": []
 },
 {
  "length": 4759,
  "seq_id": "k39_105",
  "regions": []
 },
 {
  "length": 2820,
  "seq_id": "k39_137133",
  "regions": []
 },
 {
  "length": 3783,
  "seq_id": "k39_117",
  "regions": []
 },
 {
  "length": 7444,
  "seq_id": "k39_145",
  "regions": []
 },
 {
  "length": 13802,
  "seq_id": "k39_19826",
  "regions": []
 },
 {
  "length": 2926,
  "seq_id": "k39_185",
  "regions": []
 },
 {
  "length": 7681,
  "seq_id": "k39_98169",
  "regions": []
 },
 {
  "length": 15374,
  "seq_id": "k39_58961",
  "regions": []
 },
 {
  "length": 5479,
  "seq_id": "k39_237",
  "regions": []
 },
 {
  "length": 3040,
  "seq_id": "k39_243",
  "regions": []
 },
 {
  "length": 14200,
  "seq_id": "k39_98242",
  "regions": []
 },
 {
  "length": 15209,
  "seq_id": "k39_263",
  "regions": []
 },
 {
  "length": 2728,
  "seq_id": "k39_117824",
  "regions": []
 },
 {
  "length": 2615,
  "seq_id": "k39_59068",
  "regions": []
 },
 {
  "length": 4758,
  "seq_id": "k39_137435",
  "regions": []
 },
 {
  "length": 4163,
  "seq_id": "k39_59105",
  "regions": []
 },
 {
  "length": 10184,
  "seq_id": "k39_20023",
  "regions": []
 },
 {
  "length": 9169,
  "seq_id": "k39_20026",
  "regions": []
 },
 {
  "length": 3546,
  "seq_id": "k39_59148",
  "regions": []
 },
 {
  "length": 11250,
  "seq_id": "k39_78791",
  "regions": []
 },
 {
  "length": 6078,
  "seq_id": "k39_59174",
  "regions": []
 },
 {
  "length": 3336,
  "seq_id": "k39_137602",
  "regions": []
 },
 {
  "length": 4485,
  "seq_id": "k39_98498",
  "regions": []
 },
 {
  "length": 6823,
  "seq_id": "k39_78883",
  "regions": []
 },
 {
  "length": 5348,
  "seq_id": "k39_543",
  "regions": []
 },
 {
  "length": 5692,
  "seq_id": "k39_39721",
  "regions": []
 },
 {
  "length": 13327,
  "seq_id": "k39_98549",
  "regions": []
 },
 {
  "length": 6661,
  "seq_id": "k39_20292",
  "regions": []
 },
 {
  "length": 6760,
  "seq_id": "k39_39798",
  "regions": []
 },
 {
  "length": 12213,
  "seq_id": "k39_78970",
  "regions": []
 },
 {
  "length": 2690,
  "seq_id": "k39_39827",
  "regions": []
 },
 {
  "length": 5972,
  "seq_id": "k39_78983",
  "regions": []
 },
 {
  "length": 20605,
  "seq_id": "k39_674",
  "regions": []
 },
 {
  "length": 11386,
  "seq_id": "k39_20377",
  "regions": []
 },
 {
  "length": 4994,
  "seq_id": "k39_118337",
  "regions": []
 },
 {
  "length": 17084,
  "seq_id": "k39_39912",
  "regions": []
 },
 {
  "length": 7793,
  "seq_id": "k39_118348",
  "regions": []
 },
 {
  "length": 2616,
  "seq_id": "k39_118387",
  "regions": []
 },
 {
  "length": 9137,
  "seq_id": "k39_98829",
  "regions": []
 },
 {
  "length": 8778,
  "seq_id": "k39_39993",
  "regions": []
 },
 {
  "length": 12032,
  "seq_id": "k39_98862",
  "regions": []
 },
 {
  "length": 12828,
  "seq_id": "k39_59671",
  "regions": []
 },
 {
  "length": 3354,
  "seq_id": "k39_98882",
  "regions": []
 },
 {
  "length": 4766,
  "seq_id": "k39_59704",
  "regions": []
 },
 {
  "length": 4238,
  "seq_id": "k39_118488",
  "regions": []
 },
 {
  "length": 20073,
  "seq_id": "k39_897",
  "regions": []
 },
 {
  "length": 7060,
  "seq_id": "k39_138089",
  "regions": []
 },
 {
  "length": 2960,
  "seq_id": "k39_59724",
  "regions": []
 },
 {
  "length": 3138,
  "seq_id": "k39_118541",
  "regions": []
 },
 {
  "length": 25728,
  "seq_id": "k39_926",
  "regions": []
 },
 {
  "length": 5074,
  "seq_id": "k39_40140",
  "regions": []
 },
 {
  "length": 13780,
  "seq_id": "k39_118564",
  "regions": []
 },
 {
  "length": 5509,
  "seq_id": "k39_59819",
  "regions": []
 },
 {
  "length": 4305,
  "seq_id": "k39_79401",
  "regions": []
 },
 {
  "length": 4508,
  "seq_id": "k39_20741",
  "regions": []
 },
 {
  "length": 7592,
  "seq_id": "k39_138225",
  "regions": []
 },
 {
  "length": 2614,
  "seq_id": "k39_20815",
  "regions": []
 },
 {
  "length": 4354,
  "seq_id": "k39_59923",
  "regions": []
 },
 {
  "length": 4243,
  "seq_id": "k39_40259",
  "regions": []
 },
 {
  "length": 12095,
  "seq_id": "k39_99151",
  "regions": []
 },
 {
  "length": 7154,
  "seq_id": "k39_118714",
  "regions": []
 },
 {
  "length": 3408,
  "seq_id": "k39_99157",
  "regions": []
 },
 {
  "length": 24688,
  "seq_id": "k39_20817",
  "regions": []
 },
 {
  "length": 6569,
  "seq_id": "k39_79524",
  "regions": []
 },
 {
  "length": 9465,
  "seq_id": "k39_40299",
  "regions": []
 },
 {
  "length": 8007,
  "seq_id": "k39_79531",
  "regions": []
 },
 {
  "length": 8441,
  "seq_id": "k39_138391",
  "regions": []
 },
 {
  "length": 3446,
  "seq_id": "k39_60010",
  "regions": []
 },
 {
  "length": 19890,
  "seq_id": "k39_118763",
  "regions": []
 },
 {
  "length": 14281,
  "seq_id": "k39_20909",
  "regions": []
 },
 {
  "length": 3884,
  "seq_id": "k39_40367",
  "regions": []
 },
 {
  "length": 7802,
  "seq_id": "k39_60047",
  "regions": []
 },
 {
  "length": 3410,
  "seq_id": "k39_138457",
  "regions": []
 },
 {
  "length": 15489,
  "seq_id": "k39_138516",
  "regions": []
 },
 {
  "length": 10948,
  "seq_id": "k39_1333",
  "regions": []
 },
 {
  "length": 13748,
  "seq_id": "k39_118889",
  "regions": []
 },
 {
  "length": 7942,
  "seq_id": "k39_40485",
  "regions": []
 },
 {
  "length": 4134,
  "seq_id": "k39_21055",
  "regions": []
 },
 {
  "length": 3102,
  "seq_id": "k39_118918",
  "regions": []
 },
 {
  "length": 4668,
  "seq_id": "k39_99410",
  "regions": []
 },
 {
  "length": 20680,
  "seq_id": "k39_21081",
  "regions": []
 },
 {
  "length": 8759,
  "seq_id": "k39_60208",
  "regions": []
 },
 {
  "length": 2870,
  "seq_id": "k39_119015",
  "regions": []
 },
 {
  "length": 7507,
  "seq_id": "k39_60312",
  "regions": []
 },
 {
  "length": 9865,
  "seq_id": "k39_21174",
  "regions": []
 },
 {
  "length": 3467,
  "seq_id": "k39_138733",
  "regions": []
 },
 {
  "length": 5183,
  "seq_id": "k39_60336",
  "regions": []
 },
 {
  "length": 4775,
  "seq_id": "k39_21196",
  "regions": []
 },
 {
  "length": 3375,
  "seq_id": "k39_21205",
  "regions": []
 },
 {
  "length": 3071,
  "seq_id": "k39_21223",
  "regions": []
 },
 {
  "length": 7431,
  "seq_id": "k39_21243",
  "regions": []
 },
 {
  "length": 4360,
  "seq_id": "k39_60420",
  "regions": []
 },
 {
  "length": 3537,
  "seq_id": "k39_138816",
  "regions": []
 },
 {
  "length": 3174,
  "seq_id": "k39_99673",
  "regions": []
 },
 {
  "length": 5750,
  "seq_id": "k39_40818",
  "regions": []
 },
 {
  "length": 6816,
  "seq_id": "k39_21334",
  "regions": []
 },
 {
  "length": 9551,
  "seq_id": "k39_80099",
  "regions": []
 },
 {
  "length": 10115,
  "seq_id": "k39_60553",
  "regions": []
 },
 {
  "length": 11511,
  "seq_id": "k39_80116",
  "regions": []
 },
 {
  "length": 13460,
  "seq_id": "k39_119331",
  "regions": []
 },
 {
  "length": 4152,
  "seq_id": "k39_40922",
  "regions": []
 },
 {
  "length": 5868,
  "seq_id": "k39_21411",
  "regions": []
 },
 {
  "length": 2877,
  "seq_id": "k39_99853",
  "regions": []
 },
 {
  "length": 6317,
  "seq_id": "k39_80155",
  "regions": []
 },
 {
  "length": 12475,
  "seq_id": "k39_1810",
  "regions": []
 },
 {
  "length": 3056,
  "seq_id": "k39_1812",
  "regions": []
 },
 {
  "length": 6226,
  "seq_id": "k39_99911",
  "regions": []
 },
 {
  "length": 5205,
  "seq_id": "k39_99936",
  "regions": []
 },
 {
  "length": 4694,
  "seq_id": "k39_1834",
  "regions": []
 },
 {
  "length": 4015,
  "seq_id": "k39_41029",
  "regions": []
 },
 {
  "length": 7291,
  "seq_id": "k39_41083",
  "regions": []
 },
 {
  "length": 12704,
  "seq_id": "k39_1916",
  "regions": []
 },
 {
  "length": 7959,
  "seq_id": "k39_80339",
  "regions": []
 },
 {
  "length": 3915,
  "seq_id": "k39_100100",
  "regions": []
 },
 {
  "length": 14368,
  "seq_id": "k39_60817",
  "regions": []
 },
 {
  "length": 9679,
  "seq_id": "k39_119574",
  "regions": []
 },
 {
  "length": 6009,
  "seq_id": "k39_21653",
  "regions": []
 },
 {
  "length": 3884,
  "seq_id": "k39_1955",
  "regions": []
 },
 {
  "length": 2670,
  "seq_id": "k39_119588",
  "regions": []
 },
 {
  "length": 21903,
  "seq_id": "k39_21656",
  "regions": []
 },
 {
  "length": 3547,
  "seq_id": "k39_60850",
  "regions": []
 },
 {
  "length": 7365,
  "seq_id": "k39_1974",
  "regions": []
 },
 {
  "length": 5533,
  "seq_id": "k39_80407",
  "regions": []
 },
 {
  "length": 9856,
  "seq_id": "k39_60870",
  "regions": []
 },
 {
  "length": 11332,
  "seq_id": "k39_2017",
  "regions": []
 },
 {
  "length": 6643,
  "seq_id": "k39_21713",
  "regions": []
 },
 {
  "length": 7925,
  "seq_id": "k39_100219",
  "regions": []
 },
 {
  "length": 3326,
  "seq_id": "k39_2051",
  "regions": []
 },
 {
  "length": 10367,
  "seq_id": "k39_80502",
  "regions": []
 },
 {
  "length": 25044,
  "seq_id": "k39_41272",
  "regions": []
 },
 {
  "length": 5838,
  "seq_id": "k39_80503",
  "regions": []
 },
 {
  "length": 18652,
  "seq_id": "k39_119745",
  "regions": []
 },
 {
  "length": 2956,
  "seq_id": "k39_61048",
  "regions": []
 },
 {
  "length": 3520,
  "seq_id": "k39_80589",
  "regions": []
 },
 {
  "length": 4273,
  "seq_id": "k39_100385",
  "regions": []
 },
 {
  "length": 9244,
  "seq_id": "k39_2213",
  "regions": []
 },
 {
  "length": 15728,
  "seq_id": "k39_2254",
  "regions": []
 },
 {
  "length": 3066,
  "seq_id": "k39_119947",
  "regions": []
 },
 {
  "length": 18565,
  "seq_id": "k39_61226",
  "regions": []
 },
 {
  "length": 4150,
  "seq_id": "k39_61302",
  "regions": []
 },
 {
  "length": 8191,
  "seq_id": "k39_80860",
  "regions": []
 },
 {
  "length": 7031,
  "seq_id": "k39_2456",
  "regions": [
   {
    "start": 1,
    "end": 7031,
    "idx": 1,
    "orfs": [
     {
      "start": 82,
      "end": 1089,
      "strand": -1,
      "locus_tag": "ctg144_1",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg144_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg144_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 82 - 1,089,\n (total: 1008 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg144_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg144_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCTTCCGGCGGTGAATCAGGCTGTCGAAGACTACGTCCGAACCCTTTGAATTCTTCGGGCCAGCAATTGATCAGTTCGTGCCTCGAAGCCCTGGAGCGCGGCGCTCGATGGCTCTCGGCCAATCAACGGAAGGATGGATCCTTTTCCAGCACCATCCATAGATCCGCTCGCCTCGAAGACCCGGGCCAGGAAGAATTCGCCGTGTTTCCGACGTTGCTGATACTCCGCTCCCTTCGGCGGCTGCCGGGGTTTCAGGTCCTGCGTGAGCGCGCGGGTGCCTTCGTATTGGGTGCGAAACGACCAGGGGGCACGTGGAGTTACTGGTACCGGGATCCTCCGTTCCACGTGCCTCCGGACGTTGATGATACGGCCCTGGCGCTGACAGTCACACGTGACCTGCTGACGCCGGCACAACGAGCGGAAATAGTTGTTCGGCTTGCTCAGAACCGCGACGACTGCGGCCTGTTTTGGACATGGTTCGATGTCCCAGAGCACAATGATACCGACCTGGTGGTCAACGTGAACGTGATCGGTGCGCTGGGCGAGGGATCGTTCACGGACGCTGCGATTCGGTTGATTCAGGCCCGACTTGGGTGCGATCCAGACGGGTGCACTTACTATTACCCAACAAAGAGCGCGCTCGCCTATGCCCTGGCTTGGGCGGTCGACGAGGGGGTGACTGCGCTAGTGGACCCAGGAGAACGACTTCAATCTGGGTTGGTTTCGAGCTGGAAGTGCTTGTCCGATGAGGACCTGGCGCAAAGCCTGGCAGCCGGCGCTCATCTGGGGCTGGGCGCCCATGGCGAGTGGCGCCAGGGTTTGGCCAGGTTGTTGCGGCTGCAAGGTGAGGATGGCGGTTGGCCAGCGGTTGTTTTTGCCCTGGGACCCAGGCCCCCTGAAGAACCTGAGCACTGGTACGCCTCAGACAGTGTCCATACGGCTTTGGCCCTCGAAGCGATTCACGGTTGTCTTCCGCTTTTGGAAGGCCCGAAATCGTTGACATAA",
      "translation": "MPSGGESGCRRLRPNPLNSSGQQLISSCLEALERGARWLSANQRKDGSFSSTIHRSARLEDPGQEEFAVFPTLLILRSLRRLPGFQVLRERAGAFVLGAKRPGGTWSYWYRDPPFHVPPDVDDTALALTVTRDLLTPAQRAEIVVRLAQNRDDCGLFWTWFDVPEHNDTDLVVNVNVIGALGEGSFTDAAIRLIQARLGCDPDGCTYYYPTKSALAYALAWAVDEGVTALVDPGERLQSGLVSSWKCLSDEDLAQSLAAGAHLGLGAHGEWRQGLARLLRLQGEDGGWPAVVFALGPRPPEEPEHWYASDSVHTALALEAIHGCLPLLEGPKSLT",
      "product": ""
     },
     {
      "start": 1038,
      "end": 1952,
      "strand": -1,
      "locus_tag": "ctg144_2",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg144_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg144_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,038 - 1,952,\n (total: 915 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg144_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg144_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCTGAGGAGTGCCCCGCCGGATCTTACCGTGCCATTTGCTATGGTGTGCCCGTCATATCGGACGTGCCATTGACGGTCTTGGGCGGCGCGAAAAGCGAATTGCAGGCGCCTTGCCGCATTGTCATTGAAAGATCCTCACCTCCTTCGATGCGGACGGGACAGGCACTGATCGAACTCGAGATTCAGGGCCGAAAAGTGTCATCCCGGTTCGCCCCCGACCATGATGACGAGACACATCGCGGCGTCTGGAGGGCGTTCGTCGAGAACGTTGCACGATTCGAATGGCGAGAAGGCCCCGACGAACCCTTGCGCATCTGGAGGGAAGGGGCATCAGACGAAATCCTGGCGTTCTGGGTGGTCCATCTGCTCCTTCCCGCTTACCTGTCCTGCAACCGGGGAATCAGTATCCTGCACGCATCCGCAGTCGAGGTGGAGGGTGGCTGCGTGGCGTTTCTCGGCCCCTCGTTCAGCGGCAAGTCCACGTTGCTGGCCAGTTTCCTGAGTCGCGGTTTTGCGTTGTATTGCGATGACAAACTCGCAATTCGCCAGGTGGGGGACGGGATTCGAGCGTTTGCGGCGCACGGTCGCTATCGACCTTACCGCGCCAACGAATCCCTGGGCCGTTGCCAGGCCCGGCGGGTCGCCGACCCGGGACCGGTTCGTGCCCTTTTGGCCCTCGAGCGGATTGCAGGCCTGGAGAAGCCGGAGATAACGCCGGTTTCAGGCGCTGACGCATTTCGACGCCTGATCGCCGACCACCACATGGGATTCTGGCAATCGCGGGCTGAAAATTTTCAGGCTGTCTCGCACCTGTCCCGCACCGTACCTCTGGCTACCCTGGCAATTCCAGATGACCTGCGATGCCTTCCGGCGGTGAATCAGGCTGTCGAAGACTACGTCCGAACCCTTTGA",
      "translation": "MSEECPAGSYRAICYGVPVISDVPLTVLGGAKSELQAPCRIVIERSSPPSMRTGQALIELEIQGRKVSSRFAPDHDDETHRGVWRAFVENVARFEWREGPDEPLRIWREGASDEILAFWVVHLLLPAYLSCNRGISILHASAVEVEGGCVAFLGPSFSGKSTLLASFLSRGFALYCDDKLAIRQVGDGIRAFAAHGRYRPYRANESLGRCQARRVADPGPVRALLALERIAGLEKPEITPVSGADAFRRLIADHHMGFWQSRAENFQAVSHLSRTVPLATLAIPDDLRCLPAVNQAVEDYVRTL",
      "product": ""
     },
     {
      "start": 2044,
      "end": 2559,
      "strand": 1,
      "locus_tag": "ctg144_3",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg144_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg144_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,044 - 2,559,\n (total: 516 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) lassopeptide: PF13471<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg144_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg144_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGCTGTGTGCCCTTGACCTTGCAACTGACATCGAATTTGCCGTGAATCAACCCGAAAGGACCTTACGCATCCGGATCGCCACGGATTCCCAGCCACGAGTCCACCGTGGCAAGCGGTTCGCTGCAAAAAGCCTGTTGGCCCTGGTCAGCCTGGCGATCAGCCTGGTGGGCGTGCAGCGAACCCACCGCTGCCTGACGATTCTGGCAGCACCCGCCCATCGGGCCCGGGTCGGCAAGAGCAATCCGGAACAGGCGCTTCTGCATGCTGATCTATGGCGGCAAATTCTGGAATCGGAAGCGGCCGCCCTGCCCTTCAGGGCCGAATGCAGTGAAATCTCCCTGAGCCTCCATGCACTGATGCTGCTCGGGGGCCATCGGGGCGAGGTCGTCATCGGCCATCGCTTGCTGCAGGACAACGTGCAGGGACACACCTGGCTGATGCTGGAGGGACAGGTTGTCTCGGAGCTCGGCGAACCGGACAAGGCCTATCCCATTTTGCATGTTCGCTTGAGGTGA",
      "translation": "MLCALDLATDIEFAVNQPERTLRIRIATDSQPRVHRGKRFAAKSLLALVSLAISLVGVQRTHRCLTILAAPAHRARVGKSNPEQALLHADLWRQILESEAAALPFRAECSEISLSLHALMLLGGHRGEVVIGHRLLQDNVQGHTWLMLEGQVVSELGEPDKAYPILHVRLR",
      "product": ""
     },
     {
      "start": 2585,
      "end": 4348,
      "strand": 1,
      "locus_tag": "ctg144_4",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg144_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg144_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,585 - 4,348,\n (total: 1764 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) lassopeptide: Asn_synthase<br>\n \n  biosynthetic-additional (rule-based-clusters) GATase_7<br>\n \n  biosynthetic-additional (smcogs) SMCOG1177:asparagine synthase (glutamine-hydrolyzing) (Score: 232.3; E-value: 1.9e-70)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg144_4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg144_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGTGGCTTGTTTGCCGTCTTCAATCGATCCGGTGCACCCGTCAACGAAGCGGACCTGGCCCGGGCACTCGGGCGCATGTCTGTCAGGGGTCGCGACGACTCACGTATGTGGCACCAGTCCAATGCAGGCCTGGCCGCGGCTGTAACGTTCTGGTCCAGTGAAGAAAAACCTTGCGACCTGCCCTCCACGCTGGACGGGTCATGCCATGTCATTGCCGCAGCATTGCTCAGCAACCGCCCGGAACTGCGCCGGCAGTTGCACGGCGCCGGCCACGCAACCACCCCGGAAACCTCCGACGCGGAACTGATTCTCCGCAGTTACACCGCCTGGGGTGAACGTTGCACGGAGCATCTTCGCGGAGAATTCGCTGCCGTCGTGTGGGACCCGGCCCGCCAGAAACTGCTGGGGTTCGTGGACCATTTTGGCACCCTGCCCCTGTTCTATACCGATACATCGGAGATGGCGGTGCTGAGTACGGATCTCGAAGCCATCGCCACTTTTCGCGGTGTCGATCGCACATTGAGTCCTGAGGCCATCGTCGACACGCTGATATACGGGTTTCAACAATCCCGATCCAGCACGATTTACGAGCATATTCATCGTTTGCCGGGCGGGCACCTGCTGGAGGTAGCGCCGGAAAAAGCCCGTAGAAGCGTGTACTGGACGCCCGACGAATGGTCTCCCCTGAGAAACGTCAGCGACCCACAATCCCTGGTGGACGAATTTCATGCACATCTCGAAAGGGCTGTGCTCGCGAGGGCCCGACTCCCGAACCTTGGCGTCGAGTTGTCCGGTGGACTGGACACTTCCAGCATCGCCCAGGTTCTGAGCGAGGATGCCCGGAATCGCCGACCTCAGCGCCACCTAAGGGCGTTTTGCCATGGATTTTCGGGCCCGGCCGGAGAAGCAGAACCCGCCCTCGCTCGCCAGACTGCCGACCACCTCGGCCTGGACCTGGAAGTGCTCTGGCAGGACCGAGGTCACCCATTGGGCACCACGAAGCCGAGCCACTTTCCCCCTGAACCCCAGGGCTTTCTGTGGGATGCGGGATTGCTGCATGGGCGCAATGCGGCGGCTCATTCGCCCATCCTGTTCTCAGGTCACGGCGGCGACATGATTCTGGGGTACGTGGAATACCACTGGATGCGCCAACTGCGCCGGCGGCCAATGGGCGCGTTTCGAGACCTTCTGACGTTTTTCAGGATGTACGGCTTCAAGCGACCGCCACTCGGGCTACGCAATTGGGTCAGGAAGTGGCAGGGAGCCAACGAATCAAACATGCCTGTGCCCACCTGGCTCCGCCAGGACCTGGTGGACCGGGTCGCCCCCCTCGACCGGGTTACGCATATCGAGACAAGAAGCGAATCCTTCCGCCAACGGCTGGGAATGTGGCACAGCCCCGTGTCCTCGATGATTTTTTCCCGAACCGATGCCGCCTACTACGACGCGCCCATTCGTTGCGTTTATCCCTATTTCGATTTCGATTTGTGGGAGTTTCTGCAATCAGTGCCACCAATACCCTACTTCGTGAAGAAGGCCCTGCTGCGGGTCGACATGAAGCATCGTCTCCCAACCGCTGTCGTCACTCGACCAAAGGTTCACCTGGCAGATGCCAGCCATCCGATCCTGGAGACCATGCAAGCCTCGGGCGTCCCCACCTGGTATTTCGAGCAACTCGAAAGTCCTTGCCTGGATCCCTACGTCGATGGCCGGAGCGTGGCTCGGCGCCGGGAACAGATCGAACGAGTCGGTAAAGCCTAA",
      "translation": "MSGLFAVFNRSGAPVNEADLARALGRMSVRGRDDSRMWHQSNAGLAAAVTFWSSEEKPCDLPSTLDGSCHVIAAALLSNRPELRRQLHGAGHATTPETSDAELILRSYTAWGERCTEHLRGEFAAVVWDPARQKLLGFVDHFGTLPLFYTDTSEMAVLSTDLEAIATFRGVDRTLSPEAIVDTLIYGFQQSRSSTIYEHIHRLPGGHLLEVAPEKARRSVYWTPDEWSPLRNVSDPQSLVDEFHAHLERAVLARARLPNLGVELSGGLDTSSIAQVLSEDARNRRPQRHLRAFCHGFSGPAGEAEPALARQTADHLGLDLEVLWQDRGHPLGTTKPSHFPPEPQGFLWDAGLLHGRNAAAHSPILFSGHGGDMILGYVEYHWMRQLRRRPMGAFRDLLTFFRMYGFKRPPLGLRNWVRKWQGANESNMPVPTWLRQDLVDRVAPLDRVTHIETRSESFRQRLGMWHSPVSSMIFSRTDAAYYDAPIRCVYPYFDFDLWEFLQSVPPIPYFVKKALLRVDMKHRLPTAVVTRPKVHLADASHPILETMQASGVPTWYFEQLESPCLDPYVDGRSVARRREQIERVGKA",
      "product": ""
     },
     {
      "start": 4484,
      "end": 4669,
      "strand": 1,
      "locus_tag": "ctg144_5",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg144_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg144_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,484 - 4,669,\n (total: 186 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg144_5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg144_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGAAAAAGTTCGGTCCAAATCTGGACGGTCAGACAACTCGGCGGAGTGCAATTCCGCCACGCCCGCCTACGTGAAGCCGAAACTCCATGACTTCGGAAAAATGCAGGACATCGTGCACACTGGACAGGACAGCTTCATGGACGATACCGGGATGTACGAAGGCACTGTTGGTACGATGAGCTGA",
      "translation": "MEKVRSKSGRSDNSAECNSATPAYVKPKLHDFGKMQDIVHTGQDSFMDDTGMYEGTVGTMS",
      "product": ""
     },
     {
      "start": 4709,
      "end": 6052,
      "strand": 1,
      "locus_tag": "ctg144_6",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg144_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg144_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,709 - 6,052,\n (total: 1344 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg144_6\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg144_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCCGGGCCGGCCTCCCTGGCCGGTTTGCTCCTTAGCCAATCTCACACGCATCCGGTCCCAAAAGTCATCACGCAAGCCCTTTGCGGTCATCAACGACTGTTCGATGCCTTTACGCTGGCCGGATTCGAGTGTGATCTAGGCCAGGCCAATAGATTTGACTTCCAGGTTGCGGCATTCAACCGGGACCGTGAATACGCCAGGCTGCTGGCGCAACTCGGTTCGCTTCAGTCCGACTGCCAGGGAGCAGAAGCGGACCTAGCTGGCGCCTTGCGGCTCTCGCTCAAACAAGTCATGGCACCGGATGACTGTTTTGGAACGCCGCACAGCCTTTGGCTGGAGTTCGACCTGGTCGATCCCGGCTCACTGGGTCGTGGTCCTTCACTGTTCCTGGCACTGGCCCATCCCGCCACGTCAGAACAGGCCGTCCAGTTCACCGACTACCTGGCAAGGCTCACCTCAGCGGCAGGTTCGGTGAAACTACCGGGCGGGTTGCAAAATCTTCTGGAACTCCTGGGGCCGGGTGACTCCATCAGTCATGTGGGCTGGATGTTGGGCCGGGCGACACCCAGCTTGCGACTGGTGGTTCGCGTTGCAGACGGCACCAATCCGCTCGATGTCGGCTCTCGCTTGCCGGGCGAGCGACGACCCGGCGCCTGGGCGCCCCTGCTGGCTGAGCTGTCAGATGACCTGCAATTCAACCGACTCTGTATTGACGTATTCCCTGACCGGTTTGAAATCAATGGCATAGAGTGCTTTCCCCTCAGCGGACACCAGCGAAGCGCTGCCCTCGCCGGCATTCTCTCCAGGCTCGAGCGCAATGAGGTCTGCACACCCGAGCACCGGAATCGGCTGCAGGACTGGGAGGGTTGCCATTTTCCCCGCCCGGATGAGACGTGGCCATTGGCGATGATCTGGCCCGGCCTGACAAAGCCCGCGAATGAGTTCACGGTATTCCAGAGAAGCGTCAGTCACTTCAAGGTGATGGGACGCACCTCCGGGGAACCCTTGGTCAAGGCCTACTGGGGGGGCGAGCTGACTTATTGGTCACTCGGGTCCAGTAACGTCCTGCCAAACGAAGGGGCCATCGAGGCAGAGCGCGGCCACACTTCGCAACTGCAGCACATGCTTGATTTTGTCCGGGCGTGCCGAAACGACGACGCCCTCAGAACGAGCCTTGAATCGGAATTGAACCCGAGCCTCGAGAGGCTCACAGAAGCGGGGCGTCAGTTCGGGTTTCGCGTGGAACCCAGATCATTCCACCAGGCCTTCGCCATCGACTGGCAAATGCGGTGGCGGCAGCTACACGAAGTGGGCGCCTTACCGGTTGAAACAACTGGTTAA",
      "translation": "MPGPASLAGLLLSQSHTHPVPKVITQALCGHQRLFDAFTLAGFECDLGQANRFDFQVAAFNRDREYARLLAQLGSLQSDCQGAEADLAGALRLSLKQVMAPDDCFGTPHSLWLEFDLVDPGSLGRGPSLFLALAHPATSEQAVQFTDYLARLTSAAGSVKLPGGLQNLLELLGPGDSISHVGWMLGRATPSLRLVVRVADGTNPLDVGSRLPGERRPGAWAPLLAELSDDLQFNRLCIDVFPDRFEINGIECFPLSGHQRSAALAGILSRLERNEVCTPEHRNRLQDWEGCHFPRPDETWPLAMIWPGLTKPANEFTVFQRSVSHFKVMGRTSGEPLVKAYWGGELTYWSLGSSNVLPNEGAIEAERGHTSQLQHMLDFVRACRNDDALRTSLESELNPSLERLTEAGRQFGFRVEPRSFHQAFAIDWQMRWRQLHEVGALPVETTG",
      "product": ""
     },
     {
      "start": 6056,
      "end": 7030,
      "strand": 1,
      "locus_tag": "ctg144_7",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg144_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg144_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,056 - 7,030,\n (total: 975 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) NTP_transf_5<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg144_7\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg144_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGCGGCGCTCGAAACGTCTGATCAATACTCTGGCGACGACGATCACCGGGGCCAGGGCCAACGTTGCGGGCATCAACGTCAGCCAATTGGTCGATCTGGCGGTCAGTCACGGCGTTCATGGGCTTCTCAACGAGGCGTCGACCCAGGGGCGGATCGACGGTCTGCCTCAACCCGAATGCCAACGGTTACATCGCCTCGCCCTGGCGGAGGCAGCAGCCGACCTGACGCAGGTGGCGGCCTTGCGGGAATTGCTCAGTTCGTTCGAGACAGAAGGCTTTCGTCCCTTGTTGCTCAAGGGTCTTCCCGTCGCGGCGCTTCACTATCCTAAGCGCCACTTGCGCCACCGGACCGACGTGGACCTGTATCTGTCACCGGGACACTCCACAAACGCGGCTCAGGTCCTTCACTCCCTGGGGTACCGAGTCTACGGGGTCAGCCGGCAAAACCCGACGGTGCACCAGTTCCACGCATCGCGGGGCGAAAGCTCACCCATACCCATTCATTTCGACTTGCACTGGGGCATCAGCAACCGCGCGTTGTTCCGGTCTGTCCTGCCATTCGACGCCGTGGCGCCAAACGCACAATCCATTTCCGATCTGGACCCGGCCGCCCTCACCCTGTCCAATCCGCACCTGTTGATTCATGCTTGCGTGCACCGAATCGCCCATGGCAGGAACTCGCAGAGAGACCGTCTGGTGTGGTTGAACGACATCCGCCTGATCCTGGCCAGCCTGGATGACCAGGAACGAGGGCGCTTCGTCGACGACGCGCTGGCTTGGAAGGTGGGCGCCGTTTGTGCCGACGGTATTGCCTCGATGAGCGCCGCGTTCCAGCAAGTGCCCGATGCGGGCCTTTGTACCGCCTTGACCGCTCGACAGGCGCTGGAGCCCAGCGCCAAGCTGAGCCGGGCCGGGCGATGGCGGTGGATGCTGTCGGACGTGGCGGCAGAACCCGGCCTGCCGGCCCAGTGG",
      "translation": "MKRRSKRLINTLATTITGARANVAGINVSQLVDLAVSHGVHGLLNEASTQGRIDGLPQPECQRLHRLALAEAAADLTQVAALRELLSSFETEGFRPLLLKGLPVAALHYPKRHLRHRTDVDLYLSPGHSTNAAQVLHSLGYRVYGVSRQNPTVHQFHASRGESSPIPIHFDLHWGISNRALFRSVLPFDAVAPNAQSISDLDPAALTLSNPHLLIHACVHRIAHGRNSQRDRLVWLNDIRLILASLDDQERGRFVDDALAWKVGAVCADGIASMSAAFQQVPDAGLCTALTARQALEPSAKLSRAGRWRWMLSDVAAEPGLPAQW",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 2043,
      "end": 4348,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 7031,
      "product": "lassopeptide",
      "category": "RiPP",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "lassopeptide",
    "products": [
     "lassopeptide"
    ],
    "product_categories": [
     "RiPP"
    ],
    "cssClass": "RiPP lassopeptide",
    "anchor": "r144c1"
   }
  ]
 },
 {
  "length": 2839,
  "seq_id": "k39_120152",
  "regions": []
 },
 {
  "length": 12120,
  "seq_id": "k39_2519",
  "regions": []
 },
 {
  "length": 3534,
  "seq_id": "k39_80958",
  "regions": []
 },
 {
  "length": 3647,
  "seq_id": "k39_2543",
  "regions": []
 },
 {
  "length": 6571,
  "seq_id": "k39_120228",
  "regions": []
 },
 {
  "length": 3611,
  "seq_id": "k39_120281",
  "regions": []
 },
 {
  "length": 2836,
  "seq_id": "k39_2633",
  "regions": []
 },
 {
  "length": 18957,
  "seq_id": "k39_120298",
  "regions": []
 },
 {
  "length": 3426,
  "seq_id": "k39_41911",
  "regions": []
 },
 {
  "length": 10160,
  "seq_id": "k39_22471",
  "regions": []
 },
 {
  "length": 6365,
  "seq_id": "k39_140107",
  "regions": []
 },
 {
  "length": 7033,
  "seq_id": "k39_22511",
  "regions": []
 },
 {
  "length": 6040,
  "seq_id": "k39_100981",
  "regions": []
 },
 {
  "length": 6456,
  "seq_id": "k39_140134",
  "regions": []
 },
 {
  "length": 6224,
  "seq_id": "k39_120440",
  "regions": []
 },
 {
  "length": 3673,
  "seq_id": "k39_22662",
  "regions": []
 },
 {
  "length": 2575,
  "seq_id": "k39_81273",
  "regions": []
 },
 {
  "length": 6941,
  "seq_id": "k39_120532",
  "regions": []
 },
 {
  "length": 6674,
  "seq_id": "k39_22704",
  "regions": []
 },
 {
  "length": 3686,
  "seq_id": "k39_101131",
  "regions": []
 },
 {
  "length": 11653,
  "seq_id": "k39_2890",
  "regions": []
 },
 {
  "length": 2943,
  "seq_id": "k39_22745",
  "regions": []
 },
 {
  "length": 9165,
  "seq_id": "k39_101217",
  "regions": []
 },
 {
  "length": 3504,
  "seq_id": "k39_120729",
  "regions": []
 },
 {
  "length": 7863,
  "seq_id": "k39_61989",
  "regions": []
 },
 {
  "length": 5466,
  "seq_id": "k39_22897",
  "regions": [
   {
    "start": 1,
    "end": 5466,
    "idx": 1,
    "orfs": [
     {
      "start": 69,
      "end": 491,
      "strand": 1,
      "locus_tag": "ctg170_1",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg170_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg170_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 69 - 491,\n (total: 423 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg170_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg170_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAACCGGTCCCGAATCGTCCTGCACGCCCTCGCCATTGCCGCCGTCCTCAACCTGGCCGCCCTGGCCACCCCGGACAGCGCCGCCTGGGCCGGCAAGCCGATCCAGGACATCAAGGATGTGTCGATTCCCGCCGGCATGGACATGAAGGCCATCGGCGACGCCATCATCGACGGCTGCGCCGTGCGCAGCTGGATTGCCGAGGAAGTGGGCCCCGGGCACATGCAGTGCACCGTCTACGTCCGTTCCCACATGGCCAAGGTCAACATCAACTACGACACGTCCTCGTACTCCATCACCTACGCCGACAGCGAGGAGCTGGACTACGACGCCGGTGATTACGAGATTCACCGAAACTACAACAGCTGGGTCCAGAACCTGAACGGCGACATCCGCACGGCGCTGCTGCGCGCCTCGCGCTGA",
      "translation": "MNRSRIVLHALAIAAVLNLAALATPDSAAWAGKPIQDIKDVSIPAGMDMKAIGDAIIDGCAVRSWIAEEVGPGHMQCTVYVRSHMAKVNINYDTSSYSITYADSEELDYDAGDYEIHRNYNSWVQNLNGDIRTALLRASR",
      "product": ""
     },
     {
      "start": 529,
      "end": 1110,
      "strand": 1,
      "locus_tag": "ctg170_2",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg170_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg170_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 529 - 1,110,\n (total: 582 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg170_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg170_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGACGCCACCGCCGGCCGGTACGCTGCCCCCACCCCGGCTCGAAACCCTTTCCGCCGACGGCCGCCCCCTGGCGCAGTGGGGCCTGCTGGCCGCCGGCGCCCACGACACTTCCGTGATGGCGGAGGCCCTCGATGCCCGCGACCGGCAGCGCGCCGACGGGTTTTCGAACCCGGAACGGCGTTCTGAGTACATCGCCTCGCGGTGGCTGCTGGGGCGGCTGCAGGTCCAGGGCCCGTCCTCCCTGAGCCACTGCCGCCGCTGGCTGGCGGCCGCGGCCACCCCCTGGGCGGCGATCGGTGTCGACGTCGAATGCCGCCTGCCGCGAGCGGTGGACGAGGTCGCGGAACGACTGGGGTGGGAAGACGTCCCGAACGCCCGCTACCTGCAGGCGTGGACCCTGTGGGAAGCCTGGCGGAAACTCGAGCGGGGTTCGGTGCTGGACGCGCCGGACCTGCCCTATGCACTCGCCCTGCGGGAATCGGAACGCTTCTTCGACGGGCCGAGCGAAGTGTCGGGCGCCTGGTGGTTCAGTCGCGATCTGGGCGATGCCGTGCTCAGTGTCGTCGTGCGCAGGGCGTGA",
      "translation": "MTPPPAGTLPPPRLETLSADGRPLAQWGLLAAGAHDTSVMAEALDARDRQRADGFSNPERRSEYIASRWLLGRLQVQGPSSLSHCRRWLAAAATPWAAIGVDVECRLPRAVDEVAERLGWEDVPNARYLQAWTLWEAWRKLERGSVLDAPDLPYALALRESERFFDGPSEVSGAWWFSRDLGDAVLSVVVRRA",
      "product": ""
     },
     {
      "start": 1117,
      "end": 2349,
      "strand": -1,
      "locus_tag": "ctg170_3",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg170_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg170_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,117 - 2,349,\n (total: 1233 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) arylpolyene: APE_KS1<br>\n \n  biosynthetic-additional (smcogs) SMCOG1022:Beta-ketoacyl synthase (Score: 306.1; E-value: 7e-93)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg170_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg170_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAACCGACGCGTCGTGGTGACGGGCGCGGCCGGGCTCACCGGCCTGGGCGCGGACTGGCCGACCATCCGCGCCGGCCTGGAGGCAGGACGCAGCGCGGTGCGGTACTTCCCCGAGTGGGAGGAGATCCGTGGCCTGAACTGCAAACTGGGCGCGCCCGCCGCCGATTTCGAACTGCCGGAGCACTACACGCGCAAGCGCACCCGGACCATGGGCCGCAATGCGCTGATGGCGGTGCGGGCCACGGAGCTGGCGGTGGAACAGGCGGGCCTGGCCGGCCACGAGGTACTGGGCTCGGGCCGGACCGGCGTGTCCTACGGCTCATCCTCCGGCAGCACCGACGCGCTGGCCGAAATGGCCCACGTCCGGGTCTCGGACAACGCCCGCAAGGTCAACGCCACCAGCTACGTGCGCCTGATGGGCCACACGGCCGCAGCCAACATCGGCATGTTCTTCGGCCTGCGTGGCCGGGTGATCCCCACCATCAGCGCCTGCACGGCGGGCAGCCAGGGCATCGGCTATGCCTGGGAAGCCATCCGCCACGGGCTGCAGGACGTGATGCTGGCCGGCGGCAGCGAAGAACTGTGTCCCTCCCACGTGGCCGTGTTCGACGTCCTGTACGCCACCAGCACCTCGAACGACCGGCCGGAGCACACGCCGCGCCCCTTCGACGCGGACCGGAACGGGCTGGTGGTGGGCGAGGGCGCGGCGACACTGGTGCTGGAGTCGCTGGACCACGCCCGGGACAGAAACGCGCCGATTCTCGCCGAACTGACGGGATTTGCGACGAACTCTGATGGAAATCACGTGACACGTCCCGATCGCGATTCCATGGCGCGGGTCATGCGCATGGCGCTGGAGCGCGCGGACCGGGCGCCGGCGGACATCGGCTACGTGAACGCCCACGGCACCGCCACGGAAGCCGGGGACGTGGCCGAAAGCCTGGCCACGGAGCAGGTGTTCGGCAGCGACACGCCCGTGGCCTCGCTCAAGGGCTACCTGGGCCACACGCTCGGCGCCTGCGGCGCCATCGAGGCCTGGCTGAGCATGGAAATGATGCAAGCGGGATGGTTCGCGCCCAACCACAACCTGGAACGGCCGGATCCGGACTGCGGCCGGCTGGATTACCTGATGGGCGAGGCGCGCGCGTTGGGCGTGCGCGCGGTGATGAGCAACAACTTCGCCTTCGGCGGGATCAACACCTCCCTGGTGTTCGAGCGGTTCGAAGGCTGA",
      "translation": "MNRRVVVTGAAGLTGLGADWPTIRAGLEAGRSAVRYFPEWEEIRGLNCKLGAPAADFELPEHYTRKRTRTMGRNALMAVRATELAVEQAGLAGHEVLGSGRTGVSYGSSSGSTDALAEMAHVRVSDNARKVNATSYVRLMGHTAAANIGMFFGLRGRVIPTISACTAGSQGIGYAWEAIRHGLQDVMLAGGSEELCPSHVAVFDVLYATSTSNDRPEHTPRPFDADRNGLVVGEGAATLVLESLDHARDRNAPILAELTGFATNSDGNHVTRPDRDSMARVMRMALERADRAPADIGYVNAHGTATEAGDVAESLATEQVFGSDTPVASLKGYLGHTLGACGAIEAWLSMEMMQAGWFAPNHNLERPDPDCGRLDYLMGEARALGVRAVMSNNFAFGGINTSLVFERFEG",
      "product": ""
     },
     {
      "start": 2346,
      "end": 3089,
      "strand": -1,
      "locus_tag": "ctg170_4",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg170_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg170_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,346 - 3,089,\n (total: 744 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n  biosynthetic-additional (smcogs) SMCOG1001:short-chain dehydrogenase/reductase SDR (Score: 222.7; E-value: 8.7e-68)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg170_4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg170_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCGAATCTCGTCCTTCCGTCCTCGTCACCGGCTCCAGCCGCGGCATCGGCCGAGCGATCGCGCTCGACCTCGCCGCGCACGGCTACGACCCGGTGGTTCATTGCCGCGGCAGCCGTGAAGCGGCCGAGGGCGTGGCCGCCGAAGCCCGGCAGGCCGGGGCGGGAGCCCGCGTGCTGCAGTTCGACGTCTGCGACCGGGCGGCGACCCGCGCGGCGCTGGAAGCGGACGTTGCCGAACACGGCGCGTACTACGGGGTCGTGCTGAACTCGGGCATCGCGCGCGACGGCGCGTTCCCCATGCTGGGCGAGGAAGACTGGGACGCGGTACTGCGCACCAACCTGGACGGCTTCTACAACGTGCTCCATCCCCTGGTCATGCCGCTGGTGCGGGCGCGCCGGCCGGCGCGCATCGTCACCCTGTCCTCGGTCTCCGGCGTGGTCGGCAATCGCGGGCAGGTGAACTACAGCGCTTCCAAGGCCGGCATCATCGGCGCCACCAAGGCGCTGGCCACCGAGCTGGCCAGTCGCAACATCACCGTGAACTGCGTCGCCCCCGGCCTGGTCGACACCGACATGATGGAAGCCATCCCCGAGGACCTCCGTGAACGGATGATCGAGCACATTCCCCTGGGCCGCGCCGCCCGCCCGGAGGAGGTCGCCGCCGTGGTGCGCTTCCTGCTCAGCCCCGAGGCGTCCTACGTCACGCGGCAGGTCATCGGCGTGAACGGGGGCATGGCGTGA",
      "translation": "MSESRPSVLVTGSSRGIGRAIALDLAAHGYDPVVHCRGSREAAEGVAAEARQAGAGARVLQFDVCDRAATRAALEADVAEHGAYYGVVLNSGIARDGAFPMLGEEDWDAVLRTNLDGFYNVLHPLVMPLVRARRPARIVTLSSVSGVVGNRGQVNYSASKAGIIGATKALATELASRNITVNCVAPGLVDTDMMEAIPEDLRERMIEHIPLGRAARPEEVAAVVRFLLSPEASYVTRQVIGVNGGMA",
      "product": ""
     },
     {
      "start": 3086,
      "end": 3553,
      "strand": -1,
      "locus_tag": "ctg170_5",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg170_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg170_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,086 - 3,553,\n (total: 468 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg170_5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg170_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGAGCGCGAACCTGCGCGAACTCGAGGCCCTGCTGCCCCATCGCCCGCCCCTGCTGCTGCTGGAGCGCCTGGTCGAGGGTGATCCCGACCGCGCCGTGGCCGATGTCCGGGTCCGGGCCGGCGATCCCCTGGTGGAAGCCGGCCGCGGCCTGCCGGCCTGGGCGCTGGTGGAAGTGTTCGCCCAGGCGGCCGCCCTGATCGGTGGACTGTCAGCGCGCGCACGTGGCGAGGCCGTGGCCCAGGGCTTCCTGCTCGGCACCCGGCGCCTGGACTGCCCGGTCTCCCACCTGCCGGTGGGGTCGCAGTTCACGGTGGAGGCGCGCGCCGCCTTCACGGACGGTTCCGGCATGGGCGCTTACCATTGCCGCATCCGCGAACCGCAGTGGCCGGTGGAATGCACGCTGTCGGTCTACACCCCGCCCGCAGTCATGGCGACGCCGGGCGACACCGGGAACCCCGAACCATGA",
      "translation": "MSANLRELEALLPHRPPLLLLERLVEGDPDRAVADVRVRAGDPLVEAGRGLPAWALVEVFAQAAALIGGLSARARGEAVAQGFLLGTRRLDCPVSHLPVGSQFTVEARAAFTDGSGMGAYHCRIREPQWPVECTLSVYTPPAVMATPGDTGNPEP",
      "product": ""
     },
     {
      "start": 3550,
      "end": 4395,
      "strand": -1,
      "locus_tag": "ctg170_6",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg170_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg170_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,550 - 4,395,\n (total: 846 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Glycos_transf_2<br>\n \n  biosynthetic-additional (smcogs) SMCOG1123:polyprenol-monophosphomannose synthase ppm1 (Score: 64.4; E-value: 2e-19)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg170_6\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg170_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCACGCCCGGGACCGCATCCGGGCCGCCGGAAACCCCGTCCCGGCCACCGGGAACCCCGCCCGGGCCACCGGAAACAAGCTTCCGGCCGGCCTTGCTGGTGCCGCACTACGATCACCTGGAGCAGTTCGAGCGCTTCCTGCCGAAATTGATGGCCACGGAGGTGCCCTTGCTGGTGGTGGACGACGGCAGCCCGGCCGAGCAGCGCGAACGCCTGTCCGCCCTGGCGGCTTCAGCCGGTTTCGAGCTGCTGGAGCGGCCGGAGAACCGGGGCAAGGGCGACGCCCTGCTGGCCGGCTTCGCCTGGGCCGACCGCCTGGGGTACACCCATGCCCTGCAGATGGACGCTGACGGCCAGCACGACACCGGCGACGTGGCGCGCTTCCTGGACTGCGCGCGCGAACGGCCCCGCACCCTGGTCTGCGGCGCGCCGGTGTTCGGCAAGGACGCCCCCTGGATCCGTGTCTGGGGCCGCAAGCTCACGGACTTCGTCGTCGCGCTGGAAACCTGGTCCTTCGGCGTGCGGGACGCGCTTTGCGGCTTCCGCGTCTATCCCCTGGCGGGCACGCTGGAAATCATCGCCCGGGACCGTCCCGGTGAGCGCATGGACTTCGACGCCGACATGCTGGTGCTGGCGCGCTGGCACGGCATGGACCTGCACTTCCTGGACACGAAGGTGGCCTACCCCGAGCAGGGCCGCTCCCATTTCCGCTACGTCCGCGACAACCTGCGCATGGTGGGCCTGCATGTCCGCCTGCTGCTGCGCATGTTGCTGCGCATCCCGGTGGCCGTCACCGACCGGCTGACCGGGCGCATGGGCCGTGTCACGGGGGAGCCGCGTTGA",
      "translation": "MSTPGTASGPPETPSRPPGTPPGPPETSFRPALLVPHYDHLEQFERFLPKLMATEVPLLVVDDGSPAEQRERLSALAASAGFELLERPENRGKGDALLAGFAWADRLGYTHALQMDADGQHDTGDVARFLDCARERPRTLVCGAPVFGKDAPWIRVWGRKLTDFVVALETWSFGVRDALCGFRVYPLAGTLEIIARDRPGERMDFDADMLVLARWHGMDLHFLDTKVAYPEQGRSHFRYVRDNLRMVGLHVRLLLRMLLRIPVAVTDRLTGRMGRVTGEPR",
      "product": ""
     },
     {
      "start": 4392,
      "end": 4763,
      "strand": -1,
      "locus_tag": "ctg170_7",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg170_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg170_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,392 - 4,763,\n (total: 372 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg170_7\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg170_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCTGAGGCCCGGCCAGCCAACCCAACCGAACCTTCCGCTCCGCCCGTCATCGACCGGGTGCACGACGGCGACACGGCGCAGTGGCGTCTCCGGGTCGGCGGCGACTGCCCGTGGCTCGAAGGCCATTTTCCCGAACGTCCCGTCCTGCCCGGCGTGGTGCTGCTGCGCTGGGCCATCCAGGCCGCGGTTGACACCTGGCCCGAACTGGACACCGTCACGGGCGTGAGCAATCTCAAGTTCCGCAACCCGGTTCTGCCGCCGGCCGAGGTGGTCCTTCACCTGGCGTTCGACGCCTCCCGGCGCCACATCGATTTCCGCTACGCCCGGGACGGCAAGGACTGCGCCCAGGGCCGGGTGCGCTTCGCATGA",
      "translation": "MAEARPANPTEPSAPPVIDRVHDGDTAQWRLRVGGDCPWLEGHFPERPVLPGVVLLRWAIQAAVDTWPELDTVTGVSNLKFRNPVLPPAEVVLHLAFDASRRHIDFRYARDGKDCAQGRVRFA",
      "product": ""
     },
     {
      "start": 4796,
      "end": 5041,
      "strand": -1,
      "locus_tag": "ctg170_8",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg170_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg170_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,796 - 5,041,\n (total: 246 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg170_8\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg170_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGAACACCGACATCGACTCCTACCAGTACGTTCGAAACCTGCTCGTCGACCAGTTCGACGTGCCGGCGGACGCCATTCGCCCGGAGGCCCTGCTGGCCGACGACCTGGGCATCGACAGCATCGACGCCGTGGACATGATCGTGCACATGCGCGAAGTGACCGGCGAGCGCATCACGCCCGAACGCTTCCGGCAGGTGCGCACCGTGCAGGACGTGGTGGACATCGTCGATCGCGTCCTCGCCTGA",
      "translation": "MNTDIDSYQYVRNLLVDQFDVPADAIRPEALLADDLGIDSIDAVDMIVHMREVTGERITPERFRQVRTVQDVVDIVDRVLA",
      "product": ""
     },
     {
      "start": 5122,
      "end": 5466,
      "strand": -1,
      "locus_tag": "ctg170_9",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg170_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg170_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,122 - 5,466,\n (total: 345 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg170_9\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg170_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "CGCCTGCTCGAGGCGGCGGTGGAACGGCTGCAGGCAGGGGGCACCCTGGTGCTGTTTCCCCAGGGCACGCGGACGCGGCCGGGAGAAGAGCCACAGTTCCGTCGCGGGGCGGCGGTGATCGCCGCGCGGGCCGGCGCGGACCTGCTCCCGGTGCGGATCACCTGCGAGCCGCCCGTGCTGCGCAAGGGGGATCCCTGGTTCCTGGCGCCGCCGCGGCGGCCCCATTTCACGCTCGAAGCCCTGCCGCGCCTGTCGCCGGAACGGTGGACGGCAGAGGGGGAGCGTGCCGGCACCGTGCGGCTGACGGAAAGGCTTAGTGAACTCCTGCTCGAAGCGGTACACTAG",
      "translation": "MLLEAAVERLQAGGTLVLFPQGTRTRPGEEPQFRRGAAVIAARAGADLLPVRITCEPPVLRKGDPWFLAPPRRPHFTLEALPRLSPERWTAEGERAGTVRLTERLSELLLEAVH",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 1116,
      "end": 2349,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 5466,
      "product": "arylpolyene",
      "category": "PKS",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "arylpolyene",
    "products": [
     "arylpolyene"
    ],
    "product_categories": [
     "PKS"
    ],
    "cssClass": "PKS arylpolyene",
    "anchor": "r170c1"
   }
  ]
 },
 {
  "length": 14774,
  "seq_id": "k39_101315",
  "regions": []
 },
 {
  "length": 7182,
  "seq_id": "k39_62029",
  "regions": []
 },
 {
  "length": 8252,
  "seq_id": "k39_42431",
  "regions": []
 },
 {
  "length": 7684,
  "seq_id": "k39_101348",
  "regions": []
 },
 {
  "length": 3375,
  "seq_id": "k39_42514",
  "regions": []
 },
 {
  "length": 8493,
  "seq_id": "k39_120881",
  "regions": []
 },
 {
  "length": 5029,
  "seq_id": "k39_81680",
  "regions": []
 },
 {
  "length": 3577,
  "seq_id": "k39_62187",
  "regions": []
 },
 {
  "length": 14759,
  "seq_id": "k39_101500",
  "regions": []
 },
 {
  "length": 6215,
  "seq_id": "k39_81718",
  "regions": []
 },
 {
  "length": 5444,
  "seq_id": "k39_23126",
  "regions": []
 },
 {
  "length": 8142,
  "seq_id": "k39_42608",
  "regions": []
 },
 {
  "length": 3943,
  "seq_id": "k39_62250",
  "regions": []
 },
 {
  "length": 2603,
  "seq_id": "k39_101572",
  "regions": []
 },
 {
  "length": 8627,
  "seq_id": "k39_81791",
  "regions": []
 },
 {
  "length": 15713,
  "seq_id": "k39_140791",
  "regions": []
 },
 {
  "length": 3373,
  "seq_id": "k39_42737",
  "regions": []
 },
 {
  "length": 19975,
  "seq_id": "k39_42821",
  "regions": []
 },
 {
  "length": 4228,
  "seq_id": "k39_3581",
  "regions": []
 },
 {
  "length": 11331,
  "seq_id": "k39_140971",
  "regions": []
 },
 {
  "length": 23270,
  "seq_id": "k39_81998",
  "regions": []
 },
 {
  "length": 5559,
  "seq_id": "k39_42904",
  "regions": []
 },
 {
  "length": 9164,
  "seq_id": "k39_43023",
  "regions": []
 },
 {
  "length": 4874,
  "seq_id": "k39_121393",
  "regions": []
 },
 {
  "length": 8325,
  "seq_id": "k39_43038",
  "regions": []
 },
 {
  "length": 11091,
  "seq_id": "k39_23568",
  "regions": []
 },
 {
  "length": 8399,
  "seq_id": "k39_82204",
  "regions": []
 },
 {
  "length": 10957,
  "seq_id": "k39_82207",
  "regions": []
 },
 {
  "length": 4204,
  "seq_id": "k39_62773",
  "regions": []
 },
 {
  "length": 2517,
  "seq_id": "k39_23641",
  "regions": []
 },
 {
  "length": 4021,
  "seq_id": "k39_62782",
  "regions": []
 },
 {
  "length": 5653,
  "seq_id": "k39_43184",
  "regions": []
 },
 {
  "length": 8376,
  "seq_id": "k39_23741",
  "regions": [
   {
    "start": 1,
    "end": 6035,
    "idx": 1,
    "orfs": [
     {
      "start": 3,
      "end": 170,
      "strand": -1,
      "locus_tag": "ctg203_1",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg203_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg203_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3 - 170,\n (total: 168 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg203_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg203_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCTGAGCGCCTGCGAACGCTGCAGGAGCGCTTCGCCGCCCACCTCCGCGACCCGGCCGCCACCCCTGCCCCGGAGGACGCGGAAGACCGGCGCATGGCCAGCTACCAGCGCCGGTTCTCCACCAACGTGTCCAACCTCGTGGCCCGGAGTGTCCCGGTGCTGCGC",
      "translation": "MAERLRTLQERFAAHLRDPAATPAPEDAEDRRMASYQRRFSTNVSNLVARSVPVLR",
      "product": ""
     },
     {
      "start": 163,
      "end": 1035,
      "strand": -1,
      "locus_tag": "ctg203_2",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg203_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg203_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 163 - 1,035,\n (total: 873 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) RiPP-like: DUF692<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg203_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg203_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCCAACGACCTTTTCCCGTACAGGGAACGGGTCTCGGACTGAGGCGGGCCCTGCTGGGCCCGCTTCAGGATGCGGACCCCGACCGGTTGGAAGCCAGCGTCGACTTCATGGAGGTCGCGCCGGAAAACTGGATCGGCGTGGGTGGCCGCCTGGGCCATGCCCTGCGCGCCTTCACCGAACGCTTTCCCTTCGTCTGTCACGGCCTGTCGCTCTCGCTGGGCGGGCCGGCCCCGCTGGACGAAACGCTGCTGCGCCGCACACGCGCGTTCCTGGACGCGCACGACATCCGCTGCTTCACCGAGCACCTGAGCTACTGTTCCGACGCGGGGCACCTGTACGACCTCATGCCCATTCCGTTCACCCGCGAGGCGGTGGACTACGTGGCCGAGCGAATCCGCCGGACCCAGGACCTGCTCGGCCGCCGGATCGGCATCGAGAACGTGTCCTACTACGCGGCGCCCGGCGCCGAACTCAGCGAAATCGAATTCATCAACGCGGTGGTCTCCGAGGCCGACTGCGACCTGTTGCTGGACGTGAACAACATCTGGGTCAACGCCATCAACCACGGATACGACCCGGTGGAATTCCTGCGGGACCTGCCGGGCGATCGCGTGGTCTACGGCCACGTCGCCGGCCATCACGAAGAGGCGCCCGACCTGCGGGTGGACACCCACGGCGCCGCGGTGATCGATGGTGTCTGGGACCTGCTGGACGTCGCCTACGGCACCTTCGGCGCCTACCCCACCCTGCTGGAACGCGACTTCAACTTCCCGTCCGTCGATGAACTGCTGGCCGAGGTGGACCGCATCCGCCTGGCCCAGGACCGGCACGCCGCGGACTCCGCGCTGGACGCCCGGCGCCATGGCTGA",
      "translation": "MSQRPFPVQGTGLGLRRALLGPLQDADPDRLEASVDFMEVAPENWIGVGGRLGHALRAFTERFPFVCHGLSLSLGGPAPLDETLLRRTRAFLDAHDIRCFTEHLSYCSDAGHLYDLMPIPFTREAVDYVAERIRRTQDLLGRRIGIENVSYYAAPGAELSEIEFINAVVSEADCDLLLDVNNIWVNAINHGYDPVEFLRDLPGDRVVYGHVAGHHEEAPDLRVDTHGAAVIDGVWDLLDVAYGTFGAYPTLLERDFNFPSVDELLAEVDRIRLAQDRHAADSALDARRHG",
      "product": ""
     },
     {
      "start": 1072,
      "end": 1350,
      "strand": -1,
      "locus_tag": "ctg203_3",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg203_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg203_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,072 - 1,350,\n (total: 279 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg203_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg203_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCTGACAAGACCGTACTGATCAAACCCGTTGCCGCCATCTGCGGTGTCGCGCTCGTTTCATCCCTGGCCGCCGGCACCGTGCTGGCCGACGACCCCTTCGAACTCACCGATCTGGACGCCGGCTACATGCTCGCAGGTGACGACAAGGGCGAAGAAGGCAAGTGCGGCGAAGGCAAGTGCGGTGAGGAAGGCGAAGAGGGAGAAGAAGGCGAGGAAGGTGAAGACGAGGACAAGGGTGAGGAAGGCAAGTGCGGCGAGGGCAAATGCGGCTCCTGA",
      "translation": "MADKTVLIKPVAAICGVALVSSLAAGTVLADDPFELTDLDAGYMLAGDDKGEEGKCGEGKCGEEGEEGEEGEEGEDEDKGEEGKCGEGKCGS",
      "product": ""
     },
     {
      "start": 1723,
      "end": 2361,
      "strand": -1,
      "locus_tag": "ctg203_4",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg203_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg203_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,723 - 2,361,\n (total: 639 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg203_4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg203_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATCAAGGCGGACCGTGTCGAATTCTTCCGGCGCCTGCGCGAGCACGACCCGAACCCCACCACGGAGCTGGAGTACGACAGCGCCTTCGAACTGCTGGTGGCGGTGATTCTTTCCGCCCAGGCCACGGACGTCGGCGTGAACAAGGCCACCCGCCGCCTGTTTCCGGTGGCCAACACCCCTCGCGCCATTCTCGACCTGGGGCTGGAGGGGCTCAAATCGCACATCCGCACCATCGGGCTGTTCAATGCCAAGGCCGCGAACATCATCGAGACCTGCCGGATCCTGCTGGAACGCCACAATGGCCAGGTACCGGACGAGCGGGCCGCCCTCGAGGCCCTGCCGGGGGTCGGGCGCAAGACCGCCAACGTGGTCCTGAACACCGCGTTCGGCCAGCCCACGATGGCCGTGGACACCCACATCTTCCGCGTGGCGAACCGCACCGGGCTGGCCATCGGCAAGACGCCGCTGGAGGTCGAGCGCAAGCTGCTCCGTAGCGTTCCGGAAGAATTCCTGCAGGACGCCCACCACTGGCTGATCCTGCACGGGCGCTACACCTGTACGGCCCGCAAGCCGCGTTGCGCCGAGTGCCTGGTCGCCGATCTCTGCCGCGAGGGCCGCAAAGGCACCTGGCGCTGA",
      "translation": "MIKADRVEFFRRLREHDPNPTTELEYDSAFELLVAVILSAQATDVGVNKATRRLFPVANTPRAILDLGLEGLKSHIRTIGLFNAKAANIIETCRILLERHNGQVPDERAALEALPGVGRKTANVVLNTAFGQPTMAVDTHIFRVANRTGLAIGKTPLEVERKLLRSVPEEFLQDAHHWLILHGRYTCTARKPRCAECLVADLCREGRKGTWR",
      "product": ""
     },
     {
      "start": 2358,
      "end": 3068,
      "strand": -1,
      "locus_tag": "ctg203_5",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg203_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg203_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,358 - 3,068,\n (total: 711 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg203_5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg203_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACGGAATCGACTGACCCGGGCGCGCCGAACACCCCCCGCACGGGCGAGGTCTTCCGCGACGCCTTCTGGCGCCAGAACACGGGGCTGGTCGTGCTCCTGGGCCTGTGCCCGCTGCTGGCGGTCTCCGGTTCGGTGACGAACGCCCTGGGTCTGGGCCTGGCGACCACCGTGACCCTGGCGGTTTCGAACCTCTGCGTGTCCCTGGCCCGGGGCCTGCTGCGGCCGGAAATCCGCATTCCCGCTTTCGTGCTGATCATCGCCTCGACCGTGACGGTGATCGAACTCCTGATGCAGGCCTGGTTCCAGGGCCTGTACCTGGCGCTGGGCATCTTCATTCCGCTGATCGTCACCAACTGCGCCATCATCGGGCGGGCGGAGGCGTTCGCCTCGCGCCACGCGCCCTGGCCCGCGCTGGTGGACGGCTTCGCCACCGGACTGGGCTTCTGCCTGACCCTCGTGCTGCTCGGCGCCGTGCGGGAACTGGCGGGCCACGGGACACTGCTCGCGGACGCCCATCTGCTGGTGGGCGAGTGGGGCCGGAGCCTCGAATTCGAAGTCATTCCCGGCCACCCGGGATTCCTGCTGGCCATGCTGCCCCCGGGCGCGTTCATCGCCCTCGGCATGCTGGTCGCGGCGCGCAATGCCTGGCAGCAGCGCCGGGACGCAAAACCGAGCGGGGCCACCGCCCGCGAGGCCCTGGCGCAATGA",
      "translation": "MTESTDPGAPNTPRTGEVFRDAFWRQNTGLVVLLGLCPLLAVSGSVTNALGLGLATTVTLAVSNLCVSLARGLLRPEIRIPAFVLIIASTVTVIELLMQAWFQGLYLALGIFIPLIVTNCAIIGRAEAFASRHAPWPALVDGFATGLGFCLTLVLLGAVRELAGHGTLLADAHLLVGEWGRSLEFEVIPGHPGFLLAMLPPGAFIALGMLVAARNAWQQRRDAKPSGATAREALAQ",
      "product": ""
     },
     {
      "start": 3052,
      "end": 3714,
      "strand": -1,
      "locus_tag": "ctg203_6",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg203_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg203_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,052 - 3,714,\n (total: 663 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg203_6\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg203_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAGTGAACCACGAGCCGTGACGACCACCACGACGCCGCCCTGGCGGGCCGGGCTGCTGCTGGCCACCCTGGCCGTCATCGGCGTGGGCCTGCTTGCGGGCGTCCACGAACTCACGGCCGAGCGCATCGCCGCGCAGGAGCGGGCCACCCTTCTGCAGCGGCTGGACGAGGTCTTGCCAGCGGACTGGTACGACAACGACCTGCTCGCGGATGTGGTGATCGTGGAGGCGCCGGAGGCCCTGGGCCACGACCGGCCGATTCATGTCTACCGGGCCCGGCGAGGCGGTCACCCGGTGGCCGCCATCCTCGAAGTGATCGCGCCGGACGGCTACAACGGCGACATCGCGCTCCTGATGGGCGTCACCCTCGAGGGAACGGTGACCGGCGTCCGGGTCGTCCGTCACCGCGAAACACCGGGTTTGGGCGACCCCATCGAGACCGCGCGCAGCGACTGGACGCTCGGCTTCGACGGACGGTCCCTCGGCGACCCGCCGGCGGAGCGGTGGACGGTGCGCAAGGACGGCGGCGCCTTCGATCAATTCACGGGTGCTACCATCACGCCGCGCGCGGTCACCCGGGCGCTGGCCCGGGCCCTGGCCTGGTTCGCGGCACAGGACGCGACGCTCTTTGACAGGAAGGCGAACGATGACGGAATCGACTGA",
      "translation": "MSEPRAVTTTTTPPWRAGLLLATLAVIGVGLLAGVHELTAERIAAQERATLLQRLDEVLPADWYDNDLLADVVIVEAPEALGHDRPIHVYRARRGGHPVAAILEVIAPDGYNGDIALLMGVTLEGTVTGVRVVRHRETPGLGDPIETARSDWTLGFDGRSLGDPPAERWTVRKDGGAFDQFTGATITPRAVTRALARALAWFAAQDATLFDRKANDDGID",
      "product": ""
     },
     {
      "start": 3711,
      "end": 4739,
      "strand": -1,
      "locus_tag": "ctg203_7",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg203_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg203_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,711 - 4,739,\n (total: 1029 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg203_7\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg203_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCGGACATTCCACGCCGCCGCGGCCCCGCACCTGCCCTCGAAACGCACGGTTCGTGGCGTCATGTCCCAGGTGCTGCTGGCGCTGGTCCCGGGCATCGCGGTCCACGCCTGGCTGTTCGGCCCCGGCATCTTTGTGCAGATCGTGATCGCCTCCGGCTTCGCCCTGGCCTTCGAGGCGGCCCTCTTGCGGCTGCGCGGCCGGCCGCTGGCGCCCTTCCTCACCGACGGCAGCGCCGTCGTGGCCGCGAGCCTGTTCGCCCTGTGCATCCCCCCGCTGGCGCCGTGGTGGATCGCCGCGGTGGCCATGTTCTTCGCCATCGTGATCGCCAAGCACTGTTTCGGCGGCCTGGGTCACAACGTGTTCAATCCGGCCATGGTGGGTTACGTGGTCGTGCTCATCAGCTTTCCGCTCCAATTGACCCGGTGGCCGCTGCCCCGTGAACTGTCATCCGGGACCCCGGGCCTGGACGCCACCCTGCAGGCCATCCTCGGCGGTCGAGTCATTGCGCCCGACGGCATCGACGCCCTGACGGGCGCGACACCGCTGGATGCGATCCGGACCGGCCTGGCCGAGGGCCGGCCGCTGGACACCGTGCTCCAGTCGCCGGTGTTCGGCGCGGTGGGCGGAACGGGCTGGGAATGGCTGGCTGCCGCCTTCGGCATCGGCGGCCTCTACCTGTTGTGGCGCGGCATCATCCGTTGGCAGGTGCCGGTGGCGACGCTGGGCAGCGTGTTGGTGATGGCGCTCGTCGCCTGGGTACTGAACCCTGAAACCTACCCTTCGGCGGTGCTGCACTGCCTGTCGGGCGGACTGGTGCTCGGGGCCTTCTTCATCGCCACGGACCCGGTCAGCGGCTGCGCGAGCCGACGGGGTCGACTGGTCTTCGGCGTCGGCGTCGGCGTGCTCACCCTCGTGATCCGGTACTGGGGCGGCTACCCGGACGGCGTCGCCTTCGCCGTGCTGCTCATGAACATGGCCGCGCCCCTGGTCGACCGGGTCACGCGGCCCCGGGTGTACGGGACGTGA",
      "translation": "MRTFHAAAAPHLPSKRTVRGVMSQVLLALVPGIAVHAWLFGPGIFVQIVIASGFALAFEAALLRLRGRPLAPFLTDGSAVVAASLFALCIPPLAPWWIAAVAMFFAIVIAKHCFGGLGHNVFNPAMVGYVVVLISFPLQLTRWPLPRELSSGTPGLDATLQAILGGRVIAPDGIDALTGATPLDAIRTGLAEGRPLDTVLQSPVFGAVGGTGWEWLAAAFGIGGLYLLWRGIIRWQVPVATLGSVLVMALVAWVLNPETYPSAVLHCLSGGLVLGAFFIATDPVSGCASRRGRLVFGVGVGVLTLVIRYWGGYPDGVAFAVLLMNMAAPLVDRVTRPRVYGT",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 162,
      "end": 1035,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 6035,
      "product": "RiPP-like",
      "category": "RiPP",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "RiPP-like",
    "products": [
     "RiPP-like"
    ],
    "product_categories": [
     "RiPP"
    ],
    "cssClass": "RiPP RiPP-like",
    "anchor": "r203c1"
   }
  ]
 },
 {
  "length": 5367,
  "seq_id": "k39_43254",
  "regions": []
 },
 {
  "length": 17546,
  "seq_id": "k39_141410",
  "regions": []
 },
 {
  "length": 3079,
  "seq_id": "k39_121654",
  "regions": []
 },
 {
  "length": 2963,
  "seq_id": "k39_43291",
  "regions": []
 },
 {
  "length": 9751,
  "seq_id": "k39_102242",
  "regions": []
 },
 {
  "length": 16100,
  "seq_id": "k39_102249",
  "regions": []
 },
 {
  "length": 18192,
  "seq_id": "k39_141446",
  "regions": []
 },
 {
  "length": 8490,
  "seq_id": "k39_23877",
  "regions": []
 },
 {
  "length": 4655,
  "seq_id": "k39_82476",
  "regions": []
 },
 {
  "length": 7416,
  "seq_id": "k39_141477",
  "regions": []
 },
 {
  "length": 7040,
  "seq_id": "k39_82503",
  "regions": []
 },
 {
  "length": 5843,
  "seq_id": "k39_43394",
  "regions": []
 },
 {
  "length": 8315,
  "seq_id": "k39_4185",
  "regions": []
 },
 {
  "length": 4537,
  "seq_id": "k39_4201",
  "regions": []
 },
 {
  "length": 5124,
  "seq_id": "k39_102413",
  "regions": []
 },
 {
  "length": 2696,
  "seq_id": "k39_121873",
  "regions": []
 },
 {
  "length": 2801,
  "seq_id": "k39_82586",
  "regions": []
 },
 {
  "length": 16995,
  "seq_id": "k39_23999",
  "regions": []
 },
 {
  "length": 5217,
  "seq_id": "k39_82618",
  "regions": []
 },
 {
  "length": 9083,
  "seq_id": "k39_141637",
  "regions": []
 },
 {
  "length": 8757,
  "seq_id": "k39_63255",
  "regions": []
 },
 {
  "length": 4161,
  "seq_id": "k39_24049",
  "regions": []
 },
 {
  "length": 13319,
  "seq_id": "k39_4316",
  "regions": []
 },
 {
  "length": 5660,
  "seq_id": "k39_63315",
  "regions": []
 },
 {
  "length": 3231,
  "seq_id": "k39_43669",
  "regions": []
 },
 {
  "length": 8675,
  "seq_id": "k39_82792",
  "regions": []
 },
 {
  "length": 12449,
  "seq_id": "k39_122129",
  "regions": []
 },
 {
  "length": 5015,
  "seq_id": "k39_4496",
  "regions": []
 },
 {
  "length": 3590,
  "seq_id": "k39_63467",
  "regions": []
 },
 {
  "length": 9958,
  "seq_id": "k39_24305",
  "regions": []
 },
 {
  "length": 2609,
  "seq_id": "k39_122227",
  "regions": []
 },
 {
  "length": 7391,
  "seq_id": "k39_24362",
  "regions": []
 },
 {
  "length": 4129,
  "seq_id": "k39_82967",
  "regions": []
 },
 {
  "length": 16828,
  "seq_id": "k39_4613",
  "regions": []
 },
 {
  "length": 6708,
  "seq_id": "k39_82981",
  "regions": []
 },
 {
  "length": 4782,
  "seq_id": "k39_43955",
  "regions": []
 },
 {
  "length": 17243,
  "seq_id": "k39_83045",
  "regions": []
 },
 {
  "length": 4726,
  "seq_id": "k39_63637",
  "regions": []
 },
 {
  "length": 5390,
  "seq_id": "k39_4763",
  "regions": []
 },
 {
  "length": 3771,
  "seq_id": "k39_24578",
  "regions": []
 },
 {
  "length": 6401,
  "seq_id": "k39_122597",
  "regions": []
 },
 {
  "length": 7017,
  "seq_id": "k39_44204",
  "regions": []
 },
 {
  "length": 13708,
  "seq_id": "k39_103132",
  "regions": []
 },
 {
  "length": 12915,
  "seq_id": "k39_44250",
  "regions": []
 },
 {
  "length": 12369,
  "seq_id": "k39_4990",
  "regions": []
 },
 {
  "length": 7426,
  "seq_id": "k39_103243",
  "regions": []
 },
 {
  "length": 10104,
  "seq_id": "k39_44295",
  "regions": []
 },
 {
  "length": 20777,
  "seq_id": "k39_142439",
  "regions": []
 },
 {
  "length": 14247,
  "seq_id": "k39_44340",
  "regions": []
 },
 {
  "length": 24514,
  "seq_id": "k39_44342",
  "regions": []
 },
 {
  "length": 12930,
  "seq_id": "k39_24969",
  "regions": []
 },
 {
  "length": 5299,
  "seq_id": "k39_5195",
  "regions": []
 },
 {
  "length": 6526,
  "seq_id": "k39_44471",
  "regions": []
 },
 {
  "length": 5399,
  "seq_id": "k39_83700",
  "regions": []
 },
 {
  "length": 6429,
  "seq_id": "k39_44576",
  "regions": []
 },
 {
  "length": 2628,
  "seq_id": "k39_5397",
  "regions": []
 },
 {
  "length": 9163,
  "seq_id": "k39_142804",
  "regions": []
 },
 {
  "length": 2569,
  "seq_id": "k39_64507",
  "regions": []
 },
 {
  "length": 3165,
  "seq_id": "k39_25376",
  "regions": []
 },
 {
  "length": 6870,
  "seq_id": "k39_83992",
  "regions": []
 },
 {
  "length": 4774,
  "seq_id": "k39_25466",
  "regions": []
 },
 {
  "length": 9690,
  "seq_id": "k39_84024",
  "regions": []
 },
 {
  "length": 2882,
  "seq_id": "k39_44963",
  "regions": []
 },
 {
  "length": 6983,
  "seq_id": "k39_104084",
  "regions": []
 },
 {
  "length": 3187,
  "seq_id": "k39_5910",
  "regions": [
   {
    "start": 1,
    "end": 3187,
    "idx": 1,
    "orfs": [
     {
      "start": 3,
      "end": 191,
      "strand": -1,
      "locus_tag": "ctg268_1",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg268_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg268_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3 - 191,\n (total: 189 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) RRE-containing: Stand_Alone_Lasso_RRE<br>\n \n  biosynthetic (rule-based-clusters) RRE-containing: Lasso_Fused_RRE<br>\n \n  biosynthetic-additional (rule-based-clusters) PF05402<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg268_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg268_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg268_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg268_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATTGCCAGCGCTGAAACATTCCGCTGCAAGCCGGACGTCTTGTTCCAGGAGGTCAGCGGGGAGATTGTACTGCTGGACCTCGTTTCCGAGCGCTATTTCGGTCTGAATTCGACAGGCGCCAGGGTCTGGCAGGGGCTGTCGGAGGGTCGGACGACCGAGGAGATCATTTCCGGACTCGCCAAGGAG",
      "translation": "MIASAETFRCKPDVLFQEVSGEIVLLDLVSERYFGLNSTGARVWQGLSEGRTTEEIISGLAKE",
      "product": ""
     },
     {
      "start": 282,
      "end": 1373,
      "strand": -1,
      "locus_tag": "ctg268_2",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg268_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg268_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 282 - 1,373,\n (total: 1092 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg268_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg268_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg268_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg268_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCTGCTCGACGAAGTCCGGAATTCAGCCTACGCAAGGGCGATCAAGGGGCTGGTCGGTCCTGAAACTACGGTGCTCGACCTGGGTGCGGGGCTGGGACTGCTTGGCCTGATGGCGGCGAAAGCAGGTGCGCGGCAGGTCTATCTCGTCGACCCGTCTCCCGTATTGCTCGACGTCGAGTCGGTAATCGAGGCGAATGGCCTGGGAGACAGGGTCAGCATCATCCTCCAGCCGATCGAAGCAGCCAGCTTGCCGGAAAAGGTCGATGTCCTGGTTTCCGTAATGACCGGCAATTTCCTGCTGCAGGAAGATCTGCTGCCGACGCTGTTCTTCGCCAGGGATCGGTTCCTGAAGTCGACCGGCACCCTGGTCCCTGCGAAGGGAACCATGGTCGCTGTTCCCGTGACACTGGCGCGACCTGAGCGCCATCCGGCGTTCCGGTTGATGCGGGCCATTCAGGGCCTCGACTACGATTCCGTGCGCCGGCGATTCGTCAACCGCGTGCAGTTCGAACGCTTTTTCGAAAGCGACGCCCTTTACCTGGCTGCACCGGAGCCACTGGCGACACTGGATTTTTCCATTGCGGACAAGGCGGCGGTCGATACCACCACGACGTTCAGGGCAACCGCAAATGGTCGCCTGGATGGCCTGCTTGGGTGGTTCGATATGGACTTGGGCGACCACGCATTGTCCACGGGGCCACAGGCAGAGTCCGTACACTGGAAGCAGGCGTTCATGCCCCTGGAGACCCCCGTGTCCATTCGACAGGGTGAAGAGGTCCAGTTTTCACTCAACCGTCCTGAGCGTGGCGAATGGACGTGGAGCGTGTCCGTGGGCGGGTCTGTGCAAAGGATGTCCACGTTCTTCGGATACCGACCTGATATCGAAGCGTTCGAACGCCAGGCACCTGGTCATGTCCTCGAAGACACGCCGGAAAGCGTTTCTGCTCGTTTTGTGCTCGAAAGAATTGCCAGGGGTGTGACGCGGAAGGAGATGGAACGTGATTTCCTGCAGTGGAATGAGCGTCACCTGGTCGATCACCCATCCGCACGGACTTGGTTGCATCAGTTCCTCGACAGGTTTTCCTGCTGA",
      "translation": "MLLDEVRNSAYARAIKGLVGPETTVLDLGAGLGLLGLMAAKAGARQVYLVDPSPVLLDVESVIEANGLGDRVSIILQPIEAASLPEKVDVLVSVMTGNFLLQEDLLPTLFFARDRFLKSTGTLVPAKGTMVAVPVTLARPERHPAFRLMRAIQGLDYDSVRRRFVNRVQFERFFESDALYLAAPEPLATLDFSIADKAAVDTTTTFRATANGRLDGLLGWFDMDLGDHALSTGPQAESVHWKQAFMPLETPVSIRQGEEVQFSLNRPERGEWTWSVSVGGSVQRMSTFFGYRPDIEAFERQAPGHVLEDTPESVSARFVLERIARGVTRKEMERDFLQWNERHLVDHPSARTWLHQFLDRFSC",
      "product": ""
     },
     {
      "start": 1380,
      "end": 3185,
      "strand": 1,
      "locus_tag": "ctg268_3",
      "type": "transport",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg268_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg268_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,380 - 3,185,\n (total: 1806 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1288:ABC transporter related protein (Score: 300.4; E-value: 4.5e-91)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg268_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg268_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMTEETRVMLTHTLALCPSSKSKFKAGIPRSTKAYNVVASTHGTRHLKFPDLVAIVTPAKSLMGAILGLSLTTSALALVQPWLAGRLAESLTGQPEGWINDVYRWLLAWFAVVAVYSLVLFLSNRLSASVAESMFARLRNRAFEHIQSLPLTWHQRRKTGDTLSLLTHDTGTISTFVSTTVIGLIPSVLVLFGALIAMFRISPKFTVLAAAFIPVYYLAIKIVGRRLRPVSRKLLDAWSEKTVFLQDHLQLLPVIKAFGQEAREISRHEACDRKLSDAARRQAFLGARIAPLTRFLAAGGLLFLMWVGVTDLERGALDTAQLVSLLFYVLLLNQPVAALAGSYGKIQSTLGAAERLQTLFGSEPEPDPSQGEELKIKSGTVRFENVRFTYPNAPPLFEGLCLEVPGGRVTLLTGPNGVGKSTLIHLAMRFLRPSVGKIAIDGQSLEDVSTHSLRDAVGLVAQHTVLLNTTIADNLRYGKWQATQNEMETACEAAGAMAFIRELPDGLETVIGEQGLHLSGGQRQRISLARTLLKDPPIVLIDEATSMIDEGGLDEFIERIPKLFAGKTVLLVSHQKQYATIAQHVIHLESGSQPSGEWPQAPG\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg268_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg268_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACTGAAGAAACTCGCGTAATGCTCACTCATACCCTTGCCCTGTGCCCCAGCTCAAAATCGAAATTCAAGGCAGGAATCCCCCGTTCGACCAAAGCCTATAATGTCGTCGCCTCCACCCACGGTACAAGGCATTTGAAGTTTCCGGACCTCGTCGCCATCGTGACGCCCGCCAAGTCGCTCATGGGAGCAATCCTCGGATTGTCCCTGACCACCAGCGCACTGGCTCTGGTCCAGCCCTGGCTCGCAGGACGGCTGGCCGAATCCTTGACGGGACAGCCCGAGGGATGGATCAATGACGTCTATCGATGGCTGCTGGCCTGGTTTGCAGTCGTCGCCGTGTACAGCCTGGTCCTGTTTCTTTCCAACCGGCTGTCCGCGTCTGTTGCCGAGTCGATGTTTGCAAGGCTGCGTAACCGGGCCTTCGAGCACATTCAGTCCCTGCCCCTGACCTGGCACCAACGCCGGAAGACGGGAGACACCCTGTCGCTGTTGACACACGACACGGGCACCATCAGCACGTTCGTGTCGACAACTGTCATCGGTCTGATCCCTTCAGTGCTCGTTCTGTTCGGCGCCCTGATCGCCATGTTTCGTATCAGCCCAAAGTTTACTGTGCTCGCTGCGGCGTTCATCCCCGTGTACTACCTCGCAATTAAGATTGTCGGTCGCAGGCTCCGTCCCGTGTCGCGCAAGCTGCTCGATGCCTGGTCCGAGAAAACGGTGTTTCTCCAGGATCACCTGCAGCTGTTGCCAGTCATCAAGGCATTTGGACAGGAGGCCCGGGAAATCTCGCGCCACGAAGCATGCGACCGCAAGCTGTCCGATGCCGCGCGGCGCCAGGCCTTTCTTGGCGCCCGAATTGCGCCCCTGACCCGATTCCTGGCCGCCGGCGGCTTGTTGTTTCTCATGTGGGTGGGTGTCACCGATCTCGAGCGGGGAGCGCTGGACACCGCGCAACTGGTCAGCCTTCTGTTCTACGTCCTGTTGTTGAACCAGCCTGTCGCTGCGCTTGCGGGGAGTTACGGAAAGATCCAGTCGACGCTTGGTGCCGCTGAACGTCTTCAGACACTGTTCGGATCAGAACCCGAGCCGGATCCCTCGCAGGGCGAGGAACTGAAAATAAAGTCCGGTACGGTGCGGTTCGAAAACGTCAGATTTACTTACCCGAATGCGCCACCGCTGTTCGAAGGGCTTTGTTTGGAAGTGCCCGGCGGAAGAGTCACATTGCTCACTGGGCCGAATGGGGTGGGGAAATCCACGCTGATCCACCTGGCCATGCGGTTTCTGCGACCCAGCGTGGGCAAAATTGCCATCGATGGACAGAGCCTCGAAGATGTCTCGACCCATTCGCTTCGAGATGCTGTCGGGCTGGTCGCCCAGCACACCGTGCTACTGAACACGACGATTGCGGACAACCTCCGTTATGGCAAATGGCAAGCCACTCAAAACGAAATGGAGACTGCCTGCGAAGCCGCGGGGGCGATGGCGTTCATCAGGGAGCTGCCTGACGGCCTGGAAACCGTCATCGGCGAGCAGGGCCTGCACTTGTCCGGTGGGCAAAGGCAGCGCATTTCGCTGGCGCGAACCCTGCTGAAGGACCCACCCATTGTGCTGATTGATGAAGCAACCTCGATGATCGACGAAGGGGGGCTCGACGAATTCATAGAGCGAATTCCCAAGCTGTTCGCCGGCAAGACGGTGTTGCTGGTCTCGCACCAGAAACAGTATGCGACGATTGCCCAGCACGTCATCCACCTGGAGTCAGGAAGTCAGCCCAGTGGGGAGTGGCCCCAGGCACCTGGA",
      "translation": "MTEETRVMLTHTLALCPSSKSKFKAGIPRSTKAYNVVASTHGTRHLKFPDLVAIVTPAKSLMGAILGLSLTTSALALVQPWLAGRLAESLTGQPEGWINDVYRWLLAWFAVVAVYSLVLFLSNRLSASVAESMFARLRNRAFEHIQSLPLTWHQRRKTGDTLSLLTHDTGTISTFVSTTVIGLIPSVLVLFGALIAMFRISPKFTVLAAAFIPVYYLAIKIVGRRLRPVSRKLLDAWSEKTVFLQDHLQLLPVIKAFGQEAREISRHEACDRKLSDAARRQAFLGARIAPLTRFLAAGGLLFLMWVGVTDLERGALDTAQLVSLLFYVLLLNQPVAALAGSYGKIQSTLGAAERLQTLFGSEPEPDPSQGEELKIKSGTVRFENVRFTYPNAPPLFEGLCLEVPGGRVTLLTGPNGVGKSTLIHLAMRFLRPSVGKIAIDGQSLEDVSTHSLRDAVGLVAQHTVLLNTTIADNLRYGKWQATQNEMETACEAAGAMAFIRELPDGLETVIGEQGLHLSGGQRQRISLARTLLKDPPIVLIDEATSMIDEGGLDEFIERIPKLFAGKTVLLVSHQKQYATIAQHVIHLESGSQPSGEWPQAPG",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 2,
      "end": 191,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 3187,
      "product": "RRE-containing",
      "category": "RiPP",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "RRE-containing",
    "products": [
     "RRE-containing"
    ],
    "product_categories": [
     "RiPP"
    ],
    "cssClass": "RiPP RRE-containing",
    "anchor": "r268c1"
   }
  ]
 },
 {
  "length": 8975,
  "seq_id": "k39_45007",
  "regions": []
 },
 {
  "length": 7699,
  "seq_id": "k39_123652",
  "regions": []
 },
 {
  "length": 7437,
  "seq_id": "k39_25908",
  "regions": []
 },
 {
  "length": 5186,
  "seq_id": "k39_84449",
  "regions": [
   {
    "start": 1,
    "end": 5186,
    "idx": 1,
    "orfs": [
     {
      "start": 3,
      "end": 1172,
      "strand": 1,
      "locus_tag": "ctg272_1",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg272_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg272_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3 - 1,172,\n (total: 1170 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg272_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg272_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg272_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg272_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "CGGTCCGTCCTCGCGCGGACCCGAACGGAAACCCACCCCACCCTGGTCGCCACCAACCGCGAGACGCTGATGTGGGGCGCCCTGTCGTTGGTCCCCCGCGAACTCGAGCGACTGCATCGGCTGGGAAATGCCGCCCTGCCGGCCGCACCCGCCGGCCAGGGCGCATCGCAGGCGGCTGCCGCGTTTTCACCGGGCGCGCCACGCCTGGCGAGACACCTTCTGCATCTGCTGGCCAAGCGCCTGAAACGCTCGATACGTTATCGGCTGTTCCAGGAGCACTGGCACCTGCGTTACGCCTTCGGTGAGGAACCGTCGACAGCTTTCCGGCAGTTCGAATCCCTGGTGCCATCACGGGATCGTTACTGGGCCGACCCGATGCCGCTGTTTCACGAAGGCCACTGGCACATTTTCTTCGAGGACCTGCCCGAAGCAACGGACAAGGGCCACATCTCGATGATCAGCTTTGACGACCACCACCGGCCGCTGCCGCCCCGGACGGTCCTCGAACGTCCCTACCACCTTTCCTACCCCTTCGTGTTCCACTGGGACCAGCGGCTCTGGATGATTCCCGAGACCGCCAGCAACCGGGCGGTCGAGCTCTACGAGTGCACGGAGTTTCCGGATCAATGGGAACTACGCCGGCGCATCCTGGAGGACCACTACATCGTCGACGCAACCCTGGAACGCCATGACGGGCGCTGGTACCTGTTCGGCAACCAGGTCGAGAACCCGGGCGCCTCGTCCTGGACCGAGCTGTTCCTGTTCGTGAACGAGGGAGACCTGCTCGACGGCGCCTGGACGCCCCATCCGGACAATCCGATCCGCTCAGACGTGCGCTGCGCCCGCCCGGCCGGTCCCCTCTACCGGACGGGCGAGTCACTGCTTCGCCCTTCCCAGGACTGCAGCCGCCGTTACGGAGGAGGAATGACACTTCACGAAATCAACGAACTGGGGCCGGAGCGGTATTCCGAGCAGATCGTCAATCGCATCCAGCCGGACTGGGAGCCTGATCTCAAGGGCGCCCACACCTATTCGCACCGTCCCGGGCTCACCGTGATCGACGTGATGAAGGAAGTGCCGCGGCCAGGCCTTTTCGGCCGCCTGCCCGAGCCCGTCCAGCGGCGAGTGGCGCACCTCCTGGCGGCGAGGCGCGCAGCCGACGATCATTGA",
      "translation": "MSVLARTRTETHPTLVATNRETLMWGALSLVPRELERLHRLGNAALPAAPAGQGASQAAAAFSPGAPRLARHLLHLLAKRLKRSIRYRLFQEHWHLRYAFGEEPSTAFRQFESLVPSRDRYWADPMPLFHEGHWHIFFEDLPEATDKGHISMISFDDHHRPLPPRTVLERPYHLSYPFVFHWDQRLWMIPETASNRAVELYECTEFPDQWELRRRILEDHYIVDATLERHDGRWYLFGNQVENPGASSWTELFLFVNEGDLLDGAWTPHPDNPIRSDVRCARPAGPLYRTGESLLRPSQDCSRRYGGGMTLHEINELGPERYSEQIVNRIQPDWEPDLKGAHTYSHRPGLTVIDVMKEVPRPGLFGRLPEPVQRRVAHLLAARRAADDH",
      "product": ""
     },
     {
      "start": 1239,
      "end": 3146,
      "strand": 1,
      "locus_tag": "ctg272_2",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg272_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg272_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,239 - 3,146,\n (total: 1908 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: AMP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 324.4; E-value: 1.7e-98)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg272_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg272_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg272_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg272_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGGGGGCGCCTTTGGGGTTACCAAAAGGGGAAGCAGTGACGCACGATCACGACATTTGTGGGGGCGATAGCGGCCATTTGGGCGCCGTTCGCGACGTCGTGGCGCGTTTCGAACACATCGTCGCGCACCACGCGGATGCCATTGCCGTCATCGAAGCAACACCGGATTCCACCCGTTCGGACCCGAGTTACAGCTATGCCAGGCTGAATGAGCGGCGCCTGGAAATTGCCGGCGCCCTCGTCGAACAACACGGACTGGGACCCGGCGACTGGGTCGGCCTGGTGCAATCCCGCCGCTTCGACACCCTGGCGGCCATGCTGGGGATTGCCACGATCGGCGCGAGCTATGTTCCACTGGATGCCGAGTGGCCGGAAGAGCGCCGTCGATACCTCCTGTCGGATGCCAAGGTGCGGGTGCTCCTGACGGCGGGACGCTCCGCGCCGTCCGGCGCCCTGCCCCTTTCGGAGTGCCGCGGATCGGCCCGTTCATTCGAGGGCGCAGCCCCGGACACGCCGCTCTACGTCATGTACACCTCCGGCTCGACCGGGGAACCCAAGGGCGTCGTGGTGCCGCACCGGGCCGTGGTCCGGCTCGTGGTCGGGACCGATTTCATGCCCCTGGACCCGCACACCCGGTTCCTGCACGCCGCGCCCCAGTCCTTCGACGCGGCGACCCTGGAAATCTGGGGACCGCTGCTTAACGGCGGAACCTGCGTGCTGCACCCGGAGGGCATTTTCGACCCCGCCGGCCTGGACCCCCTGGCTGACAAGCACGACATCAACGCCCTGTGGCTGACGGCCGCACTGTTCAACCAATGGGTCCAGTTACGCCCAAGGGGGCTCGAAGGCGCGGCCACCGTGCTGTTCGGCGGCGAAAGAGCCTCCGTTCCGCACGTACGCCAGGCCGCCGCGCTCTGGCCCCGGACCACGCTGGTCAACGGCTACGGTCCGACCGAGAACACGACCTTCACCTGCTGTCACACGGTCCGCCCGCAGGACCTCGACGAACAGGCCACGGAACTCCCCATCGGAAAGGCCATTACGGGCACGGCGGTGTGGATCGTGAACGGCGCCTTGGAAGACGTTCCCGCCGGCACGGTCGGCGAACTGGTGACCGGCGGCGAGGGCCTGGCGCTGGAATACCTGGGCCGCCCTGAATTGACATCCGAACGCTTCGTCACCGACGCCGGGGGCGAGCGCTGGTACCGGACGGGCGACCTCGCCAGGCAGGACGACGACGGCGTCATCCATTTTCACGGCCGGGCCGACCGCCAGTTGAAGCTGCATGGCCACCGCATCGAACCGGGCGAAATCGAGGCGGCGCTGCTGGCCGACCCGCGCTTGCACCATGCCCATGTCCTGGCCGTCGAAACGCCGGAAGGCGACCAGAAACTGGCGGCCTATCTCGTCGGCGAATTCGACCGGACCGAATTGCAGAACCGGCTGGCCGGCGCCCTGCCGCGATTCATGGTGCCGTCCGTTTACGTGTGTATCAGTGAGCTACCGACAACGGCCAATGGCAAGGTCGATGTCGGGGCATTGCCGTATCCGTTTCACGGCAAGGACCCGGCGCCGGCCAACGGCGGTGGCAATGACATGGCGAGGCTGGTGGCCGCGACCTGGCGGAACGTGGTTTCGGGTATCGACCTTAAAGGCAACGACGACAACTTTTTTGACGTGGGGGGCACGTCGATGGACATGATCCGGGTCAAGCAGGCCCTGGAAAAGCAGTTGGCTACGGAGATTCCGCTGGTCAGCCTGTTCCAGTACCCCACGGTTTCGAAGCTGGCGTCTCATCTCGACGCGCTGGCCCAGCCCGAGTCCGCCGCGGCGACCGCCACGGACCGGGCGGCCCGGCGCCGGCAGCAACTGGCTCGGCGCAAGGCCGGCCGGGTGCGGACATGA",
      "translation": "MKGAPLGLPKGEAVTHDHDICGGDSGHLGAVRDVVARFEHIVAHHADAIAVIEATPDSTRSDPSYSYARLNERRLEIAGALVEQHGLGPGDWVGLVQSRRFDTLAAMLGIATIGASYVPLDAEWPEERRRYLLSDAKVRVLLTAGRSAPSGALPLSECRGSARSFEGAAPDTPLYVMYTSGSTGEPKGVVVPHRAVVRLVVGTDFMPLDPHTRFLHAAPQSFDAATLEIWGPLLNGGTCVLHPEGIFDPAGLDPLADKHDINALWLTAALFNQWVQLRPRGLEGAATVLFGGERASVPHVRQAAALWPRTTLVNGYGPTENTTFTCCHTVRPQDLDEQATELPIGKAITGTAVWIVNGALEDVPAGTVGELVTGGEGLALEYLGRPELTSERFVTDAGGERWYRTGDLARQDDDGVIHFHGRADRQLKLHGHRIEPGEIEAALLADPRLHHAHVLAVETPEGDQKLAAYLVGEFDRTELQNRLAGALPRFMVPSVYVCISELPTTANGKVDVGALPYPFHGKDPAPANGGGNDMARLVAATWRNVVSGIDLKGNDDNFFDVGGTSMDMIRVKQALEKQLATEIPLVSLFQYPTVSKLASHLDALAQPESAAATATDRAARRRQQLARRKAGRVRT",
      "product": ""
     },
     {
      "start": 3200,
      "end": 5185,
      "strand": 1,
      "locus_tag": "ctg272_3",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg272_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg272_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,200 - 5,185,\n (total: 1986 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) T1PKS: hyb_KS<br>\n \n  biosynthetic (rule-based-clusters) T1PKS: PKS_AT<br>\n \n  biosynthetic-additional (smcogs) SMCOG1093:Beta-ketoacyl synthase (Score: 89.9; E-value: 2.4e-27)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg272_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg272_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg272_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg272_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAACCAGCAAGCATTGCCCGAAAACGCCGTCGCAATCGTCGGCATCGCCTGCCGTTATCCCGGGGCCCAGGATCTCGAGGCCTTCTGGCGGAACCTGCGCGAGGGGCGCGAGTCGATCACCTTCTTTTCCGCGGACGAGATCGACGCGAGTATTCCCGACGCGATCAAGTCCCAGCCCAATTACGTCCGGGCCAAGGGGCGGCTGGACGATGTCGACCGGTTCGATGCGAAGTTTTTCGACATCCCGCCCGTCGAAGCCAGCCTCATGGATCCACAGCAGCGCCTGCTGCTCGAACTGTCCTGGGCGGCCCTCGAGGACGCGGGCATCGTTCCCGGCGAGGGCGACAACCTGGTCGGCGTCTGGGTCGGCACCAACTGGAACCGGTACTACGCCCGGCACGTGCGCGGCAGCGCGGCCGAGCAGCGCTACGGTGAATTCAACGCCCAGTTGGCGAACGAGTTCGACTTCCCCGCCTCCAGAATCGCCTACAAGTTGAACCTGACCGGACCGGCGATCACGCTGGCCACCGCCTGCTCGACCTCGCTGGTCGCCATCGGCCAGGCCATGCAGTCGTTGCTCAACTTCGAGTGCAATGCCGCGCTGGCCGGCGGCGCCAGCATCTCGGTACCCCTGAACGCCGGTTACCTGCACCACGAGGGCGAGATGCTGTCCGCCGACGGGCATTGCCGGCCCTTCGACGCGCACTCCAGCGGCACGACCTTCAATGACGGCGCCGCGGTCATCGCGCTCAAGCGCCTCGAGGACGCCGTCGCCGACGGCGACGACATCTACGCGGTGATCCGGGGCGTCGGCATCAACAACGACGGCGCCGACAAGGTCAGTTACACCGCCCCCAGCGTCAATGGACAGATCGACGCCCTGAGCGCCGCCCTGGCCATCGCGGATGTGGATCCCGCCTCGGTCGGCCTGATCGAGACGCACGGTACGGCGACCCGTCTCGGAGACCCGATCGAAGTCGCGGCCATCCGCACGGTGTACGGCGCCGACCCTTCTGCGGGGCCGTGTGCGCTCGGCGCCCTGAAAAGCAACATCGGCCATGCCATCCACGCCGCGGGCATCGCCGGCGTGATCAAGGCCGCGCTGGCGGTCCGCGACGGCGTCATTCCGCCGACCATCAACTTCGAGACGCCCAATCCGGACCTGCAACTCGAGGGCAGCCGCTTCTACGTCAACTCCGAGGCCGTGGCCTGGCCTGACGCCACGCCCCGCCGCGCCGGCGTGAGCTCCTTCGGGGTCGGTGGAACCAATGCCCACGCCCTGGTCGAGCAACCCCCGGCCGCCACGAAGGCGCCACGCGCCCCGAGCGCCGATACGCCACCCTTGCTGCTGCTTTCGGCCCGGGACACGGAGACCTGCATGCGGCAGGCGATGAACCTCTCCGACCAGGCCCGAACACAGCCCGATATGCCGGACCTGGCCGACGTCGGCTACACGCTGGCCCGTTCCCGCAAGCGCTTCGACACGCGGGCGGCCCTGTTCGCCACCGGAATCGAGGAACTGGCGGCCTTCGACGAACAGTCCACGCGAATCGTCCGCGGCAAGGCGCGGCCGCTCGACACCCTGGTGTGGGCTTTCCCCGGACAGGGGGCGCAGCGGGCCGGCATGGGCGCGGCGCTCGAGGGGCGCTCGGACGCCTACCGCGAAGCCCTCTCTCGCGCCATCGAACAGCTCAATCCGCACCTGGATCTCGACCTTCGACAGCTGTTGCAGCGCGATGGCGAACTGCCGGGCGATGCGGCCGAGCGCATCTCCGAAACGAAGTATGCCCAGCCCGCCCTGTTTGCCGTCGGCTACGCCCTTGCGGCGCACTACCGGGCCGCCGGGCTGGAGCCGGACCTCCTGGTCGGCCACAGCATCGGCGAATTCGCCGCCGCCTGTATCGCGGGCGTGTTCAGCCTCGAGGACGCCGCCCTGCTCGTGTGCGAACGCGGACGGCTGATGCAGGCCCAGCCGCGCGGCGCC",
      "translation": "MNQQALPENAVAIVGIACRYPGAQDLEAFWRNLREGRESITFFSADEIDASIPDAIKSQPNYVRAKGRLDDVDRFDAKFFDIPPVEASLMDPQQRLLLELSWAALEDAGIVPGEGDNLVGVWVGTNWNRYYARHVRGSAAEQRYGEFNAQLANEFDFPASRIAYKLNLTGPAITLATACSTSLVAIGQAMQSLLNFECNAALAGGASISVPLNAGYLHHEGEMLSADGHCRPFDAHSSGTTFNDGAAVIALKRLEDAVADGDDIYAVIRGVGINNDGADKVSYTAPSVNGQIDALSAALAIADVDPASVGLIETHGTATRLGDPIEVAAIRTVYGADPSAGPCALGALKSNIGHAIHAAGIAGVIKAALAVRDGVIPPTINFETPNPDLQLEGSRFYVNSEAVAWPDATPRRAGVSSFGVGGTNAHALVEQPPAATKAPRAPSADTPPLLLLSARDTETCMRQAMNLSDQARTQPDMPDLADVGYTLARSRKRFDTRAALFATGIEELAAFDEQSTRIVRGKARPLDTLVWAFPGQGAQRAGMGAALEGRSDAYREALSRAIEQLNPHLDLDLRQLLQRDGELPGDAAERISETKYAQPALFAVGYALAAHYRAAGLEPDLLVGHSIGEFAAACIAGVFSLEDAALLVCERGRLMQAQPRGA",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 1,
      "end": 5185,
      "tool": "",
      "neighbouring_start": 0,
      "neighbouring_end": 5186,
      "product": "CC 1: neighbouring",
      "kind": "candidatecluster",
      "prefix": "",
      "height": 0
     },
     {
      "start": 1238,
      "end": 3146,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 5186,
      "product": "NRPS-like",
      "category": "NRPS",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     },
     {
      "start": 3199,
      "end": 5185,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 5186,
      "product": "T1PKS",
      "category": "PKS",
      "height": 4,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [
      {
       "start": 1260,
       "end": 1262,
       "strand": 1,
       "containedBy": [
        "ctg272_2"
       ]
      },
      {
       "start": 2067,
       "end": 2069,
       "strand": 1,
       "containedBy": [
        "ctg272_2"
       ]
      }
     ],
     "bindingSites": []
    },
    "type": "NRPS-like,T1PKS",
    "products": [
     "T1PKS",
     "NRPS-like"
    ],
    "product_categories": [
     "NRPS",
     "PKS"
    ],
    "cssClass": "hybrid",
    "anchor": "r272c1"
   }
  ]
 },
 {
  "length": 27163,
  "seq_id": "k39_123847",
  "regions": []
 },
 {
  "length": 9270,
  "seq_id": "k39_65119",
  "regions": []
 },
 {
  "length": 5020,
  "seq_id": "k39_65134",
  "regions": []
 },
 {
  "length": 7632,
  "seq_id": "k39_143585",
  "regions": []
 },
 {
  "length": 3240,
  "seq_id": "k39_26163",
  "regions": []
 },
 {
  "length": 2620,
  "seq_id": "k39_45444",
  "regions": []
 },
 {
  "length": 5105,
  "seq_id": "k39_84904",
  "regions": []
 },
 {
  "length": 7072,
  "seq_id": "k39_104744",
  "regions": []
 },
 {
  "length": 4443,
  "seq_id": "k39_104759",
  "regions": []
 },
 {
  "length": 6264,
  "seq_id": "k39_143908",
  "regions": []
 },
 {
  "length": 14249,
  "seq_id": "k39_104811",
  "regions": []
 },
 {
  "length": 3644,
  "seq_id": "k39_26503",
  "regions": []
 },
 {
  "length": 3703,
  "seq_id": "k39_45789",
  "regions": []
 },
 {
  "length": 4046,
  "seq_id": "k39_104962",
  "regions": []
 },
 {
  "length": 3612,
  "seq_id": "k39_85233",
  "regions": []
 },
 {
  "length": 2692,
  "seq_id": "k39_105036",
  "regions": []
 },
 {
  "length": 4988,
  "seq_id": "k39_144354",
  "regions": []
 },
 {
  "length": 3840,
  "seq_id": "k39_7200",
  "regions": []
 },
 {
  "length": 3729,
  "seq_id": "k39_124774",
  "regions": []
 },
 {
  "length": 6204,
  "seq_id": "k39_27052",
  "regions": []
 },
 {
  "length": 13264,
  "seq_id": "k39_7411",
  "regions": []
 },
 {
  "length": 30746,
  "seq_id": "k39_46246",
  "regions": []
 },
 {
  "length": 4523,
  "seq_id": "k39_66296",
  "regions": []
 },
 {
  "length": 3202,
  "seq_id": "k39_105510",
  "regions": []
 },
 {
  "length": 3933,
  "seq_id": "k39_27240",
  "regions": []
 },
 {
  "length": 8926,
  "seq_id": "k39_46418",
  "regions": []
 },
 {
  "length": 3932,
  "seq_id": "k39_85869",
  "regions": []
 },
 {
  "length": 2637,
  "seq_id": "k39_105643",
  "regions": []
 },
 {
  "length": 24426,
  "seq_id": "k39_27340",
  "regions": []
 },
 {
  "length": 2851,
  "seq_id": "k39_46545",
  "regions": []
 },
 {
  "length": 15913,
  "seq_id": "k39_7778",
  "regions": []
 },
 {
  "length": 12545,
  "seq_id": "k39_105722",
  "regions": []
 },
 {
  "length": 2874,
  "seq_id": "k39_125563",
  "regions": []
 },
 {
  "length": 3723,
  "seq_id": "k39_105949",
  "regions": []
 },
 {
  "length": 5868,
  "seq_id": "k39_66913",
  "regions": []
 },
 {
  "length": 17564,
  "seq_id": "k39_86425",
  "regions": []
 },
 {
  "length": 6394,
  "seq_id": "k39_8292",
  "regions": []
 },
 {
  "length": 12108,
  "seq_id": "k39_67048",
  "regions": []
 },
 {
  "length": 26384,
  "seq_id": "k39_47115",
  "regions": []
 },
 {
  "length": 23591,
  "seq_id": "k39_106309",
  "regions": []
 },
 {
  "length": 4464,
  "seq_id": "k39_145616",
  "regions": [
   {
    "start": 1,
    "end": 4464,
    "idx": 1,
    "orfs": [
     {
      "start": 3,
      "end": 689,
      "strand": -1,
      "locus_tag": "ctg313_1",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg313_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg313_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3 - 689,\n (total: 687 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg313_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg313_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg313_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg313_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGTTCGCGGTGTACCACTCACCGGAGGGTGCGCCACGCGGCGAGGGAATCGTGGTCTGCCAGCCGCTGGGTCACGAATACTTCCGTTGCTACCGGACCCTCCAGGTGCTCTGCGCGGAACTCGCCCAGGGCGGTTACCACGTCCTGCGTTTCGATTTCTCGAACACCGGAAATTCCGCCGACGCGGATTCCCTGGAATTCAGCACCTGGGTGAACGACGTTGCACGCGCGGTTCGCGAACTCACCGACATCTCGGGCACTCGCAGCCTCTCCCTGGTCGGGGCCCGGCTGGGCGCCACGGCTTGCCTGAACCTGGGAAGCGCCGTCCAGCCGCTGAAGCAGATCGTCCTGTGGGATCCGGTCCTCGATGGGGCGTCCTGCCTGGCGTCGCTCGACCGTCTCCACGAGAAGGTCTGTTCGGCGCATCCCGGCGGTCCCTCGGGCGCCCCGGAGCTGGTGAGCGCCTCCGGCTGCGAGCGTGTCGGCCTCGATCTCCCGCCCGGCTTGCGTGACTCGATCGGCGTGATCACGCCGCCCTCCCTGGCGGTGCCCGCGGCCGAACGGCTGACGGTCGTCACGACCCTCGGGGAAACGGAGTCGCTGTCCGGTGCGTTCGCCGGGACCGTGGCCCCCAACGTGGTACAGGTCGATTCGGACTGTGGCTGGAACGACGCCGTGCGCTTCACC",
      "translation": "MFAVYHSPEGAPRGEGIVVCQPLGHEYFRCYRTLQVLCAELAQGGYHVLRFDFSNTGNSADADSLEFSTWVNDVARAVRELTDISGTRSLSLVGARLGATACLNLGSAVQPLKQIVLWDPVLDGASCLASLDRLHEKVCSAHPGGPSGAPELVSASGCERVGLDLPPGLRDSIGVITPPSLAVPAAERLTVVTTLGETESLSGAFAGTVAPNVVQVDSDCGWNDAVRFT",
      "product": ""
     },
     {
      "start": 751,
      "end": 4464,
      "strand": -1,
      "locus_tag": "ctg313_2",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg313_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg313_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 751 - 4,464,\n (total: 3714 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: A-OX<br>\n \n  other (smcogs) SMCOG1251:luciferase family protein (Score: 417.7; E-value: 6.2e-127)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg313_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg313_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg313_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg313_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "CTGAGCGATGCCGAGCTCGCCTGGCTCTCGGCCGCCTCGAAAGCGGAGCCGGGATGGATCGCCCTGCGCGGGTCGGAAACGCCACTCGACGTCGAGTGGCTGTTCCAGGACGAAGGCCAGCCCGTCCAGTCCCGGACATCCAGGGTCGAGATTCCGGAGATCGTGAACCTGGAAGCGGGCGTCACGGTCGTGCTGCTGGCGCTGTTGCGCCTGAGCGGCGACCAACGTGGACTGGTCGCGCTGCTCGATGCCACGCTCGAGGACTTTCCGCTGGTCGAGTCATTCCGCCCCGTGCTGGCCTCGCTCCGCGAGGACGAATCGGTCGCCTCGTTCACGGAGCGCATGGGCGCCCGGATCGCTGCTGCCGGAAGGAAGGGTCCCCTCCTGCGGGACCAGGGCCTGCGGTCCACCCGTGATCTCGGTTCGACGCCCTGCGTGGCGGTCAGTGCGGGCGCGGCCCTCGCGGCCGGCCGGGGGTTCGACCTGTGGGTTCACGTGGACGTGGGCGAGGCGGGCGCAAGCATCGAAACGCGATTCGAACGCGCGACCTCCGCGCGCAAGGTCGCCCAGTTCGAGCAGGCGCTCAGAGGCGTGGCCCGGGACGTCTCGACCCGTTCGACCCGGCCGGCCGCTGCCATCGACATCGTCGCCGAAACGGACCGGGCCCAGGTGCTGGACCAATGGAATCCGCCGCCGACGGCGTCGAAGGAAGAGTGCATCCACCACGCGTTCCTGCGCGTGGCATCCGAACAGGGCGCCGCGCCGGCCGTGCTGTGCGACGGCAGGGTGCTTTCCTTTGCCGAACTGGCGCAACAGGCGCAGTCGGTGGCCCGGCACCTGCAGGGCCTCGAGGTCGGCCCCGACGACCGGGTCGGCATCTGCCTGGAGCGCAACGAGGCACTGCTCATCGCCGTCCTGGGCGTGTTGGCGTCCGGGGCCGCCTACGTTCCGCTGGACCCCGAATACCCGGCCGCCCGGCTCCGGCACATCGTGGCGGACGCCGAGCCGGCGTTGACGCTGGTGAGCGAGGACACCCGGCACCGGCTGGAAGGCACGACCGCGCCCCTGCTGTCATGGGACGAGGCCCTCGCGGCCGACTCGGGCGCCGACCTTCGAGACGAGGCCAGCCCTCGGAACCTGGCCTACGTCATCTACACCTCCGGGTCCACGGGGGCACCGAAGGGCGTGATGGTCGAGCACCGCAACGCCGCGAATTTCTTCACCGCGATGGACGAGCGGGTGACCCTGGGCGCCGGGCCGCGATGGTTGTCCGTCACCAGTCTTTCCTTCGACATCTCGGTGCTGGAACTGTTGTGGACCCTGACGCGCGGCGTGGGCATCGTCCTCTACACGGGCGCAGACCGGACGGGCGCCGTGTCCGCCATCGCCCCGAAGCCGCGCGCCAACGACACGCCCATCGACTTCAGCCTGTTCTACTTCGCCAGCGACGAGGGGGAACGTCATGACGGCAGGGGTGCAAACGGCAGGGGCCCGGCCGACAAGTACCGGCTCCTCGTGGAAGGTGCGAAGTTCGCCGACGCGAACGGCTTCGTGGCCGTCTGGACCCCGGAACGACATTTCCACGCCTTCGGCGGCCTCTATCCGAACCCCTCGGTGGTGAGCGCCGCACTGGCGACCATCACGGAGCATGTCCAGCTTCGTGCGGGGAGCTGCGTGCTGCCCCTGCATGACCCGATCCGGATCGCCGAGGAGTGGGCGCTGGTCGACAACCTGTCCAACGGCCGGGTCGGCATCTCCTTCGCTTCCGGCTGGCAGCCCAACGATTTCGTGCTCGCGCCGGACCGTTACGAAAACCGGCACGAGGTCATGGCCGAAGGTATCGAGACCGTCCGCGCCCTGTGGCGCGGTGACAGCGTGCGGCGGACCAATCCGCTCGGCAAGGAGGTGGAACTGGCCACCTTGCCGCGACCGGTGCAGGAAGAGTTGCCGTTCTGGGTGACCGCCGCGGGCAACCCGGCCACTTTCCAGGCGGCAGGCCGGCAGGGTGCGAACCTGCTGACGCACCTGCTGGGTCAGGACCAGGAGGAACTGGCCGGGAAGATCGAGGCCTACCGCTCGGCCTGGCGGGAGGCGGGCCATCCGGGCGAAGGAATCGTGACACTCATGCTGCATACCTTCGTCGGAGACGACGAGGAGGCGGTCAAGGCCGCGGTGCACGAGCCGCTGAAGGCGTACCTCCGCAGCTCCGTCGGCCTCATCCGCAAGTTCGCCGACACCTTTCCCGCCTTCAGGAATCGCGGCGGTGATGGCGGGACGATCGACTTCGACGCGCTCGCCCCGGAGGACATGGAGGCGCTGCTCGAATTCGCCTTCGAGCGGTACTACCGGGACAGCGGCCTGTTCGGCGCCCCGGAGCGCTGCGCCCGGATGGTCGATTCGCTGAAGGGCATCGGCGTGAACGAGATCGCCTGCCTGGTCGATTTCGGCGTGCCCTCCGAACAGGTGCTCGAACACCTGCCGGACATCGCGGAGGTCATGCGACGGTCGAAACCCCGGTCCGAGCTTCCGGCGGGATCGGTGGCGGCCTTGATCCAGGCCCACGGCGCCACGCACCTGCAATGCACCCCCTCGCAGGCGCAGATGCTGCTGGCCGACCCGGACAACCACCCCGCAGTGGCCGGCCTGCGGGGCTGGCTGGTGGGCGGCGAGGCGCTGCCGGAAGAACTCGCCAGGCGCCTCCGAACCGTGGCGCGGGGGACGGTGATCAACATGTACGGCCCCACGGAAACCACGATCTGGTCCACGACGTGGGCCCTGCCAGAGGATCCCGGCCCGGTGCTGATCGGCACGCCCATCGCCAACACCCGCTGCTACGTGCTCGACGATGCCCTCCGGCTTCGGCCGCCGGGCGCGCCCGGCGAACTGTTCATCGGCGGCCAGGGCGTGACCCGTGGGTATCTCGGCAAGGAGGCATTGACGGCGTCCCGCTTCCTGGAGGACCCCTTCGGTGATCCGGGCGACCGCATGTACCGGACCGGCGACCGCGTGCGCTGGGTCGACGGGGAGCTGGAGTTCCTCGGCCGTATGGACGACCAGGTCAAGGTGCGCGGCTACCGGATCGAACTGGGCGACATCGAGTCGGCACTCGCCGCCTTCGACGGCCCCCAGCAGGTGGTGGCCGCCATCAAGACGGACGCCGCCGGCGATCCGGCCATCGTTGCTTATGCCCTGATGCCCCCGGGGACCGGCCTCGACGAAGTGGCCCTGCGGCGCCATCTCAACCGCACACTGCCGCCGTACATGGTCCCCCAGGTCTTCATCGAGATCGACGAGGTGCCGCTGACCCCGAACGGGAAGGTGGACCGGCGCGCCTTGCCGGACCTCGATGCCGGCCGGCGCGGCCGGCGCGGCGCCTTCGTGCCCCCGTCAACGGAGACCGAGAAGGCCCTTGCGGCCATCTGGGGCGAGGTGCTCTCGGTGGCGCAGGTGGGCTCGCAGGACACCTTCTTCGAACTGGGCGGGGATTCCCTGGCGGCCGTCCGGGTCGCGGTTCGCATCCGCGAGGTGATCGGCGAGCGGCTGCCCCTGGAAACCCTCCTTCGCGCGACGCTGGCCCAATCGGCGAGGTCCCTGGACGGCGCGCGGGCGGGCGAGCGCCCTGGTGCGGGGCCCGCGACCCGGGAACCCGCGGACGCCACTGGGCGCAAGTCCGGACTGTTGCACCGCCTGACCCGGCGCAAGCCCAGGGCCTGA",
      "translation": "MSDAELAWLSAASKAEPGWIALRGSETPLDVEWLFQDEGQPVQSRTSRVEIPEIVNLEAGVTVVLLALLRLSGDQRGLVALLDATLEDFPLVESFRPVLASLREDESVASFTERMGARIAAAGRKGPLLRDQGLRSTRDLGSTPCVAVSAGAALAAGRGFDLWVHVDVGEAGASIETRFERATSARKVAQFEQALRGVARDVSTRSTRPAAAIDIVAETDRAQVLDQWNPPPTASKEECIHHAFLRVASEQGAAPAVLCDGRVLSFAELAQQAQSVARHLQGLEVGPDDRVGICLERNEALLIAVLGVLASGAAYVPLDPEYPAARLRHIVADAEPALTLVSEDTRHRLEGTTAPLLSWDEALAADSGADLRDEASPRNLAYVIYTSGSTGAPKGVMVEHRNAANFFTAMDERVTLGAGPRWLSVTSLSFDISVLELLWTLTRGVGIVLYTGADRTGAVSAIAPKPRANDTPIDFSLFYFASDEGERHDGRGANGRGPADKYRLLVEGAKFADANGFVAVWTPERHFHAFGGLYPNPSVVSAALATITEHVQLRAGSCVLPLHDPIRIAEEWALVDNLSNGRVGISFASGWQPNDFVLAPDRYENRHEVMAEGIETVRALWRGDSVRRTNPLGKEVELATLPRPVQEELPFWVTAAGNPATFQAAGRQGANLLTHLLGQDQEELAGKIEAYRSAWREAGHPGEGIVTLMLHTFVGDDEEAVKAAVHEPLKAYLRSSVGLIRKFADTFPAFRNRGGDGGTIDFDALAPEDMEALLEFAFERYYRDSGLFGAPERCARMVDSLKGIGVNEIACLVDFGVPSEQVLEHLPDIAEVMRRSKPRSELPAGSVAALIQAHGATHLQCTPSQAQMLLADPDNHPAVAGLRGWLVGGEALPEELARRLRTVARGTVINMYGPTETTIWSTTWALPEDPGPVLIGTPIANTRCYVLDDALRLRPPGAPGELFIGGQGVTRGYLGKEALTASRFLEDPFGDPGDRMYRTGDRVRWVDGELEFLGRMDDQVKVRGYRIELGDIESALAAFDGPQQVVAAIKTDAAGDPAIVAYALMPPGTGLDEVALRRHLNRTLPPYMVPQVFIEIDEVPLTPNGKVDRRALPDLDAGRRGRRGAFVPPSTETEKALAAIWGEVLSVAQVGSQDTFFELGGDSLAAVRVAVRIREVIGERLPLETLLRATLAQSARSLDGARAGERPGAGPATREPADATGRKSGLLHRLTRRKPRA",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 750,
      "end": 4464,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 4464,
      "product": "NRPS-like",
      "category": "NRPS",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "NRPS-like",
    "products": [
     "NRPS-like"
    ],
    "product_categories": [
     "NRPS"
    ],
    "cssClass": "NRPS NRPS-like",
    "anchor": "r313c1"
   }
  ]
 },
 {
  "length": 23478,
  "seq_id": "k39_28025",
  "regions": [
   {
    "start": 1,
    "end": 23478,
    "idx": 1,
    "orfs": [
     {
      "start": 1,
      "end": 75,
      "strand": -1,
      "locus_tag": "ctg314_1",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1 - 75,\n (total: 75 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCCAATGGTCACTCACCGAGCGGCTGCAACCTTCCCTGCTCGATCGCCTCACCGACGAGGAGCCGGACAAG",
      "translation": "MSQWSLTERLQPSLLDRLTDEEPDK",
      "product": ""
     },
     {
      "start": 83,
      "end": 868,
      "strand": -1,
      "locus_tag": "ctg314_2",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 83 - 868,\n (total: 786 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGACGCTGAACTGCTGCTCAAGGCCGGCGATCCGGCCGCAGCCCTCGAGTCACTCAAGAACAAGGTGCGGGCCGATCCATCGAACGCGTCCCTGCGCACCTTCCTGTTCCAGCTGATGGCGATCAACGGAGACTGGGACAAGGCGACCAAGCAGTTGGACGTGGTCAAGGACCTCGACGACGGCACCATCGCCATGGCCCGTGTCTACGAGGATGTCATCAATTGCGAGAAGCACCGCGACGCGGTGTTCGCCGGCAAGGTGCGCCCCATCGTGTTCGGAGAACCCGAGCCCTGGGTGGCCAGGCTGGTCGAGGCGCAGCAGGCGCTGGCCCAGGGCGATGTCGATCGGCATCTTTCCCTCCAGCAGCAGGCCTTCGAGGAGGCTCCTGCCGTTTCGGGCCGCATCAACGACGAAGGCTTCGAGTGGCTGGCCGACGCGGACACCCGCTTTGGCCCGGTGCTCGAAATGATGTTCAACCAGCATTATTACTGGGTTCCGCTCAACCGGGTGCGCAGCCTGAAGACCGAAGCGCCTTCCGACCTGCGCGACCTGGTCTGGCTCCCGGCGGAGGTGACCTGGGTCAACGGCGGCCAGGTGATGGTGATGATGCCGGCGCGCTATCCGGGACTGGAAGGCCTCGACGGCAACCACCTCCTGGGCCGCAAGACCGAGTGGCGCGAGTCGCACCCCGGGGTGTTCGAAGGCGTCGGCCAGAAGATGCTGGGCACCGACCAGGGCGAGTACCCGCTGCTGCAGGTCCGCACCATCGAATTCGACGCCTGA",
      "translation": "MDAELLLKAGDPAAALESLKNKVRADPSNASLRTFLFQLMAINGDWDKATKQLDVVKDLDDGTIAMARVYEDVINCEKHRDAVFAGKVRPIVFGEPEPWVARLVEAQQALAQGDVDRHLSLQQQAFEEAPAVSGRINDEGFEWLADADTRFGPVLEMMFNQHYYWVPLNRVRSLKTEAPSDLRDLVWLPAEVTWVNGGQVMVMMPARYPGLEGLDGNHLLGRKTEWRESHPGVFEGVGQKMLGTDQGEYPLLQVRTIEFDA",
      "product": ""
     },
     {
      "start": 980,
      "end": 1345,
      "strand": -1,
      "locus_tag": "ctg314_3",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 980 - 1,345,\n (total: 366 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCACACCGCGACCGGTGGTGCGGCGTCCTCCTCGATGGTGGGCGACTTCAGCTGCTCGGTCCCGTGCGGCAAGGGTGACCCCAACTTCGCCCAGTACTGCGCGCTCGGCAAGCACATTCCCACCGTCAAGGTGCACCTGTGCAAATCGTCCGGCGACACGCTGGTGGAGTGGTACACCTACACCTTCAATACCGTCATCATCTCGAGCTACAGCGTTTCGGGCGGCGGTGGAGCACCGGGCTACGCGAACATCAGCTTCAACTTCGCCGATTTCCAGCTCCAGCAGTTCGACCAGGACGACAAGGGTTCGGTCAAGGCCGGCCCGGACGTGAAGTACAGCGCTCGCTTGAAGAAGCCGCTCTGA",
      "translation": "MHTATGGAASSSMVGDFSCSVPCGKGDPNFAQYCALGKHIPTVKVHLCKSSGDTLVEWYTYTFNTVIISSYSVSGGGGAPGYANISFNFADFQLQQFDQDDKGSVKAGPDVKYSARLKKPL",
      "product": ""
     },
     {
      "start": 1656,
      "end": 3158,
      "strand": -1,
      "locus_tag": "ctg314_4",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,656 - 3,158,\n (total: 1503 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCTGAAGAGAAACTCGCCACAAAGGGCGCGGCGGCAGCCGTCACCGAGGAAAGCAGTGATTTCGCGGCCCTGCTCCAGAAGGAGTTCCGCCCGAAGTCCGACCGTATCTCGGACGAAATCAATTCCGCGGTCGGCACGCTGGCCGAGTACGTGCTCAAGGACACCAACCTGGTGTCCGAGGACGCGGTGACCTCGATCCAGGCGATGATCGCCCAGATTGACGCCAAGCTGACCGAGCAGGTCAACCAGATCATCCACCATGAGGAGTTCCAGAAACTCGAGAGCGCCTGGCGCGGCCTGTCCTACATGGTGAACAACACCGAAACCGACGAGTCCCTGAAGATCAAGGTCATGAACATCTCCAAGGAGGAGCTGGGCAAGACCCTGAAGAAGTTCAAGGGAACCGCCTGGGACCAGAGCCCCTTGTTCAAGCAGATGTACGAAGAGGAATACGGGCAGTTCGGTGGTGAGCCCTTCGGGCAGATCGTGGGTGACTACTACTTCGACCACGGACCCGCGGACGTTGAAATTCTTCGTGGCATGGCGCAGATCAGCGCGGCCATGCACGCGCCGTTCATTTCCGCGGTGTCGCCGACGGCGATGCAGTTCGACTCCTGGGCCGAGCTGAGCAACCCGCGCGACCTCACCAAGATCTTCCAGACGCCGGAATACGCGGCCTGGCGGTCGCTGCGTGAATCCGAGGACTCGCGTTACCTCGGCCTGACCATGCCGCGCTTCCTCGCTCGCCTGCCTTATGGCGCGAACACCGACCCGGTCGAGGCCTTCGACTTCGAGGAGGAAACCGAGGGCGCGGATTCCAGCAAGTACTCCTGGGCCAACTCGGCCTATGCCATGGCGACCAACATCAACCGCTCCTTCAAGGTGTTCGGCTGGTGTTCGCGGATCCGCGGCATCGAGTCCGGCGGCGCGGTGGAGGAGCTTCCGACCCACACCTTCCCGACGGACGACGGCGGCGTGGCGATGAAGTGCCCGACCGAGATCGCCATCAGCGACCGGCGCGAGGCGGAACTCGCGAAGAACGGCTTCATGCCGCTCATTCATCGCAAGAACTCCGATTTCGCGGCCTTCATCGGCGCCCAGTCCTTGCAGAAGCCGCAGGAGTACGAGGATCCGGACGCCACGGCCAACGCCAACCTGGCTGCGCGCCTGCCGTACCTGTTCGCCACCTGCCGCTTCGCGCACTATCTCAAGTGCATCGTTCGCGACAAGATCGGTTCCTTCAAGGAGCGCGACGACATGCAGCGCTGGCTGAACAACTGGATCCAGCAGTACGTGGACGGCGACCCCGCGAACTCCACCGAGTCCACCAAGGCGCGCAAGCCCCTGGCGGCGGCGGAGGTCGTGGTGGAAGCGGACGAGAGCAACCCGGGCTACTACCGGTCGCGTTTCTACCTGCGGCCGCACTACCAGCTCGAAGGCCTGACCGTGTCCCTGCGACTGGTGTCCAAGCTGCCTTCCGTCAAGGAAGGGGGCGGCTGA",
      "translation": "MAEEKLATKGAAAAVTEESSDFAALLQKEFRPKSDRISDEINSAVGTLAEYVLKDTNLVSEDAVTSIQAMIAQIDAKLTEQVNQIIHHEEFQKLESAWRGLSYMVNNTETDESLKIKVMNISKEELGKTLKKFKGTAWDQSPLFKQMYEEEYGQFGGEPFGQIVGDYYFDHGPADVEILRGMAQISAAMHAPFISAVSPTAMQFDSWAELSNPRDLTKIFQTPEYAAWRSLRESEDSRYLGLTMPRFLARLPYGANTDPVEAFDFEEETEGADSSKYSWANSAYAMATNINRSFKVFGWCSRIRGIESGGAVEELPTHTFPTDDGGVAMKCPTEIAISDRREAELAKNGFMPLIHRKNSDFAAFIGAQSLQKPQEYEDPDATANANLAARLPYLFATCRFAHYLKCIVRDKIGSFKERDDMQRWLNNWIQQYVDGDPANSTESTKARKPLAAAEVVVEADESNPGYYRSRFYLRPHYQLEGLTVSLRLVSKLPSVKEGGG",
      "product": ""
     },
     {
      "start": 3162,
      "end": 3680,
      "strand": -1,
      "locus_tag": "ctg314_5",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,162 - 3,680,\n (total: 519 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGTAAAGAAAGCAGTCAGAAATTCATTCAGCGCAATCGTGCGCCCAGGGTACAGATCGAATACGACGTCGAACTGTACGGTTCGGAGAAGAAGGTCCACCTGCCCTTCGTGGCCGGGGTGCTCGCCGACCTTTCCGGCAAGTCCGAAAACACGCCGCCGCCCGTGGCGGACCGCAAGTTCCAGGAATTCGACATCGACAACTTCGATGACCGCATGAAGGCCATCAAGCCGCGTGCCGCTTTCCGGGTGGACAACACCCTGACGGGCGAGGGCCAGCTCAACGTGGACCTGACCTTCGAAAGCATGGACGACTTCTCACCCGAAGCCGTGGCGCGCAAGGTCGATTCACTCAACAAGCTGCTGGAAGCACGGACCCAGCTCAGCAACCTGGTGACCTACATGGACGGCAAGAGCGGGGCGGAAGAGCTCATCGCCAAGGCCATGAACGACCCGGCGCTCATGCAGTCCCTGGTTTCTGCGCCCAACCCCGACGACGCTTCCGAGAAAGAGGACTGA",
      "translation": "MGKESSQKFIQRNRAPRVQIEYDVELYGSEKKVHLPFVAGVLADLSGKSENTPPPVADRKFQEFDIDNFDDRMKAIKPRAAFRVDNTLTGEGQLNVDLTFESMDDFSPEAVARKVDSLNKLLEARTQLSNLVTYMDGKSGAEELIAKAMNDPALMQSLVSAPNPDDASEKED",
      "product": ""
     },
     {
      "start": 3795,
      "end": 5138,
      "strand": -1,
      "locus_tag": "ctg314_6",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,795 - 5,138,\n (total: 1344 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_6\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAGTTCAGTGGTCTCCTCTCGGTCCTGGCCTGTACGGAAATCGCCCGGCATTCGCCGGTCCCGCCCACGTCACGGGGCTGCCTGGAAAAAGTCCAGTTCGCAGTCCGTCCCCCGATCGTTTTCCCGGGACGGCCAGCGAAGGCGGGAATGTCAGTTGCGGGTCGACCCGTTTCCCCTATACTCAAGTGGTCCTGAGTTCTTGTTCAGTCATCATAGTCCAAGAATAGCAAAAGCAATCAGTGAACTTCCGGCACGGGTCCATCGCCTGGCGAGAACCCCGACGGGGTCCCTACGACTTCACGCAATTCGGCATTGGGGAGAATGCATGCGTATTTCCGCTGACGAGCTGAGCCAGCCTATTTCCGAGGATCAACCCTGCGGGGAAGATCTCGAGTACGACGCCGCCTTCCAGGCGATGGAAACCGCCCTGCAATCGCAGGACGCCCAGGAGATGGGCGATTCAACGAAAGAAGCCCAGGGTCCCGACTGGCAGGCCGTGGGCGCCAACGCCCTCGACCTCCTGGGCCGCACGCGCGACCTGCGCGTGTTCGTCAATCTCGCCATGGCGGGCCTTCACACCGACGGACTCCCGGCGTTTCACCAGGCCCTGGTGGCCCTGAACAACTGCATGGACCAGTTATGGGAAACGGTGCATCCCCAGCTCGATCCGGATGATGACAACGACCCCATGATGCGCATGAACGTGCTGCAGAACCTCGACGACTACGCCAACGTCCGCATGGGCCTGAAGCGTTGTCCGCTGGTGGAGCTCAAGGGCTTCGGCGCATTCAGCCTGCATGACATCGAACTGGCCACCGGCGCGCGCGAGGCCGGCGAAGGCGAGGAGGTGACGGACCTGGCGATCATTCAGGGCGCCTTCGTCGACTCCGACCGTGACCAGCTCACCCTGGTGTCGGAAGCGGCGGCGGGTGCGCTGGCCGAGTTCGCGCGGATGTCGGAACTGTGGTCCGAGCGCACCGGCGGGTACGAGCAGCCCGGCATCGACAACGTGATCGCCTCCCTGCGTGAAATCAGCCGAACCCTGGTGGAGTACGCGCCCGCGGGCACCGTGGCGGGTACGGAGGAGGAGGCGGCAGCCGAAGGCGAAAGCGGTTCGGCGGCGCCCGCGGCGCCCGGTACGATCAACAGTCCTGCCGATGTCATCCTGGCCCTGGACCGGATTTGCGATTACTACGCAAAGACCGAACCTTCCAGCCCCATTCCCTTCATCCTCAGGCGCGCCCAGCGGCTGGTGTCGAAATCGTTCTACGAAATCCTCCAGGACATTGCCCCTGACGGGATCACACAGTTCGACACGATCACCGGGCACATGCAGGAGTGA",
      "translation": "MSSVVSSRSWPVRKSPGIRRSRPRHGAAWKKSSSQSVPRSFSRDGQRRRECQLRVDPFPLYSSGPEFLFSHHSPRIAKAISELPARVHRLARTPTGSLRLHAIRHWGECMRISADELSQPISEDQPCGEDLEYDAAFQAMETALQSQDAQEMGDSTKEAQGPDWQAVGANALDLLGRTRDLRVFVNLAMAGLHTDGLPAFHQALVALNNCMDQLWETVHPQLDPDDDNDPMMRMNVLQNLDDYANVRMGLKRCPLVELKGFGAFSLHDIELATGAREAGEGEEVTDLAIIQGAFVDSDRDQLTLVSEAAAGALAEFARMSELWSERTGGYEQPGIDNVIASLREISRTLVEYAPAGTVAGTEEEAAAEGESGSAAPAAPGTINSPADVILALDRICDYYAKTEPSSPIPFILRRAQRLVSKSFYEILQDIAPDGITQFDTITGHMQE",
      "product": ""
     },
     {
      "start": 5140,
      "end": 6798,
      "strand": 1,
      "locus_tag": "ctg314_7",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,140 - 6,798,\n (total: 1659 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_7\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGCCGATCAGCCTGAGAATCAGCAGTTACCAGCGACTCACGCCGGGCCAGCAGGAACGGTTCTGGTCCGATGCCGGCGCCTTCACGATCGGCCGAGGCAAGGACAACGACTGGGTGATGCCCGACCCGCAGCGTTTCCTGTCGGGCGTTCATTGCCGCGTGGAGCGCAAGGGTGACGACTACTACCTCACCGACCTGAGCACCAATGGAACCTTCGTCAACGGTTCGGATACCCGGATGGAGCGCAACGGCTCCGTGCAGATCAACGACCACGACAAGTTCCGGATCGGCGACTACGAGTTCGTTGTGGAACTCGGGGACTCCACGGTCGAAGTCCGCGAGGACGTGGAGGAGCCGTTGACGGAAGGCTTCACCGCTTTCGACCAGCCCGTGGCGCCCGCCGCCGACCCCTTTGCCGACGACGACGGGGAAGACCCGTTCGCCGAACCGAAACCCGCGCCGCCCGCGCCGGCTTTCGACGATCCCGACGAACGCGAGATCAACACCCCCCTGTCTCAGCTCGATCACAACGCGCTGGACCGCGGCGTCAATATCGACAGCATCCTGAATCTCGATGACACCGGCGGGAAGCGCTCGCCGCCCCCGGCCGAGTCGGGCTTCGAAGTGATCAACGAACCCATCCGGGAAGCACGGCCGGTATCACAGCCATCGGCCGGTAGCGGTCTCGAGATCCCCGACGACTGGGACGAAGCAACGGGAATGATGCGATCCCCGCTGGCGGAGAAGAAGGAAGAGGATACCGACGAGGATTTCGGCTTTTCCGACGACTGGGGCGATACCGGCACCTTCAGCGCCGACATCGACGAACCGTTCGGTTCCGACGACGCCCTGGAAAGCGACCCGGCGCCGGAGCCCCCTGCCCCGCCGCCCTCCGCGCCCGAGCCCGAGCCCGAACCCACGCCGGCGCCCGCCCCGCCGCCACCCGCGCCGGAACCGCCACGGGCCGCGGTGGAACCCGAACCGACACCACCCGCGAAGCCGGCGCCCGCCGCGAAGCCCGCACGCGAGCCCACCCCTGCCCCGAAACGCCCGACGCCGGGCGCGGACTCGCCGTTGGCGGCCTTCGCCCGGGGTGCGCGCGTCGATGCCGCCGGCCTGAACGTGGATGACCCGGACGCCTTTTTCGAATTCCTCGGACGGGTGAACCGGGCCTTTACCGAGGGCATCATGCGTGCATTGAGCGGACGGGCCTCGGTGAAGAACGAGTTCCGCCTGGACCAGACCATGATCCGGCCCTCGGAGAACAACCCCCTGAAGTTCTCGCCCATGCCGGATGACGCGCTGGTGCGCATGCTGCGCCAGAACGACGACCACGCCTACCTGCAGGGCGAGAGCGCGGTCAAGGAAGCCTTCGAGGACATCAACGCCCACCAGATCGCCGTGATGGCCGGCATGGAAGCGGCATTGCAGGGACTGCTGCGGCGGTTCAGCCCGGAAACCCTGGAGAAGAAACTCGTGTCCAGCTCCGTGCTGGACAACATCCTGCCGGGCGCAAAAAAAGCCAGATACTGGGATATATTTAATTCCATGTACGCCGAGATCGCGAACGAGGCGGAAGACGATTTCCAGCAACTCTTCGGTTCGGAATTCATCCGCGCTTACGAGGCGCAAATGAGCCGACTCAAGAACAAGACCTAG",
      "translation": "MPISLRISSYQRLTPGQQERFWSDAGAFTIGRGKDNDWVMPDPQRFLSGVHCRVERKGDDYYLTDLSTNGTFVNGSDTRMERNGSVQINDHDKFRIGDYEFVVELGDSTVEVREDVEEPLTEGFTAFDQPVAPAADPFADDDGEDPFAEPKPAPPAPAFDDPDEREINTPLSQLDHNALDRGVNIDSILNLDDTGGKRSPPPAESGFEVINEPIREARPVSQPSAGSGLEIPDDWDEATGMMRSPLAEKKEEDTDEDFGFSDDWGDTGTFSADIDEPFGSDDALESDPAPEPPAPPPSAPEPEPEPTPAPAPPPPAPEPPRAAVEPEPTPPAKPAPAAKPAREPTPAPKRPTPGADSPLAAFARGARVDAAGLNVDDPDAFFEFLGRVNRAFTEGIMRALSGRASVKNEFRLDQTMIRPSENNPLKFSPMPDDALVRMLRQNDDHAYLQGESAVKEAFEDINAHQIAVMAGMEAALQGLLRRFSPETLEKKLVSSSVLDNILPGAKKARYWDIFNSMYAEIANEAEDDFQQLFGSEFIRAYEAQMSRLKNKT",
      "product": ""
     },
     {
      "start": 6812,
      "end": 7306,
      "strand": 1,
      "locus_tag": "ctg314_8",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,812 - 7,306,\n (total: 495 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_8\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAAGGAAGGATCGAAGTCCATGGCCAGAACTGGGGCCATCGCGCGGTGGTGTCTCGCCGCAGTGCTGATGGCCGGGCTGGCCGCCTGTGGCGGCGCCCCGAAAAAGCCGGACCCCATCACGGTCAGCATCCAGGCCGCGCCGGACGTGAATCCGGACCTCCAGGGACGGCCGTCTCCCATCGTGCTGCACATCCTGGAACTGAAGTCCGCGGAGACCTTCAACAGCCTCGATTACGTCAGCCTCACGGATCCTTCGGGCGCGGCGCTGGGCGCTGATCGACTGAACGGGATTCAGCTGGTCGTGGCGCCGGGCGGTTCCAACCTGCAGACGCTGGAAATCGACTCCGGGACTTCCGCCATCGGATTCGTCGCGGGCTACCGCGACATCGACAACGCGAGCTGGCGCCAGGTCGTGCCCATCGTGGCGGGAACCACCACCACGATCGCGGTGAACCTGGGGCAGTTCCAGGTCACCACCTCCTCCCAGAACTGA",
      "translation": "MKEGSKSMARTGAIARWCLAAVLMAGLAACGGAPKKPDPITVSIQAAPDVNPDLQGRPSPIVLHILELKSAETFNSLDYVSLTDPSGAALGADRLNGIQLVVAPGGSNLQTLEIDSGTSAIGFVAGYRDIDNASWRQVVPIVAGTTTTIAVNLGQFQVTTSSQN",
      "product": ""
     },
     {
      "start": 7320,
      "end": 8654,
      "strand": 1,
      "locus_tag": "ctg314_9",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,320 - 8,654,\n (total: 1335 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_9\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCCTGGACATCCAAGATCATCTGGTCGGAGGGCATGTTTCTCCGACCCCAGCATTTCCAGCAGAACGACCGCTACTTCGAGGCCCTGCTGGAGAATCGCACCGCGCCCCTGCGTCCGTACGCCTGGGGCGTGGTTGAACTGACACTCAGCCAGGAGGCCCTGAGCCTGGGGAAAATCGAGATCGCTTCCTGCCGGGCCGTCATGCCCGACGGGACCGCGGTCGTGATCCCCGGAGCCGACGCGGCGCCGCCGCCCATGGTGCCGGACAAGAATCTCAAGAACGAGAACGTCTACCTCTGCCTGCTGGAACGGCGGCCCAACGCCACCGAATCGAGCCGGGAGGAAAGCGACCGGGAAGAGACCCGCTTCGGCGTCCAGATTTCCGACGTGCGTGACACCAGCCTGCCCGAGGACAGCGTCGCGCCCATCGAACTGGCGCGGCCGCGACTGCGGCTGCTCGGCGAGCACGACGAACGGGAGGAGTTCGCCTGCATTCCCATCGGGCGACTGGTGGAGGTGCGCGCCGACCAGCAACTGGTGATGGACGCCGAGTACATCCCCACCTGCATGGACTGCCGCAACGAGGTCACGCTCAACGGATACATCAAGGAACTGCAGGGGCTGCTCAAGCACCGCGCGGAGGAAATCGCAGCGCGCCTGGCCGCCGAAGGCCGGGGCGGCACGCCCCAGGTCCAGGATTACCTCATCCTGCAGGTGGTGAACCGCTACGAGCCGCTGTTCGCCCACCTGGCGTCCCTGCCGCACTACCACCCCGAGTCGTTGTTCCAGGTCTGCCTCATGCTGGCCGGTGAACTGGCGACCTTCCTGGACGAGGGCAAGCGGCCCAAGAACCTGCCGGACTACGTGCACACGGACATCGCCGCGGGCTTCACGCCGCTCATGCACGAGCTTCGCAACCTCCTCGGCCACATCATCGAGTCCAGCGCCGAACAGCTGGTGCTGAAGGAATACACCAAGGTCGGCATCCACCTCGCGGTGGTGAACGACAAGGGCCTGTTCGAGAACGCGGATTTCGTGCTCGCGGTCAAGGCGGCGATGCCTTCCGAAACGCTGCGCTCGCAGTTCCCGCGCCAGGCGAAGATCGGGCCGAAGGAAAAGATGAAGACGCTGATCACCTCGCAGTTGCCGGGCATCGGGCTCGAGTCCCTGCCGGTGGCGCCGCGGGAAATTCCCTTCCATTCCGGGTTCAACTATTTCCGCCTGGACCGGACGGCCGAGCTGTGGCGTGAGCTGCCCACCTCGGGCGGTCTCGGTCTGCACCCGGGCAAGTTTCCGGACCTCGAGCTCGAACTCTGGGCCATCAGGGGCTAG",
      "translation": "MSWTSKIIWSEGMFLRPQHFQQNDRYFEALLENRTAPLRPYAWGVVELTLSQEALSLGKIEIASCRAVMPDGTAVVIPGADAAPPPMVPDKNLKNENVYLCLLERRPNATESSREESDREETRFGVQISDVRDTSLPEDSVAPIELARPRLRLLGEHDEREEFACIPIGRLVEVRADQQLVMDAEYIPTCMDCRNEVTLNGYIKELQGLLKHRAEEIAARLAAEGRGGTPQVQDYLILQVVNRYEPLFAHLASLPHYHPESLFQVCLMLAGELATFLDEGKRPKNLPDYVHTDIAAGFTPLMHELRNLLGHIIESSAEQLVLKEYTKVGIHLAVVNDKGLFENADFVLAVKAAMPSETLRSQFPRQAKIGPKEKMKTLITSQLPGIGLESLPVAPREIPFHSGFNYFRLDRTAELWRELPTSGGLGLHPGKFPDLELELWAIRG",
      "product": ""
     },
     {
      "start": 8660,
      "end": 10009,
      "strand": 1,
      "locus_tag": "ctg314_10",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_10</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_10</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,660 - 10,009,\n (total: 1350 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_10\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCTGAACACGACGACCCGTTCTTCGATCCAGACGAAGAAAAGACCATCATCAAGCCCAGTCCCGGGGGGCGCCGGCCGACCGCCCCACCCCCCGGCGGCGGGGCGCCGCCGCCGCCCTCGACACCGCGCGGCCGGGTCGAACTGAAAGGCCGCCAGGGCCTGAACCCCCTGGAGCGTTCCGCGGCCATCCTGCTCAACCTGCTCAGCCAGATTCGCAACACGCCGACGCACCCCAACCCGGAAGGACTGCACCAGCAGCTCGCCGGTGAAATCACCCAGTTCGAACGGCGCGCCCAGGCCGAGGGCATTCCGCCGGAAACCATTTATATCGCACGTTACGCCCTGTGTTCGACCATCGACGAATTCGTGATGGCCACCCCCTGGGGCGCCCAGAGCAACTGGTCACGCCAGAGCCTGCTGAGCCTGTTTCACAAGGAAACCTTCGGCGGTGAGAAATTCTTCCGGCTCCTGAACAAGCTGGAGCAGGACGCGGCCCGCAATCTCGACCTCCTGGAACTGTTCTACCTCTGTCTCGCCCTCGGTTTTCGGGGCCGCTACGCGGTATCCAATGACGGGATCAATGAGCTGGAACGCGTCCGGGAAAATCTCTACCACGTCATCCGCAACCACCGCGGCGAGTACGAGACGGGCCTGTCGCCGCATTGGGAAGGACTGGACAAGCACGCCACGGCGCGGGGGCCCCTGGTGCCCGCGTGGCTGGCCGCCTGTATCGCGATCCTGCTGCTGGTGGGTCTGTTCAGTCTCTGGCGCTTCAGTCTCAGCGGCCATGCCGACCCGGTGCACGCCGAAGTGATGGGCATCGGCCGCGAGGCCGGCCTCATCCCCAACCACATCCTGGCACCCGAGCCGGTGATGAACATTCCCGACCCCGAACCACCACGCTTCTCCCTGGCGCGTTTCCTGGCGCCCGAGATCCAGGCCGGCAAGGTCAGCGTGGACGAGTTCCCCGACCGCATGGTGGTGTCGATCAAGGGCGATGGCCTGTTCGAGTCCGGCAGTGAACGGATCAAGTCGGAGTACCTGCCCATCCTGCGTCGCATCGGCGAGGGACTGGAGCAGACCACGGGCCGTGTCCGGATCGTCGGCCACTCAGACAACGTCCCCATGCGCGCCAGCGGGCGTTTTCCCTCCAACTTCGAACTGTCCCAGGCAAGGGCGGAATCGGTGGTGACCGTGATCCATGAACAGATGCTCGACCCGGCGCGAACCGTTGCCGAAGGGCTCGGCGAAACGCAGCCCATCGCCAGCAACGACACGCGTGAGGGCCGGGCCCAGAACCGACGGGTCGAAGTGGTCGTGATGCAGCGCGCCGGGGGGGCAGGCTGA",
      "translation": "MAEHDDPFFDPDEEKTIIKPSPGGRRPTAPPPGGGAPPPPSTPRGRVELKGRQGLNPLERSAAILLNLLSQIRNTPTHPNPEGLHQQLAGEITQFERRAQAEGIPPETIYIARYALCSTIDEFVMATPWGAQSNWSRQSLLSLFHKETFGGEKFFRLLNKLEQDAARNLDLLELFYLCLALGFRGRYAVSNDGINELERVRENLYHVIRNHRGEYETGLSPHWEGLDKHATARGPLVPAWLAACIAILLLVGLFSLWRFSLSGHADPVHAEVMGIGREAGLIPNHILAPEPVMNIPDPEPPRFSLARFLAPEIQAGKVSVDEFPDRMVVSIKGDGLFESGSERIKSEYLPILRRIGEGLEQTTGRVRIVGHSDNVPMRASGRFPSNFELSQARAESVVTVIHEQMLDPARTVAEGLGETQPIASNDTREGRAQNRRVEVVVMQRAGGAG",
      "product": ""
     },
     {
      "start": 10009,
      "end": 13530,
      "strand": 1,
      "locus_tag": "ctg314_11",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_11</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_11</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,009 - 13,530,\n (total: 3522 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_11\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGGGCCCCTCATGTCCATGCTGATCACCTATGGCGTGTTCTCCGGGCTGGCCGTGGGCGCCCTGGCGATCATGGTCTGGTACTACGGGCCGCTGATCCGCTTCGGCAGCTTTGACCCACTAGGGCCGCCGGTGAACCGGATCATCGTGATCGTCGTCCTGATCCTCGGCTATTTCCTGGTTCGCGGGTTCAAGGCCTGGCGCAACCGCAAGAAGTCCGAGGCGATCTCCAAGGACCTGGCCAAGGGCGCCGCGGCCGCGGACCCCACGGCCGAGCAGTCCGCCGAGGAAATGGCCGAACTCAAGGGCCGCTTCGACGAGGCCCTGTCCGTCCTGAAGAAAAGCGAGGTCGGCGGCAAGAAGATCAAGTCCATCTACCAGCTGCCCTGGTACATCATCATCGGTCCCCCGGGGTCCGGAAAGACCACCGTGCTGGTCAATTCCGGCCTCCAGTTCCCGCTGGCCGAAAGCCTGGGCGACCAGAAGGTCCAGGGCGTGGGCGGTACGCGTTACTGCGACTGGTGGTTCACCGACGAGGCGGTGCTGATCGACACGGCCGGCCGCTACACCACCCAGGACAGCAACCAGGATGTCGACAACTCGGCCTGGCTGGGCTTCCTCAAGCTGCTCAAGAAGCACCGCGCGCGGCGGCCCATCAACGGCATCATCCTGGCCATCAGCACGGAAGAGCTGCTGCGCCAGAGCGAGCGCGACAAGGAGCGCACGGCCAAGGCCATCAGCGACCGAATCCAGGAGCTCTACGATCAGCTGGGGGTGCGGTTCCCGATCTACCTGATGTTCACGAAGTCCGACCTGCTGGCCGGCTTCATGGAGTTCTACGGCGACCTGGACCGCAATGAGCGGGCGCAGGTCTGGGGCTTCACCCTCGGGCTCGACGAGGACCCGCTGAAGGCCTTCGACGGCGAATTCTCCGCGCTGCAGCAGCGCATGGAGGAACGGCTGGTGCAGCGCCTCCAGGAGGAGCGCGACGTCCAGCGCCGCGAGCTGATCTACAACTTCCCCCTGCAGATGGCCTCTTCCCGCGAAGCCATCGAGCAGTTCCTGGGCCAGGTGTTCAAACCCAGCCGCTTCAAGACCACGCCCCTGCTTCGCGGCGTGTACTTCACCAGCGGCACCCAGGAGGGCACGCCCTTCAACCGGATCATGAGCCAGCTGGCCAGCAACTTCAGCCTGAGCCGCTCGGCCACGCAGTCCATGCCCTCCAAGGGCAAGGCCTTCTTCATCCAGGACCTGATGATGAAGGTGATCTTCGGCGAATCGGGCCTGGCCGGCGCGAACCTGAAGGTCGAGCGCATGTACGGCATTGCGCGCAAGGCCGGCTGGGCGGCGCTGATCGCCGTCCCCATCCTGCTGAACATCGCCTGGTGGATCAGCCATGGCGCCAACAAGGGCCTGATCGCCGATGTCGACCAGTCCGCCGTGGAAATCCGCGAGACCATCGACGACGTCAAGCCCAGCGATGCCTCCATGCGCGGCATCCTGCCCCTGCTCAACGAGGCCCGGGCGCTGCCCGTGGGCTACGAGGCGAGCTTTGAGTCCCCGCCCCTGCGCATGCGCTGGGGCCTGTACCAGGGGGACCGGCTGGGTGAGAACGGCACCATTCCGGCCTACAAGCGCATCCTCGAACAGGCGTTCCTGCCCCGACTCATGATCGGCATGGAGCAGGACCTGAACGCGAGCATGAACGACCCGAACCGGGTCTACGAACTGCTGAAGGCCTACCTGATGCTGGGCACGCCCGACCGCCTGGACGAGGACTACGTCCGCGAGGTCGTCACGGCCGACTGGGACAGGGACCTGGCCCGCGTCATGACCAACGAGCAACTGGACGAGCTGAAGGGGCATCTCGACGCCCTGCTCGACCTGCAGCCCCTGTCACCGCCCTTCGACCTGGACCGCAACCTGGTGACCAGCGCGCGCATCGTGCTCGGCCGGACCACCCTGGCCCAGCGCATCTACTCCGTCATCAAGAGCGAGCACATCGACGAGGGCGAAACCTACTCTCTCGGCACCATGACCGGCCCCGACGGCCCCCTGGTGTTCACCCGCTCCAGCGGCGCGCCCTTCAACAGCGGCGTGCCCGCGTTCTTCTCGCCCCTGGGCTACCAGGAGATGTACCTGCCGGCGGAAGAGGACGCCATCGAGCAGGTCGAGGACGAGGCCTGGATCTTCGCCACGGAGGCCACGGACGCCGTCCAGGTCTCGGAAACGGACCTGATCAACGGGATCCGGCTGGCCTACCTCGAGGACTACGTTCGCAGCTGGATCGATTTCCTGGAAGACGTGCGCATCCGGCCGTTCAGCGGCATGGAACAGGCCGCCAGCATCCTGCTGGTGCTCTCCGGCGATGCCTCGCCACTGCGGCAGTTGCTGGTGAACGTGTCCAACGCCACCCGCCTCACGCCCGAGGAGGTCATACGTGGCGCCCAGGAGGACGCCTCCCTGCGCGAGAAGTTCGAAGCCATCCTGCGCAGCCAGGGCACCAACCCCGACCTCGTGGACCCGGCCATGGTGGACCGGAGCTTCGCCGGCGTGCATCAACTCGCCGGGGGCGCCGACGACGGCAGGCCCTCGCCGCTGGACACGCTGATCGCGGACCTGGACAACCTGTACCGCTACATCGAGACCCTGTCACGGGCCTCGGCCGACGCGCTCATCAGCGACATGCAGAACGAGGCGAGTTCCGCCCTCACGGCAGTGCGCCAGCGGGGGCAGCGCACGCCGGCGCCCATCCGGGACTGGGTGCTGGACGTGGTCTCGCAGAGCGACAACCTGATCGCCGGGGACGCGTCCACGGCCATCCAGGCCGCCTGGTCCGCGGAGGTGGCGCCGTTCTGCCGCCAGGCCATCAATGGCCGGTACCCCTTCAATCGCGACAGCACGCAGGCCGTGCCGCTGTACGATTTCGGCACCTTCTTCGCGCCGAACTCGGGCATTCTCGACACCTTCTTCAACAAGTACCTGGCCCAGGTGGTGGACACCACCCGGCCGACCTGGGCGTTGCGCCCGGCGTACGCCAACACGGTCCGCATCAACCCGTCTTCGCTGCGCTACATGCAGCAGGCGAAGAACATCCAGCGGGCCTTCTTCTCCGGCGGTGGCGCCCTGCCCTCGGTCACCTTCGAGATGCGCCCGGTACGCCTGGATGCGGCCGCCACGAACTTCACGCTCAGCATCAATGGCGAGAGCACCAGCTACAGCCACGGCCCCATCATCGCCAAGACCTTCCGCTGGCCGGGTGACGCCGTCCAGGGCATGGTGGGTTACCAGTTCGTGCCGGCGAGCAGCGCGGGCCGCTCGGGCAATTCGGAAACCGGCCCCTGGTCCCTGTTCCGCATGTTCGACCGCTCGGGGCTGCAGGCCTCGGGCAACTCGGAAGCCTTCCAGGTGCGGTTCGAACTGGACGAGCGCTGGGCGGAGTACGAGATCCGCGCCGCGAGCGCCTTCAACCCCTTCGACCTGCGCGACCTGCGCAGCTTCCGCTGCCCGGACCAGCTGTGA",
      "translation": "MGPLMSMLITYGVFSGLAVGALAIMVWYYGPLIRFGSFDPLGPPVNRIIVIVVLILGYFLVRGFKAWRNRKKSEAISKDLAKGAAAADPTAEQSAEEMAELKGRFDEALSVLKKSEVGGKKIKSIYQLPWYIIIGPPGSGKTTVLVNSGLQFPLAESLGDQKVQGVGGTRYCDWWFTDEAVLIDTAGRYTTQDSNQDVDNSAWLGFLKLLKKHRARRPINGIILAISTEELLRQSERDKERTAKAISDRIQELYDQLGVRFPIYLMFTKSDLLAGFMEFYGDLDRNERAQVWGFTLGLDEDPLKAFDGEFSALQQRMEERLVQRLQEERDVQRRELIYNFPLQMASSREAIEQFLGQVFKPSRFKTTPLLRGVYFTSGTQEGTPFNRIMSQLASNFSLSRSATQSMPSKGKAFFIQDLMMKVIFGESGLAGANLKVERMYGIARKAGWAALIAVPILLNIAWWISHGANKGLIADVDQSAVEIRETIDDVKPSDASMRGILPLLNEARALPVGYEASFESPPLRMRWGLYQGDRLGENGTIPAYKRILEQAFLPRLMIGMEQDLNASMNDPNRVYELLKAYLMLGTPDRLDEDYVREVVTADWDRDLARVMTNEQLDELKGHLDALLDLQPLSPPFDLDRNLVTSARIVLGRTTLAQRIYSVIKSEHIDEGETYSLGTMTGPDGPLVFTRSSGAPFNSGVPAFFSPLGYQEMYLPAEEDAIEQVEDEAWIFATEATDAVQVSETDLINGIRLAYLEDYVRSWIDFLEDVRIRPFSGMEQAASILLVLSGDASPLRQLLVNVSNATRLTPEEVIRGAQEDASLREKFEAILRSQGTNPDLVDPAMVDRSFAGVHQLAGGADDGRPSPLDTLIADLDNLYRYIETLSRASADALISDMQNEASSALTAVRQRGQRTPAPIRDWVLDVVSQSDNLIAGDASTAIQAAWSAEVAPFCRQAINGRYPFNRDSTQAVPLYDFGTFFAPNSGILDTFFNKYLAQVVDTTRPTWALRPAYANTVRINPSSLRYMQQAKNIQRAFFSGGGALPSVTFEMRPVRLDAAATNFTLSINGESTSYSHGPIIAKTFRWPGDAVQGMVGYQFVPASSAGRSGNSETGPWSLFRMFDRSGLQASGNSEAFQVRFELDERWAEYEIRAASAFNPFDLRDLRSFRCPDQL",
      "product": ""
     },
     {
      "start": 13527,
      "end": 14276,
      "strand": 1,
      "locus_tag": "ctg314_12",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_12</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_12</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,527 - 14,276,\n (total: 750 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_12\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GTGAGCGAACTCGACCGCGTCTCCGACCCGGGGTTCTACGGCAAGCTGCCGGCCTACGGGGACTTCATCCAGAAGCGCCTGCCGCGCGATTTCACCGCGCCCTGGGACGACTGGTTGCAGGCCGGCATCGCCGCCGCCAAGGAACGCCTTCCGCAGGAGTGGCTGACCTTCTATCTCAGCTGCCCCGCCTGGACCTTCGTCCTGGGGAATGGCATCTGTGGGGAACAGGCCGTGGCGGGGGTGACCATTCCCAGCGTCGACAAGGTGGGGCGTTACTTCAACTTCACCCTGGCCGCGCTGCTGCCGGCGGGGACTTCTCCCGCCCTCTTCCTGGCCCGGCACCACGCCTGGCTGGGTGACCTTGAGGACCTGGCGCTGACGGCCCTGGGCGACGAATGGGACCAGGACCGCATCGACCAATCGCTCAATGAACTGCCGACACCGGAGGTCGAGGGCCTGCGTTCACCCGGTACGCTGGAACGCGGCGACGACTGGATGCGCCTGGCGTTCACCGGCGCCGACACGGCCACCGGCCGCCTCGACGCACTGCTGCATGCCCTGGTCCAGGAGGGACGGGAAGGCAGCTACGGCCTGTGGTTGCAGGACGGATCCAACCAGGTGGGCCCACAGCTGCTGTGCTGCCGTCACCTGCCGGCCACGTCCCTGTTCCTCGACATGATGGTCAGCACGGACGCTGAAGACCCCAAGAGCGAGGGCGACGATGTCCTCGACGAGTTCCTGTCCCAATGA",
      "translation": "MSELDRVSDPGFYGKLPAYGDFIQKRLPRDFTAPWDDWLQAGIAAAKERLPQEWLTFYLSCPAWTFVLGNGICGEQAVAGVTIPSVDKVGRYFNFTLAALLPAGTSPALFLARHHAWLGDLEDLALTALGDEWDQDRIDQSLNELPTPEVEGLRSPGTLERGDDWMRLAFTGADTATGRLDALLHALVQEGREGSYGLWLQDGSNQVGPQLLCCRHLPATSLFLDMMVSTDAEDPKSEGDDVLDEFLSQ",
      "product": ""
     },
     {
      "start": 14296,
      "end": 15057,
      "strand": 1,
      "locus_tag": "ctg314_13",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_13</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_13</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,296 - 15,057,\n (total: 762 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_13\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAACATCCTTTCAAAGGCCGCGACCCACGTCGGCATGGTGCGAGAACTCAATGAGGACTCCTTTCTCGACCTCGGCGAGGAAGGTGTCTGGGTGGTCGCCGACGGCATGGGCGGCCACGAGTCCGGAGAGGTGGCCAGCCAGGCCGTCGTCGGCGAAGTGGGGCGCATGTCACGCTCCGACAGTTTCGAGGCGTCACTGGAGCACCTACAGCAACACATCCTCGACGTGAACGAGGCCCTGGTGAACGATGCGGAGCGGTTCAGCCGCGACCGCCAACCGGGGAGCACCATCGTCGCGCTGCTGATCCAGGACGGCCAGGGCGCCGTGGTCTGGGCCGGCGACAGCCGTATCTACCGGCGGCGGTCCGACACCTTCGAGCAGCTCACGCGCGACCACAGCCATGTCCAGGAACTGCTCGACAACCACCTGATCCGCCCGGAAGAGGCGGAAAAACACCCCATGTCGAACGTGATCACCCGGGCCGTCGGCATCGACGTTCCCCTGGAAATCGACACCCGCACCTTCCAGGTCCTGGACGGCGACCAGTTTCTGCTGTGCTCCGACGGGCTGACGCGGCTGGTCGAGGACCGGGAAATCGACGAAATGATGAACAACAGCGACAGCGAGGAAGTCGTCCAGTCCCTGTTGCACACGGCCCTGGTCCGCGGCGCGCCGGACAATGTCACCCTGATCTACGTGGCCTGCGGAGACATCGGCGACGGCTCGACCGTCGTCATGAACATCGACGACCTGCTCTGA",
      "translation": "MNILSKAATHVGMVRELNEDSFLDLGEEGVWVVADGMGGHESGEVASQAVVGEVGRMSRSDSFEASLEHLQQHILDVNEALVNDAERFSRDRQPGSTIVALLIQDGQGAVVWAGDSRIYRRRSDTFEQLTRDHSHVQELLDNHLIRPEEAEKHPMSNVITRAVGIDVPLEIDTRTFQVLDGDQFLLCSDGLTRLVEDREIDEMMNNSDSEEVVQSLLHTALVRGAPDNVTLIYVACGDIGDGSTVVMNIDDLL",
      "product": ""
     },
     {
      "start": 15150,
      "end": 15710,
      "strand": 1,
      "locus_tag": "ctg314_14",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_14</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_14</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,150 - 15,710,\n (total: 561 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_14\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGATTCTAGGCCTGGTGCTGTTCATCGGCAGCCACTCCGTGGCCGTCGTCGCTCCCGGCTGGCGCGACCGTTTCGCCGACAAGCACAAGGCGGCCTGGAAAGCCCTGGTGGTCTTCGTCGCCCTCGCGGGTGTGGTCGGCATCGTGAAAGGCTACGCGGAAGCCCGCCTGGATCCGGTGCTGCTCTGGGTGCCGCCCACCTGGCTGCGCCACGTGGCGGCCCTGCTGCTCCTGCCGGTGTTCGTGTTCTTCCTGGCGCCCTACTTTCCGGGCCGCATCAAGACCACCCTGAAGCACCCCCAGCTGGTCGCGCTCAAGCTCTGGGCCCTCGCCCACCTGCTGGTGAACGGCACCCTGGCGGACATCGTCCTGTTCGGCAGCCTGCTGGCCTGGGCCGTGGTCTGCCGCATCTCCTACCGCTGGCGGCCCGCCAACGAGACCCCGGTGGTGACCCACAGCCGGGCCAACGACTTCATCCTGCTGGCCCTGGGGCTGGCGCTCTACGTGCTTTTCGTGCGCTGGTGGCACCTGGCCTGGATCGGCGTGGCGCCGTTCGGCTGA",
      "translation": "MILGLVLFIGSHSVAVVAPGWRDRFADKHKAAWKALVVFVALAGVVGIVKGYAEARLDPVLLWVPPTWLRHVAALLLLPVFVFFLAPYFPGRIKTTLKHPQLVALKLWALAHLLVNGTLADIVLFGSLLAWAVVCRISYRWRPANETPVVTHSRANDFILLALGLALYVLFVRWWHLAWIGVAPFG",
      "product": ""
     },
     {
      "start": 15712,
      "end": 17889,
      "strand": -1,
      "locus_tag": "ctg314_15",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_15</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_15</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,712 - 17,889,\n (total: 2178 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PF00561<br>\n \n  biosynthetic-additional (rule-based-clusters) Peptidase_S9<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_15\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGTCCGATGAGCTCGATATTGCACGGCTCGAGGCCAGCCCGGGCCTCGACGGCCCCGTGGCCCGGGGCGTGGAAATCGCCCCGGACGCTTCCCGTGTCACTTTCCTGCGCGGCCGCGAGGACGACCGGCAGCAACTCGACCTGTGGGAATTCCACATCGCCGACGGGGTGGAGCGCCGGCTGGTCGACAGCCAAGCCCTGCTGGGCGCGCCGGAGGTCCTGGACGAGGTCGAGAAGGCGCGCCGGGAACGCCAGCGCGTGTTCTTCACCGGCATCGTGGAATATGCGTGGGCCCCGGACGGCCGGTCACTGCTCTTTCCGCTGGGCGGCGACCTCTACCACCTGCCCCTGGGGGGCGAGCCCCGCCGCCTGACGGACACGGAGGCGACGGAAACCGACGCCCGGGTCTCGCCCGGCGGGCGCTATGTCTCCTTCATCCGCGACCGGAACCTGCACCTCGTCGACCTGGCATCCGGCGATGCCCGGGCCCTGACCGATGGCGCCACGGACACGGTGTCCTTCGGCATGGCCGAATTCGTGGCCCAGGAAGAGATGTACCGCTTCACCGGCTACTGGTGGTCGCCGGACGATCGCCGGCTGGCCTTCACCCGGGTGGACGAGGCGGGCGTGAGCCTGGTCAACCGTTACGAGATCGGCGCGGACGGTGTCACCACGGTGCCCCAGCGCTATCCCTTCGCCGGCGAAGCCAATGCCCGGGTGCAGCTGTTCCTCCTGGACCTGGCGACCGGTGAACAGCGCGAAGTGGCGTTCGACGCCTCGGGTGACGACTACCTCGCCCGGGTCGATTTCGCCCCCGACGGCACCCTGGTGTTCCAGCGCCAGTCCCGGGACCAGCGCCGGCTGGACCTGGTGTTCGTCGACCCGGTCACGCTCGAGCAGACCGTGGTCCTGACGGAACGCGCCGACACCTGGATCAACCTGCACAGCGATCTGCACTTCACCGCCGACGCGCAGCGCTTTCTCTGGACTTCGGAGCGCGACGGTCAGCGCCATCTCTACGTGTTCTCGCGGGATGGACAGTTGCTGCGACAGCTCACGGACGGCGACGGGTCCGTGGCGGAAACCGGCCGCGGCGGCGGGGGCGTGCGCGCGCTCGACGAAGCCAACGGCCTGGCCTGGTTCCTGGCCGGACGCGAGACGCCGATCGAGCAGCATCTCTACCGGGTTCCACTGGATGGCTCGGCCGGGCCGGAGCGCGTCACGGAGGCCGGTGGCTGGCACGAAGCCACGGTCGCCCGCGACGGGTCCTTTTTCGTCGACCGGGGCCAGTCCCCGGACCGTCCTCCCTACACGGCCATCCGCGACGGGGAAGGCGGCCTGCTGGCCTGGGTGCTGGAAAACGCGCTGGACGACTCGCATCCCTATCACCCCTACCTGGCCGGTCACCGCCCCGCGGAGTTCGGCACCCTGCCCGGGGCCGACGGCACGCCGCTGTACTGGGAGATGATTCGACCGGTGGGCTTCGATCCTTCCGGAAAGCACCCGGCGGTGGTGTTCGTCTACGGCGGGCCGGGCGGCGCCCAGGTGCGTCGCGACTGGACCGTGGATTTCCGCCAGGTGCTCGCCCGGGAAGGCTTCGTGGTGTTCACCGTGGACAACCGGGGGACGGGCGGGCGAGGGACGGCCTTCGATGCCCCGATTCACCACCGGCTGGGCTTCGCCGAACTGGAGGACCAGGTCGCGGGGGTCGACTGGTTGGCGCAGCAGCCCGGCGTGGACGGCGAACGCATCGGTATCTACGGCGGTTCCTACGGCGGCACCATGACCCTGCTGTCCCTGTTCCGCGCCCCTGAGCGCTTCGCCGCGGGCGTCGCCCTGGCCCCGGTGACCGACTGGCGCCTCTACGACACCCACTACACGGAACGCTACCTGGGTGATCCGGCGGCCGGCGACGCCTACGAGATCACCAGCCCGATGCGCTATGTCGACGGCCTGGCGGATCCACTGTTGCTGGTGCACGGCATGGCCGACGACAACGTGTTCTTCGACCACAGCGTCAAGCTGATGGCCAGCCTGCAGGGCGCCGGCAAGACCTTCGAACTGATGACCTATCCGGGCAAACGCCACCGCATCACCGGTGAGGCGGAACGCACCCACCTGTACACGATGATGCTGGAATTCTTCCGGCGCCACCTCGCACCGGCGGAAGAGGGTTGA",
      "translation": "MSDELDIARLEASPGLDGPVARGVEIAPDASRVTFLRGREDDRQQLDLWEFHIADGVERRLVDSQALLGAPEVLDEVEKARRERQRVFFTGIVEYAWAPDGRSLLFPLGGDLYHLPLGGEPRRLTDTEATETDARVSPGGRYVSFIRDRNLHLVDLASGDARALTDGATDTVSFGMAEFVAQEEMYRFTGYWWSPDDRRLAFTRVDEAGVSLVNRYEIGADGVTTVPQRYPFAGEANARVQLFLLDLATGEQREVAFDASGDDYLARVDFAPDGTLVFQRQSRDQRRLDLVFVDPVTLEQTVVLTERADTWINLHSDLHFTADAQRFLWTSERDGQRHLYVFSRDGQLLRQLTDGDGSVAETGRGGGGVRALDEANGLAWFLAGRETPIEQHLYRVPLDGSAGPERVTEAGGWHEATVARDGSFFVDRGQSPDRPPYTAIRDGEGGLLAWVLENALDDSHPYHPYLAGHRPAEFGTLPGADGTPLYWEMIRPVGFDPSGKHPAVVFVYGGPGGAQVRRDWTVDFRQVLAREGFVVFTVDNRGTGGRGTAFDAPIHHRLGFAELEDQVAGVDWLAQQPGVDGERIGIYGGSYGGTMTLLSLFRAPERFAAGVALAPVTDWRLYDTHYTERYLGDPAAGDAYEITSPMRYVDGLADPLLLVHGMADDNVFFDHSVKLMASLQGAGKTFELMTYPGKRHRITGEAERTHLYTMMLEFFRRHLAPAEEG",
      "product": ""
     },
     {
      "start": 18005,
      "end": 19972,
      "strand": -1,
      "locus_tag": "ctg314_16",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_16</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_16</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,005 - 19,972,\n (total: 1968 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: AMP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 313.3; E-value: 4e-95)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_16\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGAGCCCGGCAAAGGACACCCTGGGCGGCCTGCTGTCCGCCGCCATCGCCCGTGGACCGCGTTCGGTGACCTTCATCGAGGGCGCGCAGGAAGAAGTCCGCGTTTCCTACGACGACCTCCGCGCCCGCGCCCTGGGCGTGCTGCGTCACTTCCAGGCCGCCGGCCTGGAGCCGGGCGACGAACTGATCCTGTTCACCAACAGCAACGAGCAGTTCGTCGACGCCTTCTGGGCCTGCATCCTCGGCGGTATCGTGCCGGTACCCGTGGCCGTGGGCATCAGCGACGACCACCGCGCCAAGCTGCTGCGGATCTTCGCCTCGCTGCGCAATCCCTGGCTGTACACGGAGCGCAACCTCGCACGGCGCCTGGAGCGCTTCGGGGAAGGTCATGACCGCCTGGCCGAGATTGCCCGCCTGCTCGAGCGAACCCTGGTGGTGGACGACATCGAGGACATCGGCACCCCTGGCCGGGTGCATGCCGCGGCGCCGGACGACGTGGCCTTCATCCAGTTTTCCTCCGGCTCCACCAGCGAGCCCAAGGGCGTGGTGCTGACCCACCGCAACGTGATCACCAACATCCGCGCCATCTGCGAGGGTTACGGCAGCCGCGACGACGACGTCGCCGTCAGCTGGATGCCGCTGACCCACGACATGGGCCTGATCGGTTTCCACCTGTGCATGATCGCGGCCAACAACGACCACCACGTCATGGCCACGAGCCTGTTCGTCCGGCGTCCCCTGTTGTGGATGCAGAAGGCGGCTGAGAAGGGTGCGACCCTGACGTGCTCGCCCAACTTCGGCTACAAGCACTTCCTCAAGGTGTTCGAGTCGAAGGGATTGGACGGCATCGACCTGGGCCGCGTGCGCCTGGTGTTCAACGGGGCCGAGCCCATCTCCGCCGCGCTCGCGCGGCAGTTCCTGGAAGCGCTCGCACCCCACGGCCTGGACCCGGACTGCATGTTTCCGGTCTACGGTCTCGCCGAGGCCAGCCTGGGCGTGACCTTCCCCGAGCCCGGGGCGCCCCTGCGCACCGTGATGGCCCATCGCCACGGCCTGGCCGTCGGGGAACCCTGGTCGCCCGCCGAAGGCGACGACCAGGATGCCGTGGAGTTCGTCCTGCTCGGCACGCCGATCCGCGACTGCCAGGTCCGGCTCTGCGACGACCAGGACCACGTCCTGGAGGAAGGGCGGGTCGGCCACGTGCAGATCCGCGGCGGCAACGTCACGCGGGGCTATTACGGCTACCGCGGCAGGAGCCGGGATGTGTTCGCCGACCTCGACTGGCTGCGGACCGGCGACCTGGGCTTCTTCCACGAAGGCCAGCTGGTGATCACCGGTCGCTCCAAGGACATCATTTTCGTCAACGGCCAGAACTACTACCCCCACGACATCGAGGCCCTGGCGGGGGAGCTCGACGGGCTGGAACTGGGCAAGGTCGTGGCCGCCGGCGTCACCAGCCCTGAAGCGGGCACGGACGAACTGCTGCTGTTCGTGCTCGACCGCGGGGAGGTCGCCACCTTCGCGGACCTCGCGCGCCGCCTGCGGGCCCACGTGGGCGAGACCACGGGCCTGGAAGTCGGCCAGGTCATCCCGGTGACGCGCATTCCCAAGACCACCAGCGGCAAGGTGCAGCGGCACAAGCTGACGGAGGCCTACCTGGACGGGGAGTACGCCCCGGTACTGGCCGAACTCGCGGCCCTGGAGACGGTGACCGAGGAAGACCCGGTCCCGGCCGGCGGCATGGAGCAGGCTCTGGCGCAGATCTGCAACAGCATCGTGGTCGACCGCCCGGTCGGCCTGGACGACAACCTGTTCGAGATCGGCATCAGCTCGCTGGCCCTGGCGCAGATCCACGCCCGCGTGGACGAGCTGTACCCCGGTGAAATGGACATTGCCGACGTGTTCGAGTACCCGACCATCCGCGAGCTGGCCGCCTTCCTGGAAGCGCGGCGCGCCGGCGGCGCCTGA",
      "translation": "MSPAKDTLGGLLSAAIARGPRSVTFIEGAQEEVRVSYDDLRARALGVLRHFQAAGLEPGDELILFTNSNEQFVDAFWACILGGIVPVPVAVGISDDHRAKLLRIFASLRNPWLYTERNLARRLERFGEGHDRLAEIARLLERTLVVDDIEDIGTPGRVHAAAPDDVAFIQFSSGSTSEPKGVVLTHRNVITNIRAICEGYGSRDDDVAVSWMPLTHDMGLIGFHLCMIAANNDHHVMATSLFVRRPLLWMQKAAEKGATLTCSPNFGYKHFLKVFESKGLDGIDLGRVRLVFNGAEPISAALARQFLEALAPHGLDPDCMFPVYGLAEASLGVTFPEPGAPLRTVMAHRHGLAVGEPWSPAEGDDQDAVEFVLLGTPIRDCQVRLCDDQDHVLEEGRVGHVQIRGGNVTRGYYGYRGRSRDVFADLDWLRTGDLGFFHEGQLVITGRSKDIIFVNGQNYYPHDIEALAGELDGLELGKVVAAGVTSPEAGTDELLLFVLDRGEVATFADLARRLRAHVGETTGLEVGQVIPVTRIPKTTSGKVQRHKLTEAYLDGEYAPVLAELAALETVTEEDPVPAGGMEQALAQICNSIVVDRPVGLDDNLFEIGISSLALAQIHARVDELYPGEMDIADVFEYPTIRELAAFLEARRAGGA",
      "product": ""
     },
     {
      "start": 19969,
      "end": 21369,
      "strand": -1,
      "locus_tag": "ctg314_17",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_17</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_17</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,969 - 21,369,\n (total: 1401 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) p450<br>\n \n  biosynthetic-additional (smcogs) SMCOG1034:cytochrome P450 (Score: 350.2; E-value: 3e-106)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_17\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGCCGGTCCCGCCCGGCTCCGGTGTATAATTCGCCGCTTGTATCACGCGGCCCCGTGGGGCCCCGGCGGCAAGCGCGACCCCATGAGCCAGACCCCCCAGACCACGCCCACAGCACCCGGACCGGTGGACCCCCACCCCCTGGACTGCGACGAGGCCACTTTTCACCTGATTCCGCGCCTCGTGGCGGAACATGGCGAAGTGGTGCGCGTGGCCGTGCCCAACCTGGACCGGCCCACCTGGGTGATCGCCGACCCGGCCGACATCCGGCGGGTGCTGGTGAGCAACCATCGCAACTACGTCAAGGGCGTGGGCTTCGAGCGCGTGGAGATGCTGCTGGGCAACGGCATCATCGTCAGCGACGGCGCCTTCTGGCGCCGGCAGCGCACCATGATCCAGCCGGCCTTCAGCCGCGGCAACATGCCGCGTTTCTTCGATATGGTGCGCGAGGTGACCCTGCGCCTGAAGGAAGAATGGCTGGCCGCGGCCCGCGAGGGTGGGGAAATCGACATCACCCGGGCGACCAGCGACTACGCGCTGGAAATCATCCTGCGACTGATCTTCAGCGACGACCTGGAGTTCTTTGTCGACCAGGAAGGCATCAACCCCTTCCTGTTCCTGACCGAGGATCCCTCGCGGGACCTGCGGGTGGCCATGAAATTCCGCCAGTTGCTCAAGCAGGTCCGGGTGCTGATCGAACGACGCCGCGAGACCGGCGAGCGACCGTTCGACCTCTTGTCCATGATGATGGACGCCCGCGCCAGCCGCACCGAGGAAGCCATGAGCGACAAGGAGCTCGTCGACGAGGTCGCCACGCTGATCATCGCCGGACACGAGACCTCCGCCGGCACGCTGAACTGGGCCTGGACGCTCTTGTCCGGCGACGAGGACAGCGCCCGGGCCCTGCGCGAGGAATCGCGACGCGTCTGCCCCGACGGCGAGCTCACCTACGAGCACCTGGAAGAACTGGTCTTCACCCGCCAGGTGCTGGATGAAACCCTGCGCCTCTATCCCCCGGTCTGGCTGTTCACCCGCCGTGCGGTCGAGGCCGACGAACTCGGCGGCCATGCCATCGAGGCCGGGGACAACGTGTTCCTGTCGCCCTGGCTCACCCAGCGGCTCGAGCGCCTCTGGCCGGAGCCGGACGCCTTCCGGCCGGAACGCTTCGCGCCGGGCCGGGACGAGGCACGCGAGGACCAGGCCTTCTTTCCCTTCTCCGCCGGGCCGCGCCGTTGCATCGGCGAATTCTTCTCCTACGTGGAAATGCGGACCCACCTGGCCTTGCTGGCCCCGGTGTTCCGCCTGCGGCTCGTGCCCGGGCAGGACATCGCGCTGGAGCCGGCCATCAACCTGCGCACGAAACACAACCTGCGCATGACCGTGGAGGCCCTGCAGCCATGA",
      "translation": "MAGPARLRCIIRRLYHAAPWGPGGKRDPMSQTPQTTPTAPGPVDPHPLDCDEATFHLIPRLVAEHGEVVRVAVPNLDRPTWVIADPADIRRVLVSNHRNYVKGVGFERVEMLLGNGIIVSDGAFWRRQRTMIQPAFSRGNMPRFFDMVREVTLRLKEEWLAAAREGGEIDITRATSDYALEIILRLIFSDDLEFFVDQEGINPFLFLTEDPSRDLRVAMKFRQLLKQVRVLIERRRETGERPFDLLSMMMDARASRTEEAMSDKELVDEVATLIIAGHETSAGTLNWAWTLLSGDEDSARALREESRRVCPDGELTYEHLEELVFTRQVLDETLRLYPPVWLFTRRAVEADELGGHAIEAGDNVFLSPWLTQRLERLWPEPDAFRPERFAPGRDEAREDQAFFPFSAGPRRCIGEFFSYVEMRTHLALLAPVFRLRLVPGQDIALEPAINLRTKHNLRMTVEALQP",
      "product": ""
     },
     {
      "start": 21502,
      "end": 22275,
      "strand": 1,
      "locus_tag": "ctg314_18",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_18</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_18</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,502 - 22,275,\n (total: 774 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_18\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGACCGACCCACAACGCAGCTACGCGCCAAGCCAGAAGGCCCAGCGCTCGCGGACCACCGGCGAGGAAGCGACCTCGCGCCGGCGCATGTCCGCCGGACGCAAGGTCTGGTACGCCTTCCTGGTGGCGCTGGCCAAGGTGCTGGTCAAGTCGCTGTGGTCCACCTGCCGCGTTGAGAAGGTGATCGGCGCCGAGCACATGGACGCGGCGCTGGCCGCCGGCGAACCCATCATTCCCTGCTACTGGCACCAGATGCACCTGTTCTGCACCCGCTACATGCTGGAACTGAAGGAAGGCGGCCTGAACGTCGGTTTCCTGATCAGCCCCTCGGTGAGCGGCGAGGTGCCCGCGGCCATGGCGCGCTCCTGGGGCGCGGCGGTGGTGCGCGGTTCCCCCACCCGCACCGGCGGGCAGGCCCTGCGCGACATGTACCTGACCGTCCGCAAGGAAGGCGTGTCCCCGGTGATCACCGTCGACGGTCCCAAGGGCCCGGCGGAAGTGGTGAAGATCGGCGCCGTGCTGCTCGCCCGGCTGACCGCCACGGCCATGGTCCCGGTGGCCTGCGGCGCCAGTTCGGCGCTGCTGTGGAACAGCTGGGACCGCTTCATGGTGCCCCGGCCCTTCTCCCGCATCGTCATCGTCGTCGGTGAGCCGCTGCGCGTCCCGGAAGGCACCCCCATCGACGAGCTGGAGCCCATCCGGCTGGAACTGGAACAACGGCTGAAGGACGCCGACCGGCAGGCGAAGGCCTACTTCGACACCCGGCCCGCCTGA",
      "translation": "MTDPQRSYAPSQKAQRSRTTGEEATSRRRMSAGRKVWYAFLVALAKVLVKSLWSTCRVEKVIGAEHMDAALAAGEPIIPCYWHQMHLFCTRYMLELKEGGLNVGFLISPSVSGEVPAAMARSWGAAVVRGSPTRTGGQALRDMYLTVRKEGVSPVITVDGPKGPAEVVKIGAVLLARLTATAMVPVACGASSALLWNSWDRFMVPRPFSRIVIVVGEPLRVPEGTPIDELEPIRLELEQRLKDADRQAKAYFDTRPA",
      "product": ""
     },
     {
      "start": 22366,
      "end": 23319,
      "strand": 1,
      "locus_tag": "ctg314_19",
      "type": "other",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_19</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_19</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,366 - 23,319,\n (total: 954 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_19\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "ATGGTGGTCGGCAATCAAGCATCGGCCGGACACACCCGCGTGGACACGACAGGCGCACTGAACGCCGCATCGAAGACAGCACCGGCTCACGGACTGCGCCCGCTGGGGGAACTCAGCGCCGCGGAGCGCCTCAATTTCCTGCTCACCAACCGCATCCCGCGGCAGGCGGCCACCCGCTTCATGGGCTGGTTCAGCCGCATCGAAAACCGGCTGCTGGCGAAGGCGAGCATCGGCCTGTGGCAATGCTTCGTCGACGACCTGCGCCTGTTCGAGGCCGAGCAGACCCGGTTTGCCAGCCTGCAGCAGTGCTTCACCCGGCGCCTGAGGCCCGGCGCCCGCCCGGTGGACCCACGGCCGGAGGTGTTCACCAGTCCCTGCGACGCCATCATCGGCGCCCATGGCGAACTGGACGGCCTGGCGGCGCTGCAGGCGAAGGGCTTTCCCTATGGCATCGACGAACTGCTGGGTGACCCGGAGGCCGCCGAACGCCATCGCGGCGGCTTCTACCTCACGCTGCGGCTCAAATCGAGCATGTACCACCGCTTCCACGCCCCGACCGACGGTCGCGTCGGGCGCATCCGCTATCTCTCGGGCGACACCTGGAACGTGAACCCGGTGGCCCTGAAAGTGGTCGAGCGCCTGTTCTGCCGCAACGAGCGGGTGGTGTTTCCGTTCCAACCCGCCGATGACGGCCCCCCTCTGACCCTGGTGGCGGTGGCCGCCGTGCTGGTGGCCAGCGTCGGCATCCACGGCCTCGAGCACCCCCTGGACCTCGACTGGGGCGGCCCCACGCTGATCGACCTCGACCGGGATTACACCCGCGGCGAGGAGATGGGCTGGTTCCAGCATGGCTCGACCCTGGTGGTTCTGGCGCCGCGGGGCGCCACCCTGTGCGAAGGATGGCGGCAGGGCGACACCGTCCGCATGGGCCAGGCCCTCCTGCAACGGCTCTGA",
      "translation": "MVVGNQASAGHTRVDTTGALNAASKTAPAHGLRPLGELSAAERLNFLLTNRIPRQAATRFMGWFSRIENRLLAKASIGLWQCFVDDLRLFEAEQTRFASLQQCFTRRLRPGARPVDPRPEVFTSPCDAIIGAHGELDGLAALQAKGFPYGIDELLGDPEAAERHRGGFYLTLRLKSSMYHRFHAPTDGRVGRIRYLSGDTWNVNPVALKVVERLFCRNERVVFPFQPADDGPPLTLVAVAAVLVASVGIHGLEHPLDLDWGGPTLIDLDRDYTRGEEMGWFQHGSTLVVLAPRGATLCEGWRQGDTVRMGQALLQRL",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 18004,
      "end": 19972,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 23478,
      "product": "NRPS-like",
      "category": "NRPS",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [
      {
       "start": 4497,
       "end": 4499,
       "strand": -1,
       "containedBy": [
        "ctg314_6"
       ]
      }
     ],
     "bindingSites": []
    },
    "type": "NRPS-like",
    "products": [
     "NRPS-like"
    ],
    "product_categories": [
     "NRPS"
    ],
    "cssClass": "NRPS NRPS-like",
    "anchor": "r314c1"
   }
  ]
 },
 {
  "length": 4398,
  "seq_id": "k39_86615",
  "regions": []
 },
 {
  "length": 6740,
  "seq_id": "k39_145659",
  "regions": []
 },
 {
  "length": 4395,
  "seq_id": "k39_28087",
  "regions": []
 },
 {
  "length": 8959,
  "seq_id": "k39_67305",
  "regions": []
 },
 {
  "length": 7259,
  "seq_id": "k39_67332",
  "regions": []
 },
 {
  "length": 3463,
  "seq_id": "k39_126120",
  "regions": []
 },
 {
  "length": 7041,
  "seq_id": "k39_28156",
  "regions": []
 },
 {
  "length": 4946,
  "seq_id": "k39_67381",
  "regions": []
 },
 {
  "length": 16627,
  "seq_id": "k39_67463",
  "regions": []
 },
 {
  "length": 3332,
  "seq_id": "k39_106646",
  "regions": []
 },
 {
  "length": 9701,
  "seq_id": "k39_47524",
  "regions": []
 },
 {
  "length": 3427,
  "seq_id": "k39_8935",
  "regions": []
 },
 {
  "length": 7905,
  "seq_id": "k39_126458",
  "regions": []
 },
 {
  "length": 3431,
  "seq_id": "k39_9014",
  "regions": []
 },
 {
  "length": 7011,
  "seq_id": "k39_67909",
  "regions": []
 },
 {
  "length": 9994,
  "seq_id": "k39_107176",
  "regions": []
 },
 {
  "length": 4298,
  "seq_id": "k39_48036",
  "regions": []
 },
 {
  "length": 3445,
  "seq_id": "k39_126887",
  "regions": []
 },
 {
  "length": 4082,
  "seq_id": "k39_9766",
  "regions": []
 },
 {
  "length": 10875,
  "seq_id": "k39_9862",
  "regions": []
 },
 {
  "length": 11929,
  "seq_id": "k39_127204",
  "regions": []
 },
 {
  "length": 2854,
  "seq_id": "k39_68580",
  "regions": []
 },
 {
  "length": 7396,
  "seq_id": "k39_88037",
  "regions": []
 },
 {
  "length": 9127,
  "seq_id": "k39_10083",
  "regions": []
 },
 {
  "length": 2834,
  "seq_id": "k39_107989",
  "regions": []
 },
 {
  "length": 6281,
  "seq_id": "k39_48864",
  "regions": []
 },
 {
  "length": 2818,
  "seq_id": "k39_68978",
  "regions": []
 },
 {
  "length": 7843,
  "seq_id": "k39_29767",
  "regions": []
 },
 {
  "length": 5307,
  "seq_id": "k39_127821",
  "regions": []
 },
 {
  "length": 4355,
  "seq_id": "k39_127870",
  "regions": []
 },
 {
  "length": 5505,
  "seq_id": "k39_127919",
  "regions": []
 },
 {
  "length": 16565,
  "seq_id": "k39_128260",
  "regions": []
 },
 {
  "length": 5118,
  "seq_id": "k39_69698",
  "regions": []
 },
 {
  "length": 10179,
  "seq_id": "k39_49716",
  "regions": []
 },
 {
  "length": 5964,
  "seq_id": "k39_128567",
  "regions": []
 },
 {
  "length": 5279,
  "seq_id": "k39_49961",
  "regions": []
 },
 {
  "length": 3097,
  "seq_id": "k39_89448",
  "regions": []
 },
 {
  "length": 4551,
  "seq_id": "k39_128840",
  "regions": []
 },
 {
  "length": 6463,
  "seq_id": "k39_89650",
  "regions": []
 },
 {
  "length": 8485,
  "seq_id": "k39_50295",
  "regions": []
 },
 {
  "length": 2662,
  "seq_id": "k39_70428",
  "regions": []
 },
 {
  "length": 3500,
  "seq_id": "k39_70473",
  "regions": []
 },
 {
  "length": 10948,
  "seq_id": "k39_12002",
  "regions": []
 },
 {
  "length": 4347,
  "seq_id": "k39_50656",
  "regions": []
 },
 {
  "length": 3613,
  "seq_id": "k39_70829",
  "regions": []
 },
 {
  "length": 8918,
  "seq_id": "k39_110043",
  "regions": []
 },
 {
  "length": 7139,
  "seq_id": "k39_149339",
  "regions": []
 },
 {
  "length": 2682,
  "seq_id": "k39_12328",
  "regions": []
 },
 {
  "length": 4322,
  "seq_id": "k39_12572",
  "regions": []
 },
 {
  "length": 6598,
  "seq_id": "k39_149596",
  "regions": []
 },
 {
  "length": 2790,
  "seq_id": "k39_32156",
  "regions": []
 },
 {
  "length": 3700,
  "seq_id": "k39_130151",
  "regions": []
 },
 {
  "length": 5155,
  "seq_id": "k39_32309",
  "regions": []
 },
 {
  "length": 2723,
  "seq_id": "k39_72045",
  "regions": []
 },
 {
  "length": 8736,
  "seq_id": "k39_150605",
  "regions": []
 },
 {
  "length": 4711,
  "seq_id": "k39_72696",
  "regions": []
 },
 {
  "length": 5484,
  "seq_id": "k39_73411",
  "regions": []
 },
 {
  "length": 4007,
  "seq_id": "k39_53212",
  "regions": []
 },
 {
  "length": 4595,
  "seq_id": "k39_53330",
  "regions": []
 },
 {
  "length": 7328,
  "seq_id": "k39_14927",
  "regions": [
   {
    "start": 1,
    "end": 7328,
    "idx": 1,
    "orfs": [
     {
      "start": 2,
      "end": 5755,
      "strand": 1,
      "locus_tag": "ctg374_1",
      "type": "biosynthetic",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg374_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg374_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2 - 5,755,\n (total: 5754 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS: Condensation<br>\n \n  biosynthetic (rule-based-clusters) NRPS: AMP-binding<br>\n \n  biosynthetic-additional (rule-based-clusters) PKS_AT<br>\n \n  biosynthetic-additional (rule-based-clusters) Aminotran_3<br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1013:aminotransferase class-III (Score: 284; E-value: 3.2e-86)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg374_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg374_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg374_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg374_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "GCGACACCCGACCAGCTGGCCGAGTTCATCGACGACGAAGTCTGCGTCGCGGCCCGGAATGCGCCGGAGGCCTGCGTGCTGTCCGGACCGTCGGAACGACTGGAAGCGATCGCGGAAACGCTCCGGGCCCGGGACCTGCGCGTGGCCATGCTCAAGACTTCCCACGCCTTCCATTCGAGCATGATGGATGGCGCCCTGGAAGCATTCACCGCGGTCGTCGACGGCGTCGCGCGGCACGCGCCCCGGATACCGATCATCTCGACCTGCACCGGCCAGTTGCTCAGCGACGAGGAGGCCCGGTCCACGGAATACTGGGTGCAACAGCTGCGCCGGCCGGTCCGGTTCAGCGACGCCGCCACAAGCCTGCAGTCGTACACCGCCTCTCAAGGCATCGCCCTGCTGGAACTCGGCCCCGGCAGGACGCTCGCCTCCCTGTTCTCCCAGCAATGCAGCGCTGACCATTTCGCGACCCCGTCCCTGGGCCTCGTCGAGGACGAGGCGTACGTGGCCTCCTGGCTGGCCCTGGGCGCGCTCTGGTGCGCCGGCTACCCCTTGCCGGTCGAGGACTGGTGGAGCGAGGACGCACACCAACGGGTCCGGCTGCCCACCTACCCCTTCCGCAGGGACCGGCACTGGCTCGAGCCCGTGTCGGCGCCGGCGCCGCGGGACGCGGACGACGCGCCGGAGGAAGCCGCCGAGCCGGTCGTGCAGGACATCAAGACCCAGGTCACGACGGTGTTCCGTGACGTCACCGGATTCGAACTGATCGCCAGCGACAGCGGCAAGACCTTCACGGACCTTGGCCTCGATTCCCTGCTGCTCACCCAGGTGGCGGTCGCCCTCCAGCAGACCTTCGGGGTCGTGCTGACCATCAAGGACCTTAGCCAGACCCTGGACACCATCGACAAGGTGTCGGCGCGGGTGGAGAGCCAGGCCCCGGATGCTGCCGACGCCAGGAAACCGGCCCCCGCGGCCCGCAGTGGCTCCGGCCAGGACGGCACGCCCATCCGCTCGTCCCTGCCCCGGCGCGCGCCGAAACGGAAAAAGAAGGGCCACCACCGGCGCGACACGCGCCCCACCAGTTTCAGCGCCTGGTCCGAACTGGGCGAACAGCGCACGCGGGCCATCCGGGATTTCATCGAAGTCCACGTCGCGAAAACCGCCGGTTCCAAGGCGCACACCGCCCGGTACCGACCCGCCCATGCCGACCCAAGGACCGCCGCGGGCTTCAACCGCGTGTGGAAGGAGATGGTCTATCCACTGGTCTGCACCCGCAGCCAGGGCTCGGAGATCTGGGACATCGATGGCAATCGTTACATCGACATGCTGAGCGGCTTCGGGCCCAATCTGCTCGGGCACGCCGAACCGGACATCAACGCGGCCATCAGGGAACAGCTCGACGCCGGCATCGAGATCGGTCCCCAGTCGAACCTGGCCGGCGAAACGGCCGACCTCGTGTGCCAGCTCACCGGCATGGATCGTGCGAGCTTCATGTGCACAGGCTCCGAAGCCGTCCAGGCGGCCATTCGCTGCGCCCGGACCTACACGCGGCGTTCGAAGATCGTGATCTTCGAAGGGTCCTATCACGGCAATTTCGACGAGGTACTGACGCGCTCGGCCAACGCCCCGGGCCTGCTCAGGACCGTGCCGGGCTCGCCGGGCATTCCCGCGACCAGCGTGGCCGAGGTGGTCGTCCTGCCCTGGAACAGTGACGCCAGTCTCGAGGTCCTCGACGAGATCGGGGATGCGGTGGCTGCCGTGCTGCTCGAGCCCGTGCAGAGCCGCACCCCTGACATCCGGCCGGCGGCCTTCCTGAAGTCCATCCGCGAGATCACGCGCCGCCATGGCACCGTCCTGATCTTCGACGAGGTGGTCACCGGCTTCCGCTGCCATCCGGGCGGGGCCCAGGCCTGGTTCGGTATCGAGGCCGACCTCGCCACTTACGGCAAGGTGGCGGGCGGCAACATGCCCATCGGCATCGTCGCCGGACGCAGAGACATCATGAACACCTTCGACGGGGGCGACTGGAATTACGGCGACGACTCCGGGCCGGACGCCGGCGTGACCTTTTTCGCGGGCACCTTCGTGCGCCACCCCCTGGCGATCGCCGCCTGCCGCACCATGCTCGGAAAGCTGCGGAAGGCCGGCCCCGAGCTGCAGAAGGACCTCACCGAACGCACCGAGCGATTCGCCGCCCGGGTCAATGCGATCTTCCGGCGCTACGAGGCGCCGTTCGAACTCGCGCATTTCACCTCGGTGATGTACCTGCGCAACAGCGACGTCAGCGCGCTGGGGTCACTGTTCTGGTATGCGCTGCGACAGAACGGCGTGTTCGCCCTGGAAGGCTTTCCTTCCTACATGACGCTGGCGCACACCGAGGCGCATCTCGAGGAGGTGGTCGAAGCCATCGAGAACAGCCTGGCCTGGATGGTCGAATCAGGCCTCCTGGTGGAACCCCGACAGCTCAACCCCGACGCTGTGTCGGCCCCGGCCGTTCCGCTGCAGGCGCCGGACGAGACCGCCCGCCTGGGCGAGGACCCGGAAGGCCACCCGGGCTGGTTCCGGGCGGCCGACGGCGCCTGGGTCGATACCGTGTCCGGCAAGGTCGTGGCCGCCGACCCGTGGACGACGAAACTCGCGCGGATCTTCCCCGCCAGCGAGTCCCAGCAGGAAATCTGGTCGTCGGCGCAACTGGGCGACGACGCTTCCTGCGCCTTCAACGATTCGGTCAGTGTCGCGATGCCGGCGGACCTGGATGTCGGCCTGCTGCAAAAGGCGATCGACGACATCGCGATGCGCCACGAGGCCCTGCGCGCCTGCGTGTCGCCCGACGGCGCCCTGGTCAAGGTCACGGCGGAGTCGCACATCGCCCTGCGCACCAGCGACGAGCCGTTGGGGCAGATCATCGAGACGGACGTGCGCACGCCGTTCGACCTCGTCAGGGGCCCCCTCTTCCGATTCACCCTGGCCGGCCGGGGCGGCGACCGCCCGACCCTGGTGGTGACCTGTCACCACATCGTCTGCGACGGCTGGTCCATCCAATTGTTGATCAAGGAACTGGTCCGGCTGTACCGCTCGCATTGCGAAGGCGGAGAGGCCACCCTACCCCCGGCCGACAACCTGGGCGACTACAACCGGGACGCGTCCGACCTCGCCGACACCGAGGCCGAGGACTACTGGCTCGACGAGTACCACACGATTCCGCCGGTGCTGGACTTCCCGGCGGACCGTCCACGACCGAAAATGCGGACCTTCGAGTCGAAGCTCGTCGAATTGCGGGTGGACCGCGCGCGCCTGGACCGGCTGAGGGCCCTGGCCACGTCCCGCAACGCCAGCCTCTTCAACGTGCTGCTCGCCGGCTGGTTCGCTTTCACGGCGCGACTGACGGGCAACCACGACCTCGTCGTGGGCATCCCGACGGCCGGCCAGGTGGTTTCCGGCATGCCGAACCTGGTCGGGCACTGCGTGAACCTGTTGCCCTTGCGTGTGCAGGTCGACGTCAACGACCCCTTCGAGCGCCTGGTGGGGAACGTCCAGGAAAAACTGACCGACGGCCTCGAGCACCAGGGCTACACCTTCGGGCGCCTCATCAAACGCCTGCCCATCGCCCGGGATCCCAGCCGGCTGCCCATCGTCTCCGTGCAGTTCAACCTCGACCCGCCGGCGGATGCCTCCGATTTCGACTTCGGCTCGGCCAGCCCGGGACTCACGACCAATCCGCGGGCCTTCGAGAACTTCGAACTGTTCGTCAACATCGCCGAGGACCAGGACGGCCTCCTCGTTCACCTGCAGTACAACAGCAACCTGTTCGAAGAGGCCTCGATCCGCAACCGCATGGCGGAATACTTCACCCTGCTGGACGCCGCCTGCGAGGCGCCGCAGGCACGGACCGCGGAACTCGAGCTGCTGACGCAGGCGGACCGCGACCGGCTCCTGCAAGTGGCGACGGGTCCGGACGGACTGGACCATGGCCGCCATTTCCTCGATCTGTTCCGGGCGCAGGTCACAGACACCCCGGACGCCGTCGCCGTTGTCGGCGAAGACGGGCGACTGACCTACCGCGAACTGGACGACCATTCCTCGAAACGCGCCGCCCGGCTGGCCGCCCTGGTTGCGGATTCCGCGGAGGCCCTGATCGGGGTCGCCCTGCCCCGCAATGCGGACATGCTGGTCTCCCTGCTGGCCATCTGGAAGCTCGGCGCCGCCTACGTGCCCCTCGACCCCGAGTTCCCGGCGGATCGACTGCAGTTCATGATGGAGGACGCCGGCCTGTCCGCGCTGATCACGAGCCGCGCGACGCAGCCGGGCGCCGGCCCGGAGCTGCCCACCCTGTTCGTGGACGACGCGGCCGGCGTCGACGAAGCGGCGGCGCCGGTCGGGCGCCATTCCGCCGACCAGCGCGCTTACGTGATCTACACCTCCGGGTCCACGGGCCGCCCCAAGGGCGTGGACATCCCCCACCGGGCCTTCAGCAATTTCCTGCAGAGCATGTGTCTCCTGCCGGGACTGGACGCGGACAGCCGCTTGGTGGCCGTCACCACGTTGTCCTTCGATATCGCGGGGCTGGAACTGTTCGGCCCGCTCCTTGCCGGCGGTACGACCATCATCGCCAGCCACGGGCAGTCCCAGGAAGGCCGTGCGCTGGTGCGCCTGCTGGAGGACGCCGATGCCAACGTCATGCAGGCGACACCCGTCACCTGGCGAATGCTGCTGGAAGCGGGCTGGTCCTGCCCCGAGGGCTTCAAGGTGCTGTGTGGCGGCGAGGCCTTCCCCGGCGACCTGGCCACGGAGCTGTTGAAGGCCACGAGCCGCGTCTACAACCTGTACGGACCCACGGAAGCCACGGTCTGGTCCACCGTCCATCCACTCGACGCCGAATCATGGCCGGCCGCCCCCGAGGCGACCGTGCCCATCGGAGCGCCCATCCATGGCACGCAGGTGTACGTGCTCGACCGGCAGCTGAACGTCCTGCCCGCCGGGGTGCCGGGCGAACTCTTCATCGGCGGCGTCGGACTGGCCTCGGGATATCTCGGGCGCGACGAACTCACCCGTGAACGGTTCATCGAACACCGGCAGTTCGGGCTCCTGTACCGCACCGGCGACGTCGTCACGCTCGGCGCGGATGGCGCGCTGCGCTTCCGCGAGCGCATCGATACCCAGGTCAAGGTCCGGGGCTTCCGCATCGAACTGGGCGAGATCGAGGCCGCGCTCGCCGCGGTCCCCGGGGTCACCGAGGCCGTCGCCACGGTGTACGAGCCGGCGCCGGGCGACACCCGCCTGGCCGCCTACTACGTGTCATCGACGGGCGAGATCGACGAGAACGAGCTGCGCGAGCAGCTCCAGGGCCGGTTGCCCCGCTACATGCTCCCGCAGCACTTCGTCGCCATGGAAGCGCTGCCGTTGACGCCGAACCGAAAGGTCGACCGGAAAGCCCTGCCGAAACCGGTGTCGCCGAGGGCTGCGGTCGTCGCTCCCAGGAACGATACCGAGGCGCTGGTCGCCGGTCTCTGGCGGGAACTGCTGCATGTCGAGGACGTCGGCGTCGAGGATGACTTCTTCAATCTGGGCGGCCACTCCATCCTGGCCACCAGGATGATCTCCCTGCTCGAAGACCGCTCCGGCCTGCGCGTACCGCTGCGAACCCTGTTCGCCCATTCGGTGCTGGCGGACTTCGCGGGACATGCGGCGGCGGCCGGACTGGTCCAGGACAACGTGGCGGACGAATCCAGGGAAAGAGAGGTCCTGGAATTTTGA",
      "translation": "MTPDQLAEFIDDEVCVAARNAPEACVLSGPSERLEAIAETLRARDLRVAMLKTSHAFHSSMMDGALEAFTAVVDGVARHAPRIPIISTCTGQLLSDEEARSTEYWVQQLRRPVRFSDAATSLQSYTASQGIALLELGPGRTLASLFSQQCSADHFATPSLGLVEDEAYVASWLALGALWCAGYPLPVEDWWSEDAHQRVRLPTYPFRRDRHWLEPVSAPAPRDADDAPEEAAEPVVQDIKTQVTTVFRDVTGFELIASDSGKTFTDLGLDSLLLTQVAVALQQTFGVVLTIKDLSQTLDTIDKVSARVESQAPDAADARKPAPAARSGSGQDGTPIRSSLPRRAPKRKKKGHHRRDTRPTSFSAWSELGEQRTRAIRDFIEVHVAKTAGSKAHTARYRPAHADPRTAAGFNRVWKEMVYPLVCTRSQGSEIWDIDGNRYIDMLSGFGPNLLGHAEPDINAAIREQLDAGIEIGPQSNLAGETADLVCQLTGMDRASFMCTGSEAVQAAIRCARTYTRRSKIVIFEGSYHGNFDEVLTRSANAPGLLRTVPGSPGIPATSVAEVVVLPWNSDASLEVLDEIGDAVAAVLLEPVQSRTPDIRPAAFLKSIREITRRHGTVLIFDEVVTGFRCHPGGAQAWFGIEADLATYGKVAGGNMPIGIVAGRRDIMNTFDGGDWNYGDDSGPDAGVTFFAGTFVRHPLAIAACRTMLGKLRKAGPELQKDLTERTERFAARVNAIFRRYEAPFELAHFTSVMYLRNSDVSALGSLFWYALRQNGVFALEGFPSYMTLAHTEAHLEEVVEAIENSLAWMVESGLLVEPRQLNPDAVSAPAVPLQAPDETARLGEDPEGHPGWFRAADGAWVDTVSGKVVAADPWTTKLARIFPASESQQEIWSSAQLGDDASCAFNDSVSVAMPADLDVGLLQKAIDDIAMRHEALRACVSPDGALVKVTAESHIALRTSDEPLGQIIETDVRTPFDLVRGPLFRFTLAGRGGDRPTLVVTCHHIVCDGWSIQLLIKELVRLYRSHCEGGEATLPPADNLGDYNRDASDLADTEAEDYWLDEYHTIPPVLDFPADRPRPKMRTFESKLVELRVDRARLDRLRALATSRNASLFNVLLAGWFAFTARLTGNHDLVVGIPTAGQVVSGMPNLVGHCVNLLPLRVQVDVNDPFERLVGNVQEKLTDGLEHQGYTFGRLIKRLPIARDPSRLPIVSVQFNLDPPADASDFDFGSASPGLTTNPRAFENFELFVNIAEDQDGLLVHLQYNSNLFEEASIRNRMAEYFTLLDAACEAPQARTAELELLTQADRDRLLQVATGPDGLDHGRHFLDLFRAQVTDTPDAVAVVGEDGRLTYRELDDHSSKRAARLAALVADSAEALIGVALPRNADMLVSLLAIWKLGAAYVPLDPEFPADRLQFMMEDAGLSALITSRATQPGAGPELPTLFVDDAAGVDEAAAPVGRHSADQRAYVIYTSGSTGRPKGVDIPHRAFSNFLQSMCLLPGLDADSRLVAVTTLSFDIAGLELFGPLLAGGTTIIASHGQSQEGRALVRLLEDADANVMQATPVTWRMLLEAGWSCPEGFKVLCGGEAFPGDLATELLKATSRVYNLYGPTEATVWSTVHPLDAESWPAAPEATVPIGAPIHGTQVYVLDRQLNVLPAGVPGELFIGGVGLASGYLGRDELTRERFIEHRQFGLLYRTGDVVTLGADGALRFRERIDTQVKVRGFRIELGEIEAALAAVPGVTEAVATVYEPAPGDTRLAAYYVSSTGEIDENELREQLQGRLPRYMLPQHFVAMEALPLTPNRKVDRKALPKPVSPRAAVVAPRNDTEALVAGLWRELLHVEDVGVEDDFFNLGGHSILATRMISLLEDRSGLRVPLRTLFAHSVLADFAGHAAAAGLVQDNVADESREREVLEF",
      "product": ""
     },
     {
      "start": 5752,
      "end": 7326,
      "strand": 1,
      "locus_tag": "ctg374_2",
      "type": "biosynthetic-additional",
      "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg374_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg374_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,752 - 7,326,\n (total: 1575 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Condensation<br>\n \n  biosynthetic-additional (smcogs) SMCOG1127:condensation domain-containing protein (Score: 279.2; E-value: 1.2e-84)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg374_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg374_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg374_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg374_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
      "dna": "TTGACCGTCGTCGATCTGCTGGAGACGCTTCGGCGTCTCAAGGTCAGTGTCCGCGCCAATGGCGACAAGCTGGTCATCGACGCACCCGCCGGGGTGATCGATGAGACGCTCGCCGGGAACATCCGTGCGAACAAGTACCAACTGCTCGAACTCATCCGTTCGGCAGGCCAGGGCGAGGACAGCAGCAAGGTCGAACTGGCCCGTGCACCGGACGAGGACCGGCTCTCACTGACGCAGGAGCGGGTCTGGGCGATCCATCAACTGGACCCGGAGAGCAGCCAGTTCAATCTGCCCGGGGCCTGGTGGCTCGACGGCCCACTGGACACCGGGGCCCTTCGCCAGGCCATCGCGGCGTTCGAGTCCCACCATGAGATCTTCCGGCGACGGTTCGTCTCGAAGGACGGAAGCCCGAGGGTTTCGCCCCCCGAACACGACGGCGTTGCGTTCAGCATGACGACGCTCGGTGAGATCGGGCTCGAAGCCGAAGACACCCACCGCCTGGCGCGGTGGTTCGAGGACATTTCAGCTTCGCCGTTCGACCTGGCCGCCGACGCCTTGCTCCGTGTCGTGCTGCTGCGTGTGAGCGAGACCCGTCACCTGCTCTCGGTCATCAGCCACTCCATCGTCTGGGATGCCTGGTGCTACGACATCTTCCTGGCGGAACTCGGCCGGAACTACGAGGCCCTGCTGGCCGGCGAGCCGCTCGCCGGACCGGACCACCAGTATTCCGACTTCGTGCACTGGCAACGCGCCGACCAGGATCGGCGGGCCGCCCGCGAAGCCCTTCAAGCCGCCATCGACCGTCTCGAAGGCCACCGGCAAAGACTCGTGCTGCCCAGGACCCGGCAGTCGGTCGACCCCCGGGAGCACTCGGGCGCCCGGTTCAATTTCGACATTCCGGTGGAGCTGCGTGAAGCCTTGCGCGCCTTCTGCCGGCAACAGGGCGTCACGCCCTTCATGGTCTTCCTGTCGTCCTACGCCTATCTCCTGTGCCGCTACGCCGGCAAGGGAAGCGCGCTCATCACCGTGCCCCTGCGGGGACGCGAACGACCCGAGTTCGAAACCATCCCCGGACCGTTCACGAAGAACCTGTTTCTCCCGGTCGAGGTGGAAGACCGGTCGTTCGCGAGTCTGCTCGCATCCGTCAAGCAGGAAACCGGGCAGGCCTTCGGGGGCGAGGTCCCGAGCTTCGAACGGCTGATCGAAGCCATCAACCAGAACCTGGCCGACTCCGCGTTCTTTCAGCTGCAGTTCTCCTACCAGAATGTCGAGAATCGGGGCACCGAGTGGGCCAGGGGCATCCGGATGTCGGCCGGACCGGCCCACGACTCGGACCACGTCCATGCCGAGATCAGTTTCTGGATGCGGGAGGGCAGGAACAGCATGGACGGGGCGATCGACTACCGGACGTCCCTGTTCGACGAGGCGTTCATCGCACGGTTCTACGAGCGACTGCTGGCGGTGATCCGGGCCGGAATCGCAACGCCCGATGCAGCCCTGCTCGACCTGGACATCGAAGCACCCGGCGCCACGACCGACGCCCCGACGCCGCCGACACGCATCGACACCCTGTCC",
      "translation": "MTVVDLLETLRRLKVSVRANGDKLVIDAPAGVIDETLAGNIRANKYQLLELIRSAGQGEDSSKVELARAPDEDRLSLTQERVWAIHQLDPESSQFNLPGAWWLDGPLDTGALRQAIAAFESHHEIFRRRFVSKDGSPRVSPPEHDGVAFSMTTLGEIGLEAEDTHRLARWFEDISASPFDLAADALLRVVLLRVSETRHLLSVISHSIVWDAWCYDIFLAELGRNYEALLAGEPLAGPDHQYSDFVHWQRADQDRRAAREALQAAIDRLEGHRQRLVLPRTRQSVDPREHSGARFNFDIPVELREALRAFCRQQGVTPFMVFLSSYAYLLCRYAGKGSALITVPLRGRERPEFETIPGPFTKNLFLPVEVEDRSFASLLASVKQETGQAFGGEVPSFERLIEAINQNLADSAFFQLQFSYQNVENRGTEWARGIRMSAGPAHDSDHVHAEISFWMREGRNSMDGAIDYRTSLFDEAFIARFYERLLAVIRAGIATPDAALLDLDIEAPGATTDAPTPPTRIDTLS",
      "product": ""
     }
    ],
    "clusters": [
     {
      "start": 1,
      "end": 5755,
      "tool": "rule-based-clusters",
      "neighbouring_start": 0,
      "neighbouring_end": 7328,
      "product": "NRPS",
      "category": "NRPS",
      "height": 2,
      "kind": "protocluster",
      "prefix": ""
     }
    ],
    "sites": {
     "ttaCodons": [],
     "bindingSites": []
    },
    "type": "NRPS",
    "products": [
     "NRPS"
    ],
    "product_categories": [
     "NRPS"
    ],
    "cssClass": "NRPS NRPS",
    "anchor": "r374c1"
   }
  ]
 },
 {
  "length": 5512,
  "seq_id": "k39_92972",
  "regions": []
 },
 {
  "length": 2686,
  "seq_id": "k39_132458",
  "regions": []
 },
 {
  "length": 4845,
  "seq_id": "k39_73927",
  "regions": []
 },
 {
  "length": 9057,
  "seq_id": "k39_53919",
  "regions": []
 },
 {
  "length": 3023,
  "seq_id": "k39_74348",
  "regions": []
 },
 {
  "length": 4526,
  "seq_id": "k39_16304",
  "regions": []
 },
 {
  "length": 3908,
  "seq_id": "k39_94209",
  "regions": []
 },
 {
  "length": 2738,
  "seq_id": "k39_35938",
  "regions": []
 },
 {
  "length": 7039,
  "seq_id": "k39_133755",
  "regions": []
 },
 {
  "length": 3687,
  "seq_id": "k39_54836",
  "regions": []
 },
 {
  "length": 2912,
  "seq_id": "k39_36824",
  "regions": []
 },
 {
  "length": 5350,
  "seq_id": "k39_55679",
  "regions": []
 },
 {
  "length": 2716,
  "seq_id": "k39_115460",
  "regions": []
 },
 {
  "length": 11729,
  "seq_id": "k39_95425",
  "regions": []
 },
 {
  "length": 4880,
  "seq_id": "k39_76381",
  "regions": []
 },
 {
  "length": 4484,
  "seq_id": "k39_18584",
  "regions": []
 },
 {
  "length": 4515,
  "seq_id": "k39_116540",
  "regions": []
 },
 {
  "length": 3068,
  "seq_id": "k39_57733",
  "regions": []
 },
 {
  "length": 4394,
  "seq_id": "k39_117440",
  "regions": []
 }
];
var all_regions = {
 "order": [
  "r144c1",
  "r170c1",
  "r203c1",
  "r268c1",
  "r272c1",
  "r313c1",
  "r314c1",
  "r374c1"
 ],
 "r144c1": {
  "start": 1,
  "end": 7031,
  "idx": 1,
  "orfs": [
   {
    "start": 82,
    "end": 1089,
    "strand": -1,
    "locus_tag": "ctg144_1",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg144_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg144_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 82 - 1,089,\n (total: 1008 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg144_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg144_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCTTCCGGCGGTGAATCAGGCTGTCGAAGACTACGTCCGAACCCTTTGAATTCTTCGGGCCAGCAATTGATCAGTTCGTGCCTCGAAGCCCTGGAGCGCGGCGCTCGATGGCTCTCGGCCAATCAACGGAAGGATGGATCCTTTTCCAGCACCATCCATAGATCCGCTCGCCTCGAAGACCCGGGCCAGGAAGAATTCGCCGTGTTTCCGACGTTGCTGATACTCCGCTCCCTTCGGCGGCTGCCGGGGTTTCAGGTCCTGCGTGAGCGCGCGGGTGCCTTCGTATTGGGTGCGAAACGACCAGGGGGCACGTGGAGTTACTGGTACCGGGATCCTCCGTTCCACGTGCCTCCGGACGTTGATGATACGGCCCTGGCGCTGACAGTCACACGTGACCTGCTGACGCCGGCACAACGAGCGGAAATAGTTGTTCGGCTTGCTCAGAACCGCGACGACTGCGGCCTGTTTTGGACATGGTTCGATGTCCCAGAGCACAATGATACCGACCTGGTGGTCAACGTGAACGTGATCGGTGCGCTGGGCGAGGGATCGTTCACGGACGCTGCGATTCGGTTGATTCAGGCCCGACTTGGGTGCGATCCAGACGGGTGCACTTACTATTACCCAACAAAGAGCGCGCTCGCCTATGCCCTGGCTTGGGCGGTCGACGAGGGGGTGACTGCGCTAGTGGACCCAGGAGAACGACTTCAATCTGGGTTGGTTTCGAGCTGGAAGTGCTTGTCCGATGAGGACCTGGCGCAAAGCCTGGCAGCCGGCGCTCATCTGGGGCTGGGCGCCCATGGCGAGTGGCGCCAGGGTTTGGCCAGGTTGTTGCGGCTGCAAGGTGAGGATGGCGGTTGGCCAGCGGTTGTTTTTGCCCTGGGACCCAGGCCCCCTGAAGAACCTGAGCACTGGTACGCCTCAGACAGTGTCCATACGGCTTTGGCCCTCGAAGCGATTCACGGTTGTCTTCCGCTTTTGGAAGGCCCGAAATCGTTGACATAA",
    "translation": "MPSGGESGCRRLRPNPLNSSGQQLISSCLEALERGARWLSANQRKDGSFSSTIHRSARLEDPGQEEFAVFPTLLILRSLRRLPGFQVLRERAGAFVLGAKRPGGTWSYWYRDPPFHVPPDVDDTALALTVTRDLLTPAQRAEIVVRLAQNRDDCGLFWTWFDVPEHNDTDLVVNVNVIGALGEGSFTDAAIRLIQARLGCDPDGCTYYYPTKSALAYALAWAVDEGVTALVDPGERLQSGLVSSWKCLSDEDLAQSLAAGAHLGLGAHGEWRQGLARLLRLQGEDGGWPAVVFALGPRPPEEPEHWYASDSVHTALALEAIHGCLPLLEGPKSLT",
    "product": ""
   },
   {
    "start": 1038,
    "end": 1952,
    "strand": -1,
    "locus_tag": "ctg144_2",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg144_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg144_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,038 - 1,952,\n (total: 915 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg144_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg144_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCTGAGGAGTGCCCCGCCGGATCTTACCGTGCCATTTGCTATGGTGTGCCCGTCATATCGGACGTGCCATTGACGGTCTTGGGCGGCGCGAAAAGCGAATTGCAGGCGCCTTGCCGCATTGTCATTGAAAGATCCTCACCTCCTTCGATGCGGACGGGACAGGCACTGATCGAACTCGAGATTCAGGGCCGAAAAGTGTCATCCCGGTTCGCCCCCGACCATGATGACGAGACACATCGCGGCGTCTGGAGGGCGTTCGTCGAGAACGTTGCACGATTCGAATGGCGAGAAGGCCCCGACGAACCCTTGCGCATCTGGAGGGAAGGGGCATCAGACGAAATCCTGGCGTTCTGGGTGGTCCATCTGCTCCTTCCCGCTTACCTGTCCTGCAACCGGGGAATCAGTATCCTGCACGCATCCGCAGTCGAGGTGGAGGGTGGCTGCGTGGCGTTTCTCGGCCCCTCGTTCAGCGGCAAGTCCACGTTGCTGGCCAGTTTCCTGAGTCGCGGTTTTGCGTTGTATTGCGATGACAAACTCGCAATTCGCCAGGTGGGGGACGGGATTCGAGCGTTTGCGGCGCACGGTCGCTATCGACCTTACCGCGCCAACGAATCCCTGGGCCGTTGCCAGGCCCGGCGGGTCGCCGACCCGGGACCGGTTCGTGCCCTTTTGGCCCTCGAGCGGATTGCAGGCCTGGAGAAGCCGGAGATAACGCCGGTTTCAGGCGCTGACGCATTTCGACGCCTGATCGCCGACCACCACATGGGATTCTGGCAATCGCGGGCTGAAAATTTTCAGGCTGTCTCGCACCTGTCCCGCACCGTACCTCTGGCTACCCTGGCAATTCCAGATGACCTGCGATGCCTTCCGGCGGTGAATCAGGCTGTCGAAGACTACGTCCGAACCCTTTGA",
    "translation": "MSEECPAGSYRAICYGVPVISDVPLTVLGGAKSELQAPCRIVIERSSPPSMRTGQALIELEIQGRKVSSRFAPDHDDETHRGVWRAFVENVARFEWREGPDEPLRIWREGASDEILAFWVVHLLLPAYLSCNRGISILHASAVEVEGGCVAFLGPSFSGKSTLLASFLSRGFALYCDDKLAIRQVGDGIRAFAAHGRYRPYRANESLGRCQARRVADPGPVRALLALERIAGLEKPEITPVSGADAFRRLIADHHMGFWQSRAENFQAVSHLSRTVPLATLAIPDDLRCLPAVNQAVEDYVRTL",
    "product": ""
   },
   {
    "start": 2044,
    "end": 2559,
    "strand": 1,
    "locus_tag": "ctg144_3",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg144_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg144_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,044 - 2,559,\n (total: 516 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) lassopeptide: PF13471<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg144_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg144_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGCTGTGTGCCCTTGACCTTGCAACTGACATCGAATTTGCCGTGAATCAACCCGAAAGGACCTTACGCATCCGGATCGCCACGGATTCCCAGCCACGAGTCCACCGTGGCAAGCGGTTCGCTGCAAAAAGCCTGTTGGCCCTGGTCAGCCTGGCGATCAGCCTGGTGGGCGTGCAGCGAACCCACCGCTGCCTGACGATTCTGGCAGCACCCGCCCATCGGGCCCGGGTCGGCAAGAGCAATCCGGAACAGGCGCTTCTGCATGCTGATCTATGGCGGCAAATTCTGGAATCGGAAGCGGCCGCCCTGCCCTTCAGGGCCGAATGCAGTGAAATCTCCCTGAGCCTCCATGCACTGATGCTGCTCGGGGGCCATCGGGGCGAGGTCGTCATCGGCCATCGCTTGCTGCAGGACAACGTGCAGGGACACACCTGGCTGATGCTGGAGGGACAGGTTGTCTCGGAGCTCGGCGAACCGGACAAGGCCTATCCCATTTTGCATGTTCGCTTGAGGTGA",
    "translation": "MLCALDLATDIEFAVNQPERTLRIRIATDSQPRVHRGKRFAAKSLLALVSLAISLVGVQRTHRCLTILAAPAHRARVGKSNPEQALLHADLWRQILESEAAALPFRAECSEISLSLHALMLLGGHRGEVVIGHRLLQDNVQGHTWLMLEGQVVSELGEPDKAYPILHVRLR",
    "product": ""
   },
   {
    "start": 2585,
    "end": 4348,
    "strand": 1,
    "locus_tag": "ctg144_4",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg144_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg144_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,585 - 4,348,\n (total: 1764 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) lassopeptide: Asn_synthase<br>\n \n  biosynthetic-additional (rule-based-clusters) GATase_7<br>\n \n  biosynthetic-additional (smcogs) SMCOG1177:asparagine synthase (glutamine-hydrolyzing) (Score: 232.3; E-value: 1.9e-70)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg144_4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg144_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGTGGCTTGTTTGCCGTCTTCAATCGATCCGGTGCACCCGTCAACGAAGCGGACCTGGCCCGGGCACTCGGGCGCATGTCTGTCAGGGGTCGCGACGACTCACGTATGTGGCACCAGTCCAATGCAGGCCTGGCCGCGGCTGTAACGTTCTGGTCCAGTGAAGAAAAACCTTGCGACCTGCCCTCCACGCTGGACGGGTCATGCCATGTCATTGCCGCAGCATTGCTCAGCAACCGCCCGGAACTGCGCCGGCAGTTGCACGGCGCCGGCCACGCAACCACCCCGGAAACCTCCGACGCGGAACTGATTCTCCGCAGTTACACCGCCTGGGGTGAACGTTGCACGGAGCATCTTCGCGGAGAATTCGCTGCCGTCGTGTGGGACCCGGCCCGCCAGAAACTGCTGGGGTTCGTGGACCATTTTGGCACCCTGCCCCTGTTCTATACCGATACATCGGAGATGGCGGTGCTGAGTACGGATCTCGAAGCCATCGCCACTTTTCGCGGTGTCGATCGCACATTGAGTCCTGAGGCCATCGTCGACACGCTGATATACGGGTTTCAACAATCCCGATCCAGCACGATTTACGAGCATATTCATCGTTTGCCGGGCGGGCACCTGCTGGAGGTAGCGCCGGAAAAAGCCCGTAGAAGCGTGTACTGGACGCCCGACGAATGGTCTCCCCTGAGAAACGTCAGCGACCCACAATCCCTGGTGGACGAATTTCATGCACATCTCGAAAGGGCTGTGCTCGCGAGGGCCCGACTCCCGAACCTTGGCGTCGAGTTGTCCGGTGGACTGGACACTTCCAGCATCGCCCAGGTTCTGAGCGAGGATGCCCGGAATCGCCGACCTCAGCGCCACCTAAGGGCGTTTTGCCATGGATTTTCGGGCCCGGCCGGAGAAGCAGAACCCGCCCTCGCTCGCCAGACTGCCGACCACCTCGGCCTGGACCTGGAAGTGCTCTGGCAGGACCGAGGTCACCCATTGGGCACCACGAAGCCGAGCCACTTTCCCCCTGAACCCCAGGGCTTTCTGTGGGATGCGGGATTGCTGCATGGGCGCAATGCGGCGGCTCATTCGCCCATCCTGTTCTCAGGTCACGGCGGCGACATGATTCTGGGGTACGTGGAATACCACTGGATGCGCCAACTGCGCCGGCGGCCAATGGGCGCGTTTCGAGACCTTCTGACGTTTTTCAGGATGTACGGCTTCAAGCGACCGCCACTCGGGCTACGCAATTGGGTCAGGAAGTGGCAGGGAGCCAACGAATCAAACATGCCTGTGCCCACCTGGCTCCGCCAGGACCTGGTGGACCGGGTCGCCCCCCTCGACCGGGTTACGCATATCGAGACAAGAAGCGAATCCTTCCGCCAACGGCTGGGAATGTGGCACAGCCCCGTGTCCTCGATGATTTTTTCCCGAACCGATGCCGCCTACTACGACGCGCCCATTCGTTGCGTTTATCCCTATTTCGATTTCGATTTGTGGGAGTTTCTGCAATCAGTGCCACCAATACCCTACTTCGTGAAGAAGGCCCTGCTGCGGGTCGACATGAAGCATCGTCTCCCAACCGCTGTCGTCACTCGACCAAAGGTTCACCTGGCAGATGCCAGCCATCCGATCCTGGAGACCATGCAAGCCTCGGGCGTCCCCACCTGGTATTTCGAGCAACTCGAAAGTCCTTGCCTGGATCCCTACGTCGATGGCCGGAGCGTGGCTCGGCGCCGGGAACAGATCGAACGAGTCGGTAAAGCCTAA",
    "translation": "MSGLFAVFNRSGAPVNEADLARALGRMSVRGRDDSRMWHQSNAGLAAAVTFWSSEEKPCDLPSTLDGSCHVIAAALLSNRPELRRQLHGAGHATTPETSDAELILRSYTAWGERCTEHLRGEFAAVVWDPARQKLLGFVDHFGTLPLFYTDTSEMAVLSTDLEAIATFRGVDRTLSPEAIVDTLIYGFQQSRSSTIYEHIHRLPGGHLLEVAPEKARRSVYWTPDEWSPLRNVSDPQSLVDEFHAHLERAVLARARLPNLGVELSGGLDTSSIAQVLSEDARNRRPQRHLRAFCHGFSGPAGEAEPALARQTADHLGLDLEVLWQDRGHPLGTTKPSHFPPEPQGFLWDAGLLHGRNAAAHSPILFSGHGGDMILGYVEYHWMRQLRRRPMGAFRDLLTFFRMYGFKRPPLGLRNWVRKWQGANESNMPVPTWLRQDLVDRVAPLDRVTHIETRSESFRQRLGMWHSPVSSMIFSRTDAAYYDAPIRCVYPYFDFDLWEFLQSVPPIPYFVKKALLRVDMKHRLPTAVVTRPKVHLADASHPILETMQASGVPTWYFEQLESPCLDPYVDGRSVARRREQIERVGKA",
    "product": ""
   },
   {
    "start": 4484,
    "end": 4669,
    "strand": 1,
    "locus_tag": "ctg144_5",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg144_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg144_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,484 - 4,669,\n (total: 186 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg144_5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg144_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGAAAAAGTTCGGTCCAAATCTGGACGGTCAGACAACTCGGCGGAGTGCAATTCCGCCACGCCCGCCTACGTGAAGCCGAAACTCCATGACTTCGGAAAAATGCAGGACATCGTGCACACTGGACAGGACAGCTTCATGGACGATACCGGGATGTACGAAGGCACTGTTGGTACGATGAGCTGA",
    "translation": "MEKVRSKSGRSDNSAECNSATPAYVKPKLHDFGKMQDIVHTGQDSFMDDTGMYEGTVGTMS",
    "product": ""
   },
   {
    "start": 4709,
    "end": 6052,
    "strand": 1,
    "locus_tag": "ctg144_6",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg144_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg144_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,709 - 6,052,\n (total: 1344 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg144_6\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg144_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCCGGGCCGGCCTCCCTGGCCGGTTTGCTCCTTAGCCAATCTCACACGCATCCGGTCCCAAAAGTCATCACGCAAGCCCTTTGCGGTCATCAACGACTGTTCGATGCCTTTACGCTGGCCGGATTCGAGTGTGATCTAGGCCAGGCCAATAGATTTGACTTCCAGGTTGCGGCATTCAACCGGGACCGTGAATACGCCAGGCTGCTGGCGCAACTCGGTTCGCTTCAGTCCGACTGCCAGGGAGCAGAAGCGGACCTAGCTGGCGCCTTGCGGCTCTCGCTCAAACAAGTCATGGCACCGGATGACTGTTTTGGAACGCCGCACAGCCTTTGGCTGGAGTTCGACCTGGTCGATCCCGGCTCACTGGGTCGTGGTCCTTCACTGTTCCTGGCACTGGCCCATCCCGCCACGTCAGAACAGGCCGTCCAGTTCACCGACTACCTGGCAAGGCTCACCTCAGCGGCAGGTTCGGTGAAACTACCGGGCGGGTTGCAAAATCTTCTGGAACTCCTGGGGCCGGGTGACTCCATCAGTCATGTGGGCTGGATGTTGGGCCGGGCGACACCCAGCTTGCGACTGGTGGTTCGCGTTGCAGACGGCACCAATCCGCTCGATGTCGGCTCTCGCTTGCCGGGCGAGCGACGACCCGGCGCCTGGGCGCCCCTGCTGGCTGAGCTGTCAGATGACCTGCAATTCAACCGACTCTGTATTGACGTATTCCCTGACCGGTTTGAAATCAATGGCATAGAGTGCTTTCCCCTCAGCGGACACCAGCGAAGCGCTGCCCTCGCCGGCATTCTCTCCAGGCTCGAGCGCAATGAGGTCTGCACACCCGAGCACCGGAATCGGCTGCAGGACTGGGAGGGTTGCCATTTTCCCCGCCCGGATGAGACGTGGCCATTGGCGATGATCTGGCCCGGCCTGACAAAGCCCGCGAATGAGTTCACGGTATTCCAGAGAAGCGTCAGTCACTTCAAGGTGATGGGACGCACCTCCGGGGAACCCTTGGTCAAGGCCTACTGGGGGGGCGAGCTGACTTATTGGTCACTCGGGTCCAGTAACGTCCTGCCAAACGAAGGGGCCATCGAGGCAGAGCGCGGCCACACTTCGCAACTGCAGCACATGCTTGATTTTGTCCGGGCGTGCCGAAACGACGACGCCCTCAGAACGAGCCTTGAATCGGAATTGAACCCGAGCCTCGAGAGGCTCACAGAAGCGGGGCGTCAGTTCGGGTTTCGCGTGGAACCCAGATCATTCCACCAGGCCTTCGCCATCGACTGGCAAATGCGGTGGCGGCAGCTACACGAAGTGGGCGCCTTACCGGTTGAAACAACTGGTTAA",
    "translation": "MPGPASLAGLLLSQSHTHPVPKVITQALCGHQRLFDAFTLAGFECDLGQANRFDFQVAAFNRDREYARLLAQLGSLQSDCQGAEADLAGALRLSLKQVMAPDDCFGTPHSLWLEFDLVDPGSLGRGPSLFLALAHPATSEQAVQFTDYLARLTSAAGSVKLPGGLQNLLELLGPGDSISHVGWMLGRATPSLRLVVRVADGTNPLDVGSRLPGERRPGAWAPLLAELSDDLQFNRLCIDVFPDRFEINGIECFPLSGHQRSAALAGILSRLERNEVCTPEHRNRLQDWEGCHFPRPDETWPLAMIWPGLTKPANEFTVFQRSVSHFKVMGRTSGEPLVKAYWGGELTYWSLGSSNVLPNEGAIEAERGHTSQLQHMLDFVRACRNDDALRTSLESELNPSLERLTEAGRQFGFRVEPRSFHQAFAIDWQMRWRQLHEVGALPVETTG",
    "product": ""
   },
   {
    "start": 6056,
    "end": 7030,
    "strand": 1,
    "locus_tag": "ctg144_7",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg144_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg144_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,056 - 7,030,\n (total: 975 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) NTP_transf_5<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg144_7\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg144_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg144_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGCGGCGCTCGAAACGTCTGATCAATACTCTGGCGACGACGATCACCGGGGCCAGGGCCAACGTTGCGGGCATCAACGTCAGCCAATTGGTCGATCTGGCGGTCAGTCACGGCGTTCATGGGCTTCTCAACGAGGCGTCGACCCAGGGGCGGATCGACGGTCTGCCTCAACCCGAATGCCAACGGTTACATCGCCTCGCCCTGGCGGAGGCAGCAGCCGACCTGACGCAGGTGGCGGCCTTGCGGGAATTGCTCAGTTCGTTCGAGACAGAAGGCTTTCGTCCCTTGTTGCTCAAGGGTCTTCCCGTCGCGGCGCTTCACTATCCTAAGCGCCACTTGCGCCACCGGACCGACGTGGACCTGTATCTGTCACCGGGACACTCCACAAACGCGGCTCAGGTCCTTCACTCCCTGGGGTACCGAGTCTACGGGGTCAGCCGGCAAAACCCGACGGTGCACCAGTTCCACGCATCGCGGGGCGAAAGCTCACCCATACCCATTCATTTCGACTTGCACTGGGGCATCAGCAACCGCGCGTTGTTCCGGTCTGTCCTGCCATTCGACGCCGTGGCGCCAAACGCACAATCCATTTCCGATCTGGACCCGGCCGCCCTCACCCTGTCCAATCCGCACCTGTTGATTCATGCTTGCGTGCACCGAATCGCCCATGGCAGGAACTCGCAGAGAGACCGTCTGGTGTGGTTGAACGACATCCGCCTGATCCTGGCCAGCCTGGATGACCAGGAACGAGGGCGCTTCGTCGACGACGCGCTGGCTTGGAAGGTGGGCGCCGTTTGTGCCGACGGTATTGCCTCGATGAGCGCCGCGTTCCAGCAAGTGCCCGATGCGGGCCTTTGTACCGCCTTGACCGCTCGACAGGCGCTGGAGCCCAGCGCCAAGCTGAGCCGGGCCGGGCGATGGCGGTGGATGCTGTCGGACGTGGCGGCAGAACCCGGCCTGCCGGCCCAGTGG",
    "translation": "MKRRSKRLINTLATTITGARANVAGINVSQLVDLAVSHGVHGLLNEASTQGRIDGLPQPECQRLHRLALAEAAADLTQVAALRELLSSFETEGFRPLLLKGLPVAALHYPKRHLRHRTDVDLYLSPGHSTNAAQVLHSLGYRVYGVSRQNPTVHQFHASRGESSPIPIHFDLHWGISNRALFRSVLPFDAVAPNAQSISDLDPAALTLSNPHLLIHACVHRIAHGRNSQRDRLVWLNDIRLILASLDDQERGRFVDDALAWKVGAVCADGIASMSAAFQQVPDAGLCTALTARQALEPSAKLSRAGRWRWMLSDVAAEPGLPAQW",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 2043,
    "end": 4348,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 7031,
    "product": "lassopeptide",
    "category": "RiPP",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "lassopeptide",
  "products": [
   "lassopeptide"
  ],
  "product_categories": [
   "RiPP"
  ],
  "cssClass": "RiPP lassopeptide",
  "anchor": "r144c1"
 },
 "r170c1": {
  "start": 1,
  "end": 5466,
  "idx": 1,
  "orfs": [
   {
    "start": 69,
    "end": 491,
    "strand": 1,
    "locus_tag": "ctg170_1",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg170_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg170_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 69 - 491,\n (total: 423 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg170_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg170_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAACCGGTCCCGAATCGTCCTGCACGCCCTCGCCATTGCCGCCGTCCTCAACCTGGCCGCCCTGGCCACCCCGGACAGCGCCGCCTGGGCCGGCAAGCCGATCCAGGACATCAAGGATGTGTCGATTCCCGCCGGCATGGACATGAAGGCCATCGGCGACGCCATCATCGACGGCTGCGCCGTGCGCAGCTGGATTGCCGAGGAAGTGGGCCCCGGGCACATGCAGTGCACCGTCTACGTCCGTTCCCACATGGCCAAGGTCAACATCAACTACGACACGTCCTCGTACTCCATCACCTACGCCGACAGCGAGGAGCTGGACTACGACGCCGGTGATTACGAGATTCACCGAAACTACAACAGCTGGGTCCAGAACCTGAACGGCGACATCCGCACGGCGCTGCTGCGCGCCTCGCGCTGA",
    "translation": "MNRSRIVLHALAIAAVLNLAALATPDSAAWAGKPIQDIKDVSIPAGMDMKAIGDAIIDGCAVRSWIAEEVGPGHMQCTVYVRSHMAKVNINYDTSSYSITYADSEELDYDAGDYEIHRNYNSWVQNLNGDIRTALLRASR",
    "product": ""
   },
   {
    "start": 529,
    "end": 1110,
    "strand": 1,
    "locus_tag": "ctg170_2",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg170_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg170_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 529 - 1,110,\n (total: 582 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg170_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg170_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGACGCCACCGCCGGCCGGTACGCTGCCCCCACCCCGGCTCGAAACCCTTTCCGCCGACGGCCGCCCCCTGGCGCAGTGGGGCCTGCTGGCCGCCGGCGCCCACGACACTTCCGTGATGGCGGAGGCCCTCGATGCCCGCGACCGGCAGCGCGCCGACGGGTTTTCGAACCCGGAACGGCGTTCTGAGTACATCGCCTCGCGGTGGCTGCTGGGGCGGCTGCAGGTCCAGGGCCCGTCCTCCCTGAGCCACTGCCGCCGCTGGCTGGCGGCCGCGGCCACCCCCTGGGCGGCGATCGGTGTCGACGTCGAATGCCGCCTGCCGCGAGCGGTGGACGAGGTCGCGGAACGACTGGGGTGGGAAGACGTCCCGAACGCCCGCTACCTGCAGGCGTGGACCCTGTGGGAAGCCTGGCGGAAACTCGAGCGGGGTTCGGTGCTGGACGCGCCGGACCTGCCCTATGCACTCGCCCTGCGGGAATCGGAACGCTTCTTCGACGGGCCGAGCGAAGTGTCGGGCGCCTGGTGGTTCAGTCGCGATCTGGGCGATGCCGTGCTCAGTGTCGTCGTGCGCAGGGCGTGA",
    "translation": "MTPPPAGTLPPPRLETLSADGRPLAQWGLLAAGAHDTSVMAEALDARDRQRADGFSNPERRSEYIASRWLLGRLQVQGPSSLSHCRRWLAAAATPWAAIGVDVECRLPRAVDEVAERLGWEDVPNARYLQAWTLWEAWRKLERGSVLDAPDLPYALALRESERFFDGPSEVSGAWWFSRDLGDAVLSVVVRRA",
    "product": ""
   },
   {
    "start": 1117,
    "end": 2349,
    "strand": -1,
    "locus_tag": "ctg170_3",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg170_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg170_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,117 - 2,349,\n (total: 1233 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) arylpolyene: APE_KS1<br>\n \n  biosynthetic-additional (smcogs) SMCOG1022:Beta-ketoacyl synthase (Score: 306.1; E-value: 7e-93)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg170_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg170_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAACCGACGCGTCGTGGTGACGGGCGCGGCCGGGCTCACCGGCCTGGGCGCGGACTGGCCGACCATCCGCGCCGGCCTGGAGGCAGGACGCAGCGCGGTGCGGTACTTCCCCGAGTGGGAGGAGATCCGTGGCCTGAACTGCAAACTGGGCGCGCCCGCCGCCGATTTCGAACTGCCGGAGCACTACACGCGCAAGCGCACCCGGACCATGGGCCGCAATGCGCTGATGGCGGTGCGGGCCACGGAGCTGGCGGTGGAACAGGCGGGCCTGGCCGGCCACGAGGTACTGGGCTCGGGCCGGACCGGCGTGTCCTACGGCTCATCCTCCGGCAGCACCGACGCGCTGGCCGAAATGGCCCACGTCCGGGTCTCGGACAACGCCCGCAAGGTCAACGCCACCAGCTACGTGCGCCTGATGGGCCACACGGCCGCAGCCAACATCGGCATGTTCTTCGGCCTGCGTGGCCGGGTGATCCCCACCATCAGCGCCTGCACGGCGGGCAGCCAGGGCATCGGCTATGCCTGGGAAGCCATCCGCCACGGGCTGCAGGACGTGATGCTGGCCGGCGGCAGCGAAGAACTGTGTCCCTCCCACGTGGCCGTGTTCGACGTCCTGTACGCCACCAGCACCTCGAACGACCGGCCGGAGCACACGCCGCGCCCCTTCGACGCGGACCGGAACGGGCTGGTGGTGGGCGAGGGCGCGGCGACACTGGTGCTGGAGTCGCTGGACCACGCCCGGGACAGAAACGCGCCGATTCTCGCCGAACTGACGGGATTTGCGACGAACTCTGATGGAAATCACGTGACACGTCCCGATCGCGATTCCATGGCGCGGGTCATGCGCATGGCGCTGGAGCGCGCGGACCGGGCGCCGGCGGACATCGGCTACGTGAACGCCCACGGCACCGCCACGGAAGCCGGGGACGTGGCCGAAAGCCTGGCCACGGAGCAGGTGTTCGGCAGCGACACGCCCGTGGCCTCGCTCAAGGGCTACCTGGGCCACACGCTCGGCGCCTGCGGCGCCATCGAGGCCTGGCTGAGCATGGAAATGATGCAAGCGGGATGGTTCGCGCCCAACCACAACCTGGAACGGCCGGATCCGGACTGCGGCCGGCTGGATTACCTGATGGGCGAGGCGCGCGCGTTGGGCGTGCGCGCGGTGATGAGCAACAACTTCGCCTTCGGCGGGATCAACACCTCCCTGGTGTTCGAGCGGTTCGAAGGCTGA",
    "translation": "MNRRVVVTGAAGLTGLGADWPTIRAGLEAGRSAVRYFPEWEEIRGLNCKLGAPAADFELPEHYTRKRTRTMGRNALMAVRATELAVEQAGLAGHEVLGSGRTGVSYGSSSGSTDALAEMAHVRVSDNARKVNATSYVRLMGHTAAANIGMFFGLRGRVIPTISACTAGSQGIGYAWEAIRHGLQDVMLAGGSEELCPSHVAVFDVLYATSTSNDRPEHTPRPFDADRNGLVVGEGAATLVLESLDHARDRNAPILAELTGFATNSDGNHVTRPDRDSMARVMRMALERADRAPADIGYVNAHGTATEAGDVAESLATEQVFGSDTPVASLKGYLGHTLGACGAIEAWLSMEMMQAGWFAPNHNLERPDPDCGRLDYLMGEARALGVRAVMSNNFAFGGINTSLVFERFEG",
    "product": ""
   },
   {
    "start": 2346,
    "end": 3089,
    "strand": -1,
    "locus_tag": "ctg170_4",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg170_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg170_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,346 - 3,089,\n (total: 744 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n  biosynthetic-additional (smcogs) SMCOG1001:short-chain dehydrogenase/reductase SDR (Score: 222.7; E-value: 8.7e-68)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg170_4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg170_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCGAATCTCGTCCTTCCGTCCTCGTCACCGGCTCCAGCCGCGGCATCGGCCGAGCGATCGCGCTCGACCTCGCCGCGCACGGCTACGACCCGGTGGTTCATTGCCGCGGCAGCCGTGAAGCGGCCGAGGGCGTGGCCGCCGAAGCCCGGCAGGCCGGGGCGGGAGCCCGCGTGCTGCAGTTCGACGTCTGCGACCGGGCGGCGACCCGCGCGGCGCTGGAAGCGGACGTTGCCGAACACGGCGCGTACTACGGGGTCGTGCTGAACTCGGGCATCGCGCGCGACGGCGCGTTCCCCATGCTGGGCGAGGAAGACTGGGACGCGGTACTGCGCACCAACCTGGACGGCTTCTACAACGTGCTCCATCCCCTGGTCATGCCGCTGGTGCGGGCGCGCCGGCCGGCGCGCATCGTCACCCTGTCCTCGGTCTCCGGCGTGGTCGGCAATCGCGGGCAGGTGAACTACAGCGCTTCCAAGGCCGGCATCATCGGCGCCACCAAGGCGCTGGCCACCGAGCTGGCCAGTCGCAACATCACCGTGAACTGCGTCGCCCCCGGCCTGGTCGACACCGACATGATGGAAGCCATCCCCGAGGACCTCCGTGAACGGATGATCGAGCACATTCCCCTGGGCCGCGCCGCCCGCCCGGAGGAGGTCGCCGCCGTGGTGCGCTTCCTGCTCAGCCCCGAGGCGTCCTACGTCACGCGGCAGGTCATCGGCGTGAACGGGGGCATGGCGTGA",
    "translation": "MSESRPSVLVTGSSRGIGRAIALDLAAHGYDPVVHCRGSREAAEGVAAEARQAGAGARVLQFDVCDRAATRAALEADVAEHGAYYGVVLNSGIARDGAFPMLGEEDWDAVLRTNLDGFYNVLHPLVMPLVRARRPARIVTLSSVSGVVGNRGQVNYSASKAGIIGATKALATELASRNITVNCVAPGLVDTDMMEAIPEDLRERMIEHIPLGRAARPEEVAAVVRFLLSPEASYVTRQVIGVNGGMA",
    "product": ""
   },
   {
    "start": 3086,
    "end": 3553,
    "strand": -1,
    "locus_tag": "ctg170_5",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg170_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg170_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,086 - 3,553,\n (total: 468 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg170_5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg170_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGAGCGCGAACCTGCGCGAACTCGAGGCCCTGCTGCCCCATCGCCCGCCCCTGCTGCTGCTGGAGCGCCTGGTCGAGGGTGATCCCGACCGCGCCGTGGCCGATGTCCGGGTCCGGGCCGGCGATCCCCTGGTGGAAGCCGGCCGCGGCCTGCCGGCCTGGGCGCTGGTGGAAGTGTTCGCCCAGGCGGCCGCCCTGATCGGTGGACTGTCAGCGCGCGCACGTGGCGAGGCCGTGGCCCAGGGCTTCCTGCTCGGCACCCGGCGCCTGGACTGCCCGGTCTCCCACCTGCCGGTGGGGTCGCAGTTCACGGTGGAGGCGCGCGCCGCCTTCACGGACGGTTCCGGCATGGGCGCTTACCATTGCCGCATCCGCGAACCGCAGTGGCCGGTGGAATGCACGCTGTCGGTCTACACCCCGCCCGCAGTCATGGCGACGCCGGGCGACACCGGGAACCCCGAACCATGA",
    "translation": "MSANLRELEALLPHRPPLLLLERLVEGDPDRAVADVRVRAGDPLVEAGRGLPAWALVEVFAQAAALIGGLSARARGEAVAQGFLLGTRRLDCPVSHLPVGSQFTVEARAAFTDGSGMGAYHCRIREPQWPVECTLSVYTPPAVMATPGDTGNPEP",
    "product": ""
   },
   {
    "start": 3550,
    "end": 4395,
    "strand": -1,
    "locus_tag": "ctg170_6",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg170_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg170_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,550 - 4,395,\n (total: 846 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Glycos_transf_2<br>\n \n  biosynthetic-additional (smcogs) SMCOG1123:polyprenol-monophosphomannose synthase ppm1 (Score: 64.4; E-value: 2e-19)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg170_6\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg170_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCACGCCCGGGACCGCATCCGGGCCGCCGGAAACCCCGTCCCGGCCACCGGGAACCCCGCCCGGGCCACCGGAAACAAGCTTCCGGCCGGCCTTGCTGGTGCCGCACTACGATCACCTGGAGCAGTTCGAGCGCTTCCTGCCGAAATTGATGGCCACGGAGGTGCCCTTGCTGGTGGTGGACGACGGCAGCCCGGCCGAGCAGCGCGAACGCCTGTCCGCCCTGGCGGCTTCAGCCGGTTTCGAGCTGCTGGAGCGGCCGGAGAACCGGGGCAAGGGCGACGCCCTGCTGGCCGGCTTCGCCTGGGCCGACCGCCTGGGGTACACCCATGCCCTGCAGATGGACGCTGACGGCCAGCACGACACCGGCGACGTGGCGCGCTTCCTGGACTGCGCGCGCGAACGGCCCCGCACCCTGGTCTGCGGCGCGCCGGTGTTCGGCAAGGACGCCCCCTGGATCCGTGTCTGGGGCCGCAAGCTCACGGACTTCGTCGTCGCGCTGGAAACCTGGTCCTTCGGCGTGCGGGACGCGCTTTGCGGCTTCCGCGTCTATCCCCTGGCGGGCACGCTGGAAATCATCGCCCGGGACCGTCCCGGTGAGCGCATGGACTTCGACGCCGACATGCTGGTGCTGGCGCGCTGGCACGGCATGGACCTGCACTTCCTGGACACGAAGGTGGCCTACCCCGAGCAGGGCCGCTCCCATTTCCGCTACGTCCGCGACAACCTGCGCATGGTGGGCCTGCATGTCCGCCTGCTGCTGCGCATGTTGCTGCGCATCCCGGTGGCCGTCACCGACCGGCTGACCGGGCGCATGGGCCGTGTCACGGGGGAGCCGCGTTGA",
    "translation": "MSTPGTASGPPETPSRPPGTPPGPPETSFRPALLVPHYDHLEQFERFLPKLMATEVPLLVVDDGSPAEQRERLSALAASAGFELLERPENRGKGDALLAGFAWADRLGYTHALQMDADGQHDTGDVARFLDCARERPRTLVCGAPVFGKDAPWIRVWGRKLTDFVVALETWSFGVRDALCGFRVYPLAGTLEIIARDRPGERMDFDADMLVLARWHGMDLHFLDTKVAYPEQGRSHFRYVRDNLRMVGLHVRLLLRMLLRIPVAVTDRLTGRMGRVTGEPR",
    "product": ""
   },
   {
    "start": 4392,
    "end": 4763,
    "strand": -1,
    "locus_tag": "ctg170_7",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg170_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg170_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,392 - 4,763,\n (total: 372 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg170_7\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg170_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCTGAGGCCCGGCCAGCCAACCCAACCGAACCTTCCGCTCCGCCCGTCATCGACCGGGTGCACGACGGCGACACGGCGCAGTGGCGTCTCCGGGTCGGCGGCGACTGCCCGTGGCTCGAAGGCCATTTTCCCGAACGTCCCGTCCTGCCCGGCGTGGTGCTGCTGCGCTGGGCCATCCAGGCCGCGGTTGACACCTGGCCCGAACTGGACACCGTCACGGGCGTGAGCAATCTCAAGTTCCGCAACCCGGTTCTGCCGCCGGCCGAGGTGGTCCTTCACCTGGCGTTCGACGCCTCCCGGCGCCACATCGATTTCCGCTACGCCCGGGACGGCAAGGACTGCGCCCAGGGCCGGGTGCGCTTCGCATGA",
    "translation": "MAEARPANPTEPSAPPVIDRVHDGDTAQWRLRVGGDCPWLEGHFPERPVLPGVVLLRWAIQAAVDTWPELDTVTGVSNLKFRNPVLPPAEVVLHLAFDASRRHIDFRYARDGKDCAQGRVRFA",
    "product": ""
   },
   {
    "start": 4796,
    "end": 5041,
    "strand": -1,
    "locus_tag": "ctg170_8",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg170_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg170_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,796 - 5,041,\n (total: 246 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg170_8\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg170_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGAACACCGACATCGACTCCTACCAGTACGTTCGAAACCTGCTCGTCGACCAGTTCGACGTGCCGGCGGACGCCATTCGCCCGGAGGCCCTGCTGGCCGACGACCTGGGCATCGACAGCATCGACGCCGTGGACATGATCGTGCACATGCGCGAAGTGACCGGCGAGCGCATCACGCCCGAACGCTTCCGGCAGGTGCGCACCGTGCAGGACGTGGTGGACATCGTCGATCGCGTCCTCGCCTGA",
    "translation": "MNTDIDSYQYVRNLLVDQFDVPADAIRPEALLADDLGIDSIDAVDMIVHMREVTGERITPERFRQVRTVQDVVDIVDRVLA",
    "product": ""
   },
   {
    "start": 5122,
    "end": 5466,
    "strand": -1,
    "locus_tag": "ctg170_9",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg170_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg170_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,122 - 5,466,\n (total: 345 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg170_9\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg170_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg170_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "CGCCTGCTCGAGGCGGCGGTGGAACGGCTGCAGGCAGGGGGCACCCTGGTGCTGTTTCCCCAGGGCACGCGGACGCGGCCGGGAGAAGAGCCACAGTTCCGTCGCGGGGCGGCGGTGATCGCCGCGCGGGCCGGCGCGGACCTGCTCCCGGTGCGGATCACCTGCGAGCCGCCCGTGCTGCGCAAGGGGGATCCCTGGTTCCTGGCGCCGCCGCGGCGGCCCCATTTCACGCTCGAAGCCCTGCCGCGCCTGTCGCCGGAACGGTGGACGGCAGAGGGGGAGCGTGCCGGCACCGTGCGGCTGACGGAAAGGCTTAGTGAACTCCTGCTCGAAGCGGTACACTAG",
    "translation": "MLLEAAVERLQAGGTLVLFPQGTRTRPGEEPQFRRGAAVIAARAGADLLPVRITCEPPVLRKGDPWFLAPPRRPHFTLEALPRLSPERWTAEGERAGTVRLTERLSELLLEAVH",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 1116,
    "end": 2349,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 5466,
    "product": "arylpolyene",
    "category": "PKS",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "arylpolyene",
  "products": [
   "arylpolyene"
  ],
  "product_categories": [
   "PKS"
  ],
  "cssClass": "PKS arylpolyene",
  "anchor": "r170c1"
 },
 "r203c1": {
  "start": 1,
  "end": 6035,
  "idx": 1,
  "orfs": [
   {
    "start": 3,
    "end": 170,
    "strand": -1,
    "locus_tag": "ctg203_1",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg203_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg203_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3 - 170,\n (total: 168 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg203_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg203_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCTGAGCGCCTGCGAACGCTGCAGGAGCGCTTCGCCGCCCACCTCCGCGACCCGGCCGCCACCCCTGCCCCGGAGGACGCGGAAGACCGGCGCATGGCCAGCTACCAGCGCCGGTTCTCCACCAACGTGTCCAACCTCGTGGCCCGGAGTGTCCCGGTGCTGCGC",
    "translation": "MAERLRTLQERFAAHLRDPAATPAPEDAEDRRMASYQRRFSTNVSNLVARSVPVLR",
    "product": ""
   },
   {
    "start": 163,
    "end": 1035,
    "strand": -1,
    "locus_tag": "ctg203_2",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg203_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg203_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 163 - 1,035,\n (total: 873 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) RiPP-like: DUF692<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg203_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg203_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCCAACGACCTTTTCCCGTACAGGGAACGGGTCTCGGACTGAGGCGGGCCCTGCTGGGCCCGCTTCAGGATGCGGACCCCGACCGGTTGGAAGCCAGCGTCGACTTCATGGAGGTCGCGCCGGAAAACTGGATCGGCGTGGGTGGCCGCCTGGGCCATGCCCTGCGCGCCTTCACCGAACGCTTTCCCTTCGTCTGTCACGGCCTGTCGCTCTCGCTGGGCGGGCCGGCCCCGCTGGACGAAACGCTGCTGCGCCGCACACGCGCGTTCCTGGACGCGCACGACATCCGCTGCTTCACCGAGCACCTGAGCTACTGTTCCGACGCGGGGCACCTGTACGACCTCATGCCCATTCCGTTCACCCGCGAGGCGGTGGACTACGTGGCCGAGCGAATCCGCCGGACCCAGGACCTGCTCGGCCGCCGGATCGGCATCGAGAACGTGTCCTACTACGCGGCGCCCGGCGCCGAACTCAGCGAAATCGAATTCATCAACGCGGTGGTCTCCGAGGCCGACTGCGACCTGTTGCTGGACGTGAACAACATCTGGGTCAACGCCATCAACCACGGATACGACCCGGTGGAATTCCTGCGGGACCTGCCGGGCGATCGCGTGGTCTACGGCCACGTCGCCGGCCATCACGAAGAGGCGCCCGACCTGCGGGTGGACACCCACGGCGCCGCGGTGATCGATGGTGTCTGGGACCTGCTGGACGTCGCCTACGGCACCTTCGGCGCCTACCCCACCCTGCTGGAACGCGACTTCAACTTCCCGTCCGTCGATGAACTGCTGGCCGAGGTGGACCGCATCCGCCTGGCCCAGGACCGGCACGCCGCGGACTCCGCGCTGGACGCCCGGCGCCATGGCTGA",
    "translation": "MSQRPFPVQGTGLGLRRALLGPLQDADPDRLEASVDFMEVAPENWIGVGGRLGHALRAFTERFPFVCHGLSLSLGGPAPLDETLLRRTRAFLDAHDIRCFTEHLSYCSDAGHLYDLMPIPFTREAVDYVAERIRRTQDLLGRRIGIENVSYYAAPGAELSEIEFINAVVSEADCDLLLDVNNIWVNAINHGYDPVEFLRDLPGDRVVYGHVAGHHEEAPDLRVDTHGAAVIDGVWDLLDVAYGTFGAYPTLLERDFNFPSVDELLAEVDRIRLAQDRHAADSALDARRHG",
    "product": ""
   },
   {
    "start": 1072,
    "end": 1350,
    "strand": -1,
    "locus_tag": "ctg203_3",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg203_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg203_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,072 - 1,350,\n (total: 279 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg203_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg203_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCTGACAAGACCGTACTGATCAAACCCGTTGCCGCCATCTGCGGTGTCGCGCTCGTTTCATCCCTGGCCGCCGGCACCGTGCTGGCCGACGACCCCTTCGAACTCACCGATCTGGACGCCGGCTACATGCTCGCAGGTGACGACAAGGGCGAAGAAGGCAAGTGCGGCGAAGGCAAGTGCGGTGAGGAAGGCGAAGAGGGAGAAGAAGGCGAGGAAGGTGAAGACGAGGACAAGGGTGAGGAAGGCAAGTGCGGCGAGGGCAAATGCGGCTCCTGA",
    "translation": "MADKTVLIKPVAAICGVALVSSLAAGTVLADDPFELTDLDAGYMLAGDDKGEEGKCGEGKCGEEGEEGEEGEEGEDEDKGEEGKCGEGKCGS",
    "product": ""
   },
   {
    "start": 1723,
    "end": 2361,
    "strand": -1,
    "locus_tag": "ctg203_4",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg203_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg203_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,723 - 2,361,\n (total: 639 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg203_4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg203_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATCAAGGCGGACCGTGTCGAATTCTTCCGGCGCCTGCGCGAGCACGACCCGAACCCCACCACGGAGCTGGAGTACGACAGCGCCTTCGAACTGCTGGTGGCGGTGATTCTTTCCGCCCAGGCCACGGACGTCGGCGTGAACAAGGCCACCCGCCGCCTGTTTCCGGTGGCCAACACCCCTCGCGCCATTCTCGACCTGGGGCTGGAGGGGCTCAAATCGCACATCCGCACCATCGGGCTGTTCAATGCCAAGGCCGCGAACATCATCGAGACCTGCCGGATCCTGCTGGAACGCCACAATGGCCAGGTACCGGACGAGCGGGCCGCCCTCGAGGCCCTGCCGGGGGTCGGGCGCAAGACCGCCAACGTGGTCCTGAACACCGCGTTCGGCCAGCCCACGATGGCCGTGGACACCCACATCTTCCGCGTGGCGAACCGCACCGGGCTGGCCATCGGCAAGACGCCGCTGGAGGTCGAGCGCAAGCTGCTCCGTAGCGTTCCGGAAGAATTCCTGCAGGACGCCCACCACTGGCTGATCCTGCACGGGCGCTACACCTGTACGGCCCGCAAGCCGCGTTGCGCCGAGTGCCTGGTCGCCGATCTCTGCCGCGAGGGCCGCAAAGGCACCTGGCGCTGA",
    "translation": "MIKADRVEFFRRLREHDPNPTTELEYDSAFELLVAVILSAQATDVGVNKATRRLFPVANTPRAILDLGLEGLKSHIRTIGLFNAKAANIIETCRILLERHNGQVPDERAALEALPGVGRKTANVVLNTAFGQPTMAVDTHIFRVANRTGLAIGKTPLEVERKLLRSVPEEFLQDAHHWLILHGRYTCTARKPRCAECLVADLCREGRKGTWR",
    "product": ""
   },
   {
    "start": 2358,
    "end": 3068,
    "strand": -1,
    "locus_tag": "ctg203_5",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg203_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg203_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,358 - 3,068,\n (total: 711 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg203_5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg203_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACGGAATCGACTGACCCGGGCGCGCCGAACACCCCCCGCACGGGCGAGGTCTTCCGCGACGCCTTCTGGCGCCAGAACACGGGGCTGGTCGTGCTCCTGGGCCTGTGCCCGCTGCTGGCGGTCTCCGGTTCGGTGACGAACGCCCTGGGTCTGGGCCTGGCGACCACCGTGACCCTGGCGGTTTCGAACCTCTGCGTGTCCCTGGCCCGGGGCCTGCTGCGGCCGGAAATCCGCATTCCCGCTTTCGTGCTGATCATCGCCTCGACCGTGACGGTGATCGAACTCCTGATGCAGGCCTGGTTCCAGGGCCTGTACCTGGCGCTGGGCATCTTCATTCCGCTGATCGTCACCAACTGCGCCATCATCGGGCGGGCGGAGGCGTTCGCCTCGCGCCACGCGCCCTGGCCCGCGCTGGTGGACGGCTTCGCCACCGGACTGGGCTTCTGCCTGACCCTCGTGCTGCTCGGCGCCGTGCGGGAACTGGCGGGCCACGGGACACTGCTCGCGGACGCCCATCTGCTGGTGGGCGAGTGGGGCCGGAGCCTCGAATTCGAAGTCATTCCCGGCCACCCGGGATTCCTGCTGGCCATGCTGCCCCCGGGCGCGTTCATCGCCCTCGGCATGCTGGTCGCGGCGCGCAATGCCTGGCAGCAGCGCCGGGACGCAAAACCGAGCGGGGCCACCGCCCGCGAGGCCCTGGCGCAATGA",
    "translation": "MTESTDPGAPNTPRTGEVFRDAFWRQNTGLVVLLGLCPLLAVSGSVTNALGLGLATTVTLAVSNLCVSLARGLLRPEIRIPAFVLIIASTVTVIELLMQAWFQGLYLALGIFIPLIVTNCAIIGRAEAFASRHAPWPALVDGFATGLGFCLTLVLLGAVRELAGHGTLLADAHLLVGEWGRSLEFEVIPGHPGFLLAMLPPGAFIALGMLVAARNAWQQRRDAKPSGATAREALAQ",
    "product": ""
   },
   {
    "start": 3052,
    "end": 3714,
    "strand": -1,
    "locus_tag": "ctg203_6",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg203_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg203_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,052 - 3,714,\n (total: 663 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg203_6\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg203_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAGTGAACCACGAGCCGTGACGACCACCACGACGCCGCCCTGGCGGGCCGGGCTGCTGCTGGCCACCCTGGCCGTCATCGGCGTGGGCCTGCTTGCGGGCGTCCACGAACTCACGGCCGAGCGCATCGCCGCGCAGGAGCGGGCCACCCTTCTGCAGCGGCTGGACGAGGTCTTGCCAGCGGACTGGTACGACAACGACCTGCTCGCGGATGTGGTGATCGTGGAGGCGCCGGAGGCCCTGGGCCACGACCGGCCGATTCATGTCTACCGGGCCCGGCGAGGCGGTCACCCGGTGGCCGCCATCCTCGAAGTGATCGCGCCGGACGGCTACAACGGCGACATCGCGCTCCTGATGGGCGTCACCCTCGAGGGAACGGTGACCGGCGTCCGGGTCGTCCGTCACCGCGAAACACCGGGTTTGGGCGACCCCATCGAGACCGCGCGCAGCGACTGGACGCTCGGCTTCGACGGACGGTCCCTCGGCGACCCGCCGGCGGAGCGGTGGACGGTGCGCAAGGACGGCGGCGCCTTCGATCAATTCACGGGTGCTACCATCACGCCGCGCGCGGTCACCCGGGCGCTGGCCCGGGCCCTGGCCTGGTTCGCGGCACAGGACGCGACGCTCTTTGACAGGAAGGCGAACGATGACGGAATCGACTGA",
    "translation": "MSEPRAVTTTTTPPWRAGLLLATLAVIGVGLLAGVHELTAERIAAQERATLLQRLDEVLPADWYDNDLLADVVIVEAPEALGHDRPIHVYRARRGGHPVAAILEVIAPDGYNGDIALLMGVTLEGTVTGVRVVRHRETPGLGDPIETARSDWTLGFDGRSLGDPPAERWTVRKDGGAFDQFTGATITPRAVTRALARALAWFAAQDATLFDRKANDDGID",
    "product": ""
   },
   {
    "start": 3711,
    "end": 4739,
    "strand": -1,
    "locus_tag": "ctg203_7",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg203_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg203_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,711 - 4,739,\n (total: 1029 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg203_7\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg203_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg203_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCGGACATTCCACGCCGCCGCGGCCCCGCACCTGCCCTCGAAACGCACGGTTCGTGGCGTCATGTCCCAGGTGCTGCTGGCGCTGGTCCCGGGCATCGCGGTCCACGCCTGGCTGTTCGGCCCCGGCATCTTTGTGCAGATCGTGATCGCCTCCGGCTTCGCCCTGGCCTTCGAGGCGGCCCTCTTGCGGCTGCGCGGCCGGCCGCTGGCGCCCTTCCTCACCGACGGCAGCGCCGTCGTGGCCGCGAGCCTGTTCGCCCTGTGCATCCCCCCGCTGGCGCCGTGGTGGATCGCCGCGGTGGCCATGTTCTTCGCCATCGTGATCGCCAAGCACTGTTTCGGCGGCCTGGGTCACAACGTGTTCAATCCGGCCATGGTGGGTTACGTGGTCGTGCTCATCAGCTTTCCGCTCCAATTGACCCGGTGGCCGCTGCCCCGTGAACTGTCATCCGGGACCCCGGGCCTGGACGCCACCCTGCAGGCCATCCTCGGCGGTCGAGTCATTGCGCCCGACGGCATCGACGCCCTGACGGGCGCGACACCGCTGGATGCGATCCGGACCGGCCTGGCCGAGGGCCGGCCGCTGGACACCGTGCTCCAGTCGCCGGTGTTCGGCGCGGTGGGCGGAACGGGCTGGGAATGGCTGGCTGCCGCCTTCGGCATCGGCGGCCTCTACCTGTTGTGGCGCGGCATCATCCGTTGGCAGGTGCCGGTGGCGACGCTGGGCAGCGTGTTGGTGATGGCGCTCGTCGCCTGGGTACTGAACCCTGAAACCTACCCTTCGGCGGTGCTGCACTGCCTGTCGGGCGGACTGGTGCTCGGGGCCTTCTTCATCGCCACGGACCCGGTCAGCGGCTGCGCGAGCCGACGGGGTCGACTGGTCTTCGGCGTCGGCGTCGGCGTGCTCACCCTCGTGATCCGGTACTGGGGCGGCTACCCGGACGGCGTCGCCTTCGCCGTGCTGCTCATGAACATGGCCGCGCCCCTGGTCGACCGGGTCACGCGGCCCCGGGTGTACGGGACGTGA",
    "translation": "MRTFHAAAAPHLPSKRTVRGVMSQVLLALVPGIAVHAWLFGPGIFVQIVIASGFALAFEAALLRLRGRPLAPFLTDGSAVVAASLFALCIPPLAPWWIAAVAMFFAIVIAKHCFGGLGHNVFNPAMVGYVVVLISFPLQLTRWPLPRELSSGTPGLDATLQAILGGRVIAPDGIDALTGATPLDAIRTGLAEGRPLDTVLQSPVFGAVGGTGWEWLAAAFGIGGLYLLWRGIIRWQVPVATLGSVLVMALVAWVLNPETYPSAVLHCLSGGLVLGAFFIATDPVSGCASRRGRLVFGVGVGVLTLVIRYWGGYPDGVAFAVLLMNMAAPLVDRVTRPRVYGT",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 162,
    "end": 1035,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 6035,
    "product": "RiPP-like",
    "category": "RiPP",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "RiPP-like",
  "products": [
   "RiPP-like"
  ],
  "product_categories": [
   "RiPP"
  ],
  "cssClass": "RiPP RiPP-like",
  "anchor": "r203c1"
 },
 "r268c1": {
  "start": 1,
  "end": 3187,
  "idx": 1,
  "orfs": [
   {
    "start": 3,
    "end": 191,
    "strand": -1,
    "locus_tag": "ctg268_1",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg268_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg268_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3 - 191,\n (total: 189 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) RRE-containing: Stand_Alone_Lasso_RRE<br>\n \n  biosynthetic (rule-based-clusters) RRE-containing: Lasso_Fused_RRE<br>\n \n  biosynthetic-additional (rule-based-clusters) PF05402<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg268_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg268_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg268_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg268_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATTGCCAGCGCTGAAACATTCCGCTGCAAGCCGGACGTCTTGTTCCAGGAGGTCAGCGGGGAGATTGTACTGCTGGACCTCGTTTCCGAGCGCTATTTCGGTCTGAATTCGACAGGCGCCAGGGTCTGGCAGGGGCTGTCGGAGGGTCGGACGACCGAGGAGATCATTTCCGGACTCGCCAAGGAG",
    "translation": "MIASAETFRCKPDVLFQEVSGEIVLLDLVSERYFGLNSTGARVWQGLSEGRTTEEIISGLAKE",
    "product": ""
   },
   {
    "start": 282,
    "end": 1373,
    "strand": -1,
    "locus_tag": "ctg268_2",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg268_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg268_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 282 - 1,373,\n (total: 1092 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg268_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg268_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg268_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg268_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCTGCTCGACGAAGTCCGGAATTCAGCCTACGCAAGGGCGATCAAGGGGCTGGTCGGTCCTGAAACTACGGTGCTCGACCTGGGTGCGGGGCTGGGACTGCTTGGCCTGATGGCGGCGAAAGCAGGTGCGCGGCAGGTCTATCTCGTCGACCCGTCTCCCGTATTGCTCGACGTCGAGTCGGTAATCGAGGCGAATGGCCTGGGAGACAGGGTCAGCATCATCCTCCAGCCGATCGAAGCAGCCAGCTTGCCGGAAAAGGTCGATGTCCTGGTTTCCGTAATGACCGGCAATTTCCTGCTGCAGGAAGATCTGCTGCCGACGCTGTTCTTCGCCAGGGATCGGTTCCTGAAGTCGACCGGCACCCTGGTCCCTGCGAAGGGAACCATGGTCGCTGTTCCCGTGACACTGGCGCGACCTGAGCGCCATCCGGCGTTCCGGTTGATGCGGGCCATTCAGGGCCTCGACTACGATTCCGTGCGCCGGCGATTCGTCAACCGCGTGCAGTTCGAACGCTTTTTCGAAAGCGACGCCCTTTACCTGGCTGCACCGGAGCCACTGGCGACACTGGATTTTTCCATTGCGGACAAGGCGGCGGTCGATACCACCACGACGTTCAGGGCAACCGCAAATGGTCGCCTGGATGGCCTGCTTGGGTGGTTCGATATGGACTTGGGCGACCACGCATTGTCCACGGGGCCACAGGCAGAGTCCGTACACTGGAAGCAGGCGTTCATGCCCCTGGAGACCCCCGTGTCCATTCGACAGGGTGAAGAGGTCCAGTTTTCACTCAACCGTCCTGAGCGTGGCGAATGGACGTGGAGCGTGTCCGTGGGCGGGTCTGTGCAAAGGATGTCCACGTTCTTCGGATACCGACCTGATATCGAAGCGTTCGAACGCCAGGCACCTGGTCATGTCCTCGAAGACACGCCGGAAAGCGTTTCTGCTCGTTTTGTGCTCGAAAGAATTGCCAGGGGTGTGACGCGGAAGGAGATGGAACGTGATTTCCTGCAGTGGAATGAGCGTCACCTGGTCGATCACCCATCCGCACGGACTTGGTTGCATCAGTTCCTCGACAGGTTTTCCTGCTGA",
    "translation": "MLLDEVRNSAYARAIKGLVGPETTVLDLGAGLGLLGLMAAKAGARQVYLVDPSPVLLDVESVIEANGLGDRVSIILQPIEAASLPEKVDVLVSVMTGNFLLQEDLLPTLFFARDRFLKSTGTLVPAKGTMVAVPVTLARPERHPAFRLMRAIQGLDYDSVRRRFVNRVQFERFFESDALYLAAPEPLATLDFSIADKAAVDTTTTFRATANGRLDGLLGWFDMDLGDHALSTGPQAESVHWKQAFMPLETPVSIRQGEEVQFSLNRPERGEWTWSVSVGGSVQRMSTFFGYRPDIEAFERQAPGHVLEDTPESVSARFVLERIARGVTRKEMERDFLQWNERHLVDHPSARTWLHQFLDRFSC",
    "product": ""
   },
   {
    "start": 1380,
    "end": 3185,
    "strand": 1,
    "locus_tag": "ctg268_3",
    "type": "transport",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg268_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg268_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,380 - 3,185,\n (total: 1806 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1288:ABC transporter related protein (Score: 300.4; E-value: 4.5e-91)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg268_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg268_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%%0AMTEETRVMLTHTLALCPSSKSKFKAGIPRSTKAYNVVASTHGTRHLKFPDLVAIVTPAKSLMGAILGLSLTTSALALVQPWLAGRLAESLTGQPEGWINDVYRWLLAWFAVVAVYSLVLFLSNRLSASVAESMFARLRNRAFEHIQSLPLTWHQRRKTGDTLSLLTHDTGTISTFVSTTVIGLIPSVLVLFGALIAMFRISPKFTVLAAAFIPVYYLAIKIVGRRLRPVSRKLLDAWSEKTVFLQDHLQLLPVIKAFGQEAREISRHEACDRKLSDAARRQAFLGARIAPLTRFLAAGGLLFLMWVGVTDLERGALDTAQLVSLLFYVLLLNQPVAALAGSYGKIQSTLGAAERLQTLFGSEPEPDPSQGEELKIKSGTVRFENVRFTYPNAPPLFEGLCLEVPGGRVTLLTGPNGVGKSTLIHLAMRFLRPSVGKIAIDGQSLEDVSTHSLRDAVGLVAQHTVLLNTTIADNLRYGKWQATQNEMETACEAAGAMAFIRELPDGLETVIGEQGLHLSGGQRQRISLARTLLKDPPIVLIDEATSMIDEGGLDEFIERIPKLFAGKTVLLVSHQKQYATIAQHVIHLESGSQPSGEWPQAPG\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg268_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg268_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACTGAAGAAACTCGCGTAATGCTCACTCATACCCTTGCCCTGTGCCCCAGCTCAAAATCGAAATTCAAGGCAGGAATCCCCCGTTCGACCAAAGCCTATAATGTCGTCGCCTCCACCCACGGTACAAGGCATTTGAAGTTTCCGGACCTCGTCGCCATCGTGACGCCCGCCAAGTCGCTCATGGGAGCAATCCTCGGATTGTCCCTGACCACCAGCGCACTGGCTCTGGTCCAGCCCTGGCTCGCAGGACGGCTGGCCGAATCCTTGACGGGACAGCCCGAGGGATGGATCAATGACGTCTATCGATGGCTGCTGGCCTGGTTTGCAGTCGTCGCCGTGTACAGCCTGGTCCTGTTTCTTTCCAACCGGCTGTCCGCGTCTGTTGCCGAGTCGATGTTTGCAAGGCTGCGTAACCGGGCCTTCGAGCACATTCAGTCCCTGCCCCTGACCTGGCACCAACGCCGGAAGACGGGAGACACCCTGTCGCTGTTGACACACGACACGGGCACCATCAGCACGTTCGTGTCGACAACTGTCATCGGTCTGATCCCTTCAGTGCTCGTTCTGTTCGGCGCCCTGATCGCCATGTTTCGTATCAGCCCAAAGTTTACTGTGCTCGCTGCGGCGTTCATCCCCGTGTACTACCTCGCAATTAAGATTGTCGGTCGCAGGCTCCGTCCCGTGTCGCGCAAGCTGCTCGATGCCTGGTCCGAGAAAACGGTGTTTCTCCAGGATCACCTGCAGCTGTTGCCAGTCATCAAGGCATTTGGACAGGAGGCCCGGGAAATCTCGCGCCACGAAGCATGCGACCGCAAGCTGTCCGATGCCGCGCGGCGCCAGGCCTTTCTTGGCGCCCGAATTGCGCCCCTGACCCGATTCCTGGCCGCCGGCGGCTTGTTGTTTCTCATGTGGGTGGGTGTCACCGATCTCGAGCGGGGAGCGCTGGACACCGCGCAACTGGTCAGCCTTCTGTTCTACGTCCTGTTGTTGAACCAGCCTGTCGCTGCGCTTGCGGGGAGTTACGGAAAGATCCAGTCGACGCTTGGTGCCGCTGAACGTCTTCAGACACTGTTCGGATCAGAACCCGAGCCGGATCCCTCGCAGGGCGAGGAACTGAAAATAAAGTCCGGTACGGTGCGGTTCGAAAACGTCAGATTTACTTACCCGAATGCGCCACCGCTGTTCGAAGGGCTTTGTTTGGAAGTGCCCGGCGGAAGAGTCACATTGCTCACTGGGCCGAATGGGGTGGGGAAATCCACGCTGATCCACCTGGCCATGCGGTTTCTGCGACCCAGCGTGGGCAAAATTGCCATCGATGGACAGAGCCTCGAAGATGTCTCGACCCATTCGCTTCGAGATGCTGTCGGGCTGGTCGCCCAGCACACCGTGCTACTGAACACGACGATTGCGGACAACCTCCGTTATGGCAAATGGCAAGCCACTCAAAACGAAATGGAGACTGCCTGCGAAGCCGCGGGGGCGATGGCGTTCATCAGGGAGCTGCCTGACGGCCTGGAAACCGTCATCGGCGAGCAGGGCCTGCACTTGTCCGGTGGGCAAAGGCAGCGCATTTCGCTGGCGCGAACCCTGCTGAAGGACCCACCCATTGTGCTGATTGATGAAGCAACCTCGATGATCGACGAAGGGGGGCTCGACGAATTCATAGAGCGAATTCCCAAGCTGTTCGCCGGCAAGACGGTGTTGCTGGTCTCGCACCAGAAACAGTATGCGACGATTGCCCAGCACGTCATCCACCTGGAGTCAGGAAGTCAGCCCAGTGGGGAGTGGCCCCAGGCACCTGGA",
    "translation": "MTEETRVMLTHTLALCPSSKSKFKAGIPRSTKAYNVVASTHGTRHLKFPDLVAIVTPAKSLMGAILGLSLTTSALALVQPWLAGRLAESLTGQPEGWINDVYRWLLAWFAVVAVYSLVLFLSNRLSASVAESMFARLRNRAFEHIQSLPLTWHQRRKTGDTLSLLTHDTGTISTFVSTTVIGLIPSVLVLFGALIAMFRISPKFTVLAAAFIPVYYLAIKIVGRRLRPVSRKLLDAWSEKTVFLQDHLQLLPVIKAFGQEAREISRHEACDRKLSDAARRQAFLGARIAPLTRFLAAGGLLFLMWVGVTDLERGALDTAQLVSLLFYVLLLNQPVAALAGSYGKIQSTLGAAERLQTLFGSEPEPDPSQGEELKIKSGTVRFENVRFTYPNAPPLFEGLCLEVPGGRVTLLTGPNGVGKSTLIHLAMRFLRPSVGKIAIDGQSLEDVSTHSLRDAVGLVAQHTVLLNTTIADNLRYGKWQATQNEMETACEAAGAMAFIRELPDGLETVIGEQGLHLSGGQRQRISLARTLLKDPPIVLIDEATSMIDEGGLDEFIERIPKLFAGKTVLLVSHQKQYATIAQHVIHLESGSQPSGEWPQAPG",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 2,
    "end": 191,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 3187,
    "product": "RRE-containing",
    "category": "RiPP",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "RRE-containing",
  "products": [
   "RRE-containing"
  ],
  "product_categories": [
   "RiPP"
  ],
  "cssClass": "RiPP RRE-containing",
  "anchor": "r268c1"
 },
 "r272c1": {
  "start": 1,
  "end": 5186,
  "idx": 1,
  "orfs": [
   {
    "start": 3,
    "end": 1172,
    "strand": 1,
    "locus_tag": "ctg272_1",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg272_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg272_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3 - 1,172,\n (total: 1170 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg272_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg272_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg272_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg272_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "CGGTCCGTCCTCGCGCGGACCCGAACGGAAACCCACCCCACCCTGGTCGCCACCAACCGCGAGACGCTGATGTGGGGCGCCCTGTCGTTGGTCCCCCGCGAACTCGAGCGACTGCATCGGCTGGGAAATGCCGCCCTGCCGGCCGCACCCGCCGGCCAGGGCGCATCGCAGGCGGCTGCCGCGTTTTCACCGGGCGCGCCACGCCTGGCGAGACACCTTCTGCATCTGCTGGCCAAGCGCCTGAAACGCTCGATACGTTATCGGCTGTTCCAGGAGCACTGGCACCTGCGTTACGCCTTCGGTGAGGAACCGTCGACAGCTTTCCGGCAGTTCGAATCCCTGGTGCCATCACGGGATCGTTACTGGGCCGACCCGATGCCGCTGTTTCACGAAGGCCACTGGCACATTTTCTTCGAGGACCTGCCCGAAGCAACGGACAAGGGCCACATCTCGATGATCAGCTTTGACGACCACCACCGGCCGCTGCCGCCCCGGACGGTCCTCGAACGTCCCTACCACCTTTCCTACCCCTTCGTGTTCCACTGGGACCAGCGGCTCTGGATGATTCCCGAGACCGCCAGCAACCGGGCGGTCGAGCTCTACGAGTGCACGGAGTTTCCGGATCAATGGGAACTACGCCGGCGCATCCTGGAGGACCACTACATCGTCGACGCAACCCTGGAACGCCATGACGGGCGCTGGTACCTGTTCGGCAACCAGGTCGAGAACCCGGGCGCCTCGTCCTGGACCGAGCTGTTCCTGTTCGTGAACGAGGGAGACCTGCTCGACGGCGCCTGGACGCCCCATCCGGACAATCCGATCCGCTCAGACGTGCGCTGCGCCCGCCCGGCCGGTCCCCTCTACCGGACGGGCGAGTCACTGCTTCGCCCTTCCCAGGACTGCAGCCGCCGTTACGGAGGAGGAATGACACTTCACGAAATCAACGAACTGGGGCCGGAGCGGTATTCCGAGCAGATCGTCAATCGCATCCAGCCGGACTGGGAGCCTGATCTCAAGGGCGCCCACACCTATTCGCACCGTCCCGGGCTCACCGTGATCGACGTGATGAAGGAAGTGCCGCGGCCAGGCCTTTTCGGCCGCCTGCCCGAGCCCGTCCAGCGGCGAGTGGCGCACCTCCTGGCGGCGAGGCGCGCAGCCGACGATCATTGA",
    "translation": "MSVLARTRTETHPTLVATNRETLMWGALSLVPRELERLHRLGNAALPAAPAGQGASQAAAAFSPGAPRLARHLLHLLAKRLKRSIRYRLFQEHWHLRYAFGEEPSTAFRQFESLVPSRDRYWADPMPLFHEGHWHIFFEDLPEATDKGHISMISFDDHHRPLPPRTVLERPYHLSYPFVFHWDQRLWMIPETASNRAVELYECTEFPDQWELRRRILEDHYIVDATLERHDGRWYLFGNQVENPGASSWTELFLFVNEGDLLDGAWTPHPDNPIRSDVRCARPAGPLYRTGESLLRPSQDCSRRYGGGMTLHEINELGPERYSEQIVNRIQPDWEPDLKGAHTYSHRPGLTVIDVMKEVPRPGLFGRLPEPVQRRVAHLLAARRAADDH",
    "product": ""
   },
   {
    "start": 1239,
    "end": 3146,
    "strand": 1,
    "locus_tag": "ctg272_2",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg272_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg272_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,239 - 3,146,\n (total: 1908 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: AMP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 324.4; E-value: 1.7e-98)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg272_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg272_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg272_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg272_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGGGGGCGCCTTTGGGGTTACCAAAAGGGGAAGCAGTGACGCACGATCACGACATTTGTGGGGGCGATAGCGGCCATTTGGGCGCCGTTCGCGACGTCGTGGCGCGTTTCGAACACATCGTCGCGCACCACGCGGATGCCATTGCCGTCATCGAAGCAACACCGGATTCCACCCGTTCGGACCCGAGTTACAGCTATGCCAGGCTGAATGAGCGGCGCCTGGAAATTGCCGGCGCCCTCGTCGAACAACACGGACTGGGACCCGGCGACTGGGTCGGCCTGGTGCAATCCCGCCGCTTCGACACCCTGGCGGCCATGCTGGGGATTGCCACGATCGGCGCGAGCTATGTTCCACTGGATGCCGAGTGGCCGGAAGAGCGCCGTCGATACCTCCTGTCGGATGCCAAGGTGCGGGTGCTCCTGACGGCGGGACGCTCCGCGCCGTCCGGCGCCCTGCCCCTTTCGGAGTGCCGCGGATCGGCCCGTTCATTCGAGGGCGCAGCCCCGGACACGCCGCTCTACGTCATGTACACCTCCGGCTCGACCGGGGAACCCAAGGGCGTCGTGGTGCCGCACCGGGCCGTGGTCCGGCTCGTGGTCGGGACCGATTTCATGCCCCTGGACCCGCACACCCGGTTCCTGCACGCCGCGCCCCAGTCCTTCGACGCGGCGACCCTGGAAATCTGGGGACCGCTGCTTAACGGCGGAACCTGCGTGCTGCACCCGGAGGGCATTTTCGACCCCGCCGGCCTGGACCCCCTGGCTGACAAGCACGACATCAACGCCCTGTGGCTGACGGCCGCACTGTTCAACCAATGGGTCCAGTTACGCCCAAGGGGGCTCGAAGGCGCGGCCACCGTGCTGTTCGGCGGCGAAAGAGCCTCCGTTCCGCACGTACGCCAGGCCGCCGCGCTCTGGCCCCGGACCACGCTGGTCAACGGCTACGGTCCGACCGAGAACACGACCTTCACCTGCTGTCACACGGTCCGCCCGCAGGACCTCGACGAACAGGCCACGGAACTCCCCATCGGAAAGGCCATTACGGGCACGGCGGTGTGGATCGTGAACGGCGCCTTGGAAGACGTTCCCGCCGGCACGGTCGGCGAACTGGTGACCGGCGGCGAGGGCCTGGCGCTGGAATACCTGGGCCGCCCTGAATTGACATCCGAACGCTTCGTCACCGACGCCGGGGGCGAGCGCTGGTACCGGACGGGCGACCTCGCCAGGCAGGACGACGACGGCGTCATCCATTTTCACGGCCGGGCCGACCGCCAGTTGAAGCTGCATGGCCACCGCATCGAACCGGGCGAAATCGAGGCGGCGCTGCTGGCCGACCCGCGCTTGCACCATGCCCATGTCCTGGCCGTCGAAACGCCGGAAGGCGACCAGAAACTGGCGGCCTATCTCGTCGGCGAATTCGACCGGACCGAATTGCAGAACCGGCTGGCCGGCGCCCTGCCGCGATTCATGGTGCCGTCCGTTTACGTGTGTATCAGTGAGCTACCGACAACGGCCAATGGCAAGGTCGATGTCGGGGCATTGCCGTATCCGTTTCACGGCAAGGACCCGGCGCCGGCCAACGGCGGTGGCAATGACATGGCGAGGCTGGTGGCCGCGACCTGGCGGAACGTGGTTTCGGGTATCGACCTTAAAGGCAACGACGACAACTTTTTTGACGTGGGGGGCACGTCGATGGACATGATCCGGGTCAAGCAGGCCCTGGAAAAGCAGTTGGCTACGGAGATTCCGCTGGTCAGCCTGTTCCAGTACCCCACGGTTTCGAAGCTGGCGTCTCATCTCGACGCGCTGGCCCAGCCCGAGTCCGCCGCGGCGACCGCCACGGACCGGGCGGCCCGGCGCCGGCAGCAACTGGCTCGGCGCAAGGCCGGCCGGGTGCGGACATGA",
    "translation": "MKGAPLGLPKGEAVTHDHDICGGDSGHLGAVRDVVARFEHIVAHHADAIAVIEATPDSTRSDPSYSYARLNERRLEIAGALVEQHGLGPGDWVGLVQSRRFDTLAAMLGIATIGASYVPLDAEWPEERRRYLLSDAKVRVLLTAGRSAPSGALPLSECRGSARSFEGAAPDTPLYVMYTSGSTGEPKGVVVPHRAVVRLVVGTDFMPLDPHTRFLHAAPQSFDAATLEIWGPLLNGGTCVLHPEGIFDPAGLDPLADKHDINALWLTAALFNQWVQLRPRGLEGAATVLFGGERASVPHVRQAAALWPRTTLVNGYGPTENTTFTCCHTVRPQDLDEQATELPIGKAITGTAVWIVNGALEDVPAGTVGELVTGGEGLALEYLGRPELTSERFVTDAGGERWYRTGDLARQDDDGVIHFHGRADRQLKLHGHRIEPGEIEAALLADPRLHHAHVLAVETPEGDQKLAAYLVGEFDRTELQNRLAGALPRFMVPSVYVCISELPTTANGKVDVGALPYPFHGKDPAPANGGGNDMARLVAATWRNVVSGIDLKGNDDNFFDVGGTSMDMIRVKQALEKQLATEIPLVSLFQYPTVSKLASHLDALAQPESAAATATDRAARRRQQLARRKAGRVRT",
    "product": ""
   },
   {
    "start": 3200,
    "end": 5185,
    "strand": 1,
    "locus_tag": "ctg272_3",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg272_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg272_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,200 - 5,185,\n (total: 1986 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) T1PKS: hyb_KS<br>\n \n  biosynthetic (rule-based-clusters) T1PKS: PKS_AT<br>\n \n  biosynthetic-additional (smcogs) SMCOG1093:Beta-ketoacyl synthase (Score: 89.9; E-value: 2.4e-27)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg272_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg272_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg272_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg272_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAACCAGCAAGCATTGCCCGAAAACGCCGTCGCAATCGTCGGCATCGCCTGCCGTTATCCCGGGGCCCAGGATCTCGAGGCCTTCTGGCGGAACCTGCGCGAGGGGCGCGAGTCGATCACCTTCTTTTCCGCGGACGAGATCGACGCGAGTATTCCCGACGCGATCAAGTCCCAGCCCAATTACGTCCGGGCCAAGGGGCGGCTGGACGATGTCGACCGGTTCGATGCGAAGTTTTTCGACATCCCGCCCGTCGAAGCCAGCCTCATGGATCCACAGCAGCGCCTGCTGCTCGAACTGTCCTGGGCGGCCCTCGAGGACGCGGGCATCGTTCCCGGCGAGGGCGACAACCTGGTCGGCGTCTGGGTCGGCACCAACTGGAACCGGTACTACGCCCGGCACGTGCGCGGCAGCGCGGCCGAGCAGCGCTACGGTGAATTCAACGCCCAGTTGGCGAACGAGTTCGACTTCCCCGCCTCCAGAATCGCCTACAAGTTGAACCTGACCGGACCGGCGATCACGCTGGCCACCGCCTGCTCGACCTCGCTGGTCGCCATCGGCCAGGCCATGCAGTCGTTGCTCAACTTCGAGTGCAATGCCGCGCTGGCCGGCGGCGCCAGCATCTCGGTACCCCTGAACGCCGGTTACCTGCACCACGAGGGCGAGATGCTGTCCGCCGACGGGCATTGCCGGCCCTTCGACGCGCACTCCAGCGGCACGACCTTCAATGACGGCGCCGCGGTCATCGCGCTCAAGCGCCTCGAGGACGCCGTCGCCGACGGCGACGACATCTACGCGGTGATCCGGGGCGTCGGCATCAACAACGACGGCGCCGACAAGGTCAGTTACACCGCCCCCAGCGTCAATGGACAGATCGACGCCCTGAGCGCCGCCCTGGCCATCGCGGATGTGGATCCCGCCTCGGTCGGCCTGATCGAGACGCACGGTACGGCGACCCGTCTCGGAGACCCGATCGAAGTCGCGGCCATCCGCACGGTGTACGGCGCCGACCCTTCTGCGGGGCCGTGTGCGCTCGGCGCCCTGAAAAGCAACATCGGCCATGCCATCCACGCCGCGGGCATCGCCGGCGTGATCAAGGCCGCGCTGGCGGTCCGCGACGGCGTCATTCCGCCGACCATCAACTTCGAGACGCCCAATCCGGACCTGCAACTCGAGGGCAGCCGCTTCTACGTCAACTCCGAGGCCGTGGCCTGGCCTGACGCCACGCCCCGCCGCGCCGGCGTGAGCTCCTTCGGGGTCGGTGGAACCAATGCCCACGCCCTGGTCGAGCAACCCCCGGCCGCCACGAAGGCGCCACGCGCCCCGAGCGCCGATACGCCACCCTTGCTGCTGCTTTCGGCCCGGGACACGGAGACCTGCATGCGGCAGGCGATGAACCTCTCCGACCAGGCCCGAACACAGCCCGATATGCCGGACCTGGCCGACGTCGGCTACACGCTGGCCCGTTCCCGCAAGCGCTTCGACACGCGGGCGGCCCTGTTCGCCACCGGAATCGAGGAACTGGCGGCCTTCGACGAACAGTCCACGCGAATCGTCCGCGGCAAGGCGCGGCCGCTCGACACCCTGGTGTGGGCTTTCCCCGGACAGGGGGCGCAGCGGGCCGGCATGGGCGCGGCGCTCGAGGGGCGCTCGGACGCCTACCGCGAAGCCCTCTCTCGCGCCATCGAACAGCTCAATCCGCACCTGGATCTCGACCTTCGACAGCTGTTGCAGCGCGATGGCGAACTGCCGGGCGATGCGGCCGAGCGCATCTCCGAAACGAAGTATGCCCAGCCCGCCCTGTTTGCCGTCGGCTACGCCCTTGCGGCGCACTACCGGGCCGCCGGGCTGGAGCCGGACCTCCTGGTCGGCCACAGCATCGGCGAATTCGCCGCCGCCTGTATCGCGGGCGTGTTCAGCCTCGAGGACGCCGCCCTGCTCGTGTGCGAACGCGGACGGCTGATGCAGGCCCAGCCGCGCGGCGCC",
    "translation": "MNQQALPENAVAIVGIACRYPGAQDLEAFWRNLREGRESITFFSADEIDASIPDAIKSQPNYVRAKGRLDDVDRFDAKFFDIPPVEASLMDPQQRLLLELSWAALEDAGIVPGEGDNLVGVWVGTNWNRYYARHVRGSAAEQRYGEFNAQLANEFDFPASRIAYKLNLTGPAITLATACSTSLVAIGQAMQSLLNFECNAALAGGASISVPLNAGYLHHEGEMLSADGHCRPFDAHSSGTTFNDGAAVIALKRLEDAVADGDDIYAVIRGVGINNDGADKVSYTAPSVNGQIDALSAALAIADVDPASVGLIETHGTATRLGDPIEVAAIRTVYGADPSAGPCALGALKSNIGHAIHAAGIAGVIKAALAVRDGVIPPTINFETPNPDLQLEGSRFYVNSEAVAWPDATPRRAGVSSFGVGGTNAHALVEQPPAATKAPRAPSADTPPLLLLSARDTETCMRQAMNLSDQARTQPDMPDLADVGYTLARSRKRFDTRAALFATGIEELAAFDEQSTRIVRGKARPLDTLVWAFPGQGAQRAGMGAALEGRSDAYREALSRAIEQLNPHLDLDLRQLLQRDGELPGDAAERISETKYAQPALFAVGYALAAHYRAAGLEPDLLVGHSIGEFAAACIAGVFSLEDAALLVCERGRLMQAQPRGA",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 1,
    "end": 5185,
    "tool": "",
    "neighbouring_start": 0,
    "neighbouring_end": 5186,
    "product": "CC 1: neighbouring",
    "kind": "candidatecluster",
    "prefix": "",
    "height": 0
   },
   {
    "start": 1238,
    "end": 3146,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 5186,
    "product": "NRPS-like",
    "category": "NRPS",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   },
   {
    "start": 3199,
    "end": 5185,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 5186,
    "product": "T1PKS",
    "category": "PKS",
    "height": 4,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [
    {
     "start": 1260,
     "end": 1262,
     "strand": 1,
     "containedBy": [
      "ctg272_2"
     ]
    },
    {
     "start": 2067,
     "end": 2069,
     "strand": 1,
     "containedBy": [
      "ctg272_2"
     ]
    }
   ],
   "bindingSites": []
  },
  "type": "NRPS-like,T1PKS",
  "products": [
   "T1PKS",
   "NRPS-like"
  ],
  "product_categories": [
   "NRPS",
   "PKS"
  ],
  "cssClass": "hybrid",
  "anchor": "r272c1"
 },
 "r313c1": {
  "start": 1,
  "end": 4464,
  "idx": 1,
  "orfs": [
   {
    "start": 3,
    "end": 689,
    "strand": -1,
    "locus_tag": "ctg313_1",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg313_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg313_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3 - 689,\n (total: 687 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg313_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg313_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg313_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg313_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGTTCGCGGTGTACCACTCACCGGAGGGTGCGCCACGCGGCGAGGGAATCGTGGTCTGCCAGCCGCTGGGTCACGAATACTTCCGTTGCTACCGGACCCTCCAGGTGCTCTGCGCGGAACTCGCCCAGGGCGGTTACCACGTCCTGCGTTTCGATTTCTCGAACACCGGAAATTCCGCCGACGCGGATTCCCTGGAATTCAGCACCTGGGTGAACGACGTTGCACGCGCGGTTCGCGAACTCACCGACATCTCGGGCACTCGCAGCCTCTCCCTGGTCGGGGCCCGGCTGGGCGCCACGGCTTGCCTGAACCTGGGAAGCGCCGTCCAGCCGCTGAAGCAGATCGTCCTGTGGGATCCGGTCCTCGATGGGGCGTCCTGCCTGGCGTCGCTCGACCGTCTCCACGAGAAGGTCTGTTCGGCGCATCCCGGCGGTCCCTCGGGCGCCCCGGAGCTGGTGAGCGCCTCCGGCTGCGAGCGTGTCGGCCTCGATCTCCCGCCCGGCTTGCGTGACTCGATCGGCGTGATCACGCCGCCCTCCCTGGCGGTGCCCGCGGCCGAACGGCTGACGGTCGTCACGACCCTCGGGGAAACGGAGTCGCTGTCCGGTGCGTTCGCCGGGACCGTGGCCCCCAACGTGGTACAGGTCGATTCGGACTGTGGCTGGAACGACGCCGTGCGCTTCACC",
    "translation": "MFAVYHSPEGAPRGEGIVVCQPLGHEYFRCYRTLQVLCAELAQGGYHVLRFDFSNTGNSADADSLEFSTWVNDVARAVRELTDISGTRSLSLVGARLGATACLNLGSAVQPLKQIVLWDPVLDGASCLASLDRLHEKVCSAHPGGPSGAPELVSASGCERVGLDLPPGLRDSIGVITPPSLAVPAAERLTVVTTLGETESLSGAFAGTVAPNVVQVDSDCGWNDAVRFT",
    "product": ""
   },
   {
    "start": 751,
    "end": 4464,
    "strand": -1,
    "locus_tag": "ctg313_2",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg313_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg313_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 751 - 4,464,\n (total: 3714 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: A-OX<br>\n \n  other (smcogs) SMCOG1251:luciferase family protein (Score: 417.7; E-value: 6.2e-127)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg313_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg313_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg313_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg313_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "CTGAGCGATGCCGAGCTCGCCTGGCTCTCGGCCGCCTCGAAAGCGGAGCCGGGATGGATCGCCCTGCGCGGGTCGGAAACGCCACTCGACGTCGAGTGGCTGTTCCAGGACGAAGGCCAGCCCGTCCAGTCCCGGACATCCAGGGTCGAGATTCCGGAGATCGTGAACCTGGAAGCGGGCGTCACGGTCGTGCTGCTGGCGCTGTTGCGCCTGAGCGGCGACCAACGTGGACTGGTCGCGCTGCTCGATGCCACGCTCGAGGACTTTCCGCTGGTCGAGTCATTCCGCCCCGTGCTGGCCTCGCTCCGCGAGGACGAATCGGTCGCCTCGTTCACGGAGCGCATGGGCGCCCGGATCGCTGCTGCCGGAAGGAAGGGTCCCCTCCTGCGGGACCAGGGCCTGCGGTCCACCCGTGATCTCGGTTCGACGCCCTGCGTGGCGGTCAGTGCGGGCGCGGCCCTCGCGGCCGGCCGGGGGTTCGACCTGTGGGTTCACGTGGACGTGGGCGAGGCGGGCGCAAGCATCGAAACGCGATTCGAACGCGCGACCTCCGCGCGCAAGGTCGCCCAGTTCGAGCAGGCGCTCAGAGGCGTGGCCCGGGACGTCTCGACCCGTTCGACCCGGCCGGCCGCTGCCATCGACATCGTCGCCGAAACGGACCGGGCCCAGGTGCTGGACCAATGGAATCCGCCGCCGACGGCGTCGAAGGAAGAGTGCATCCACCACGCGTTCCTGCGCGTGGCATCCGAACAGGGCGCCGCGCCGGCCGTGCTGTGCGACGGCAGGGTGCTTTCCTTTGCCGAACTGGCGCAACAGGCGCAGTCGGTGGCCCGGCACCTGCAGGGCCTCGAGGTCGGCCCCGACGACCGGGTCGGCATCTGCCTGGAGCGCAACGAGGCACTGCTCATCGCCGTCCTGGGCGTGTTGGCGTCCGGGGCCGCCTACGTTCCGCTGGACCCCGAATACCCGGCCGCCCGGCTCCGGCACATCGTGGCGGACGCCGAGCCGGCGTTGACGCTGGTGAGCGAGGACACCCGGCACCGGCTGGAAGGCACGACCGCGCCCCTGCTGTCATGGGACGAGGCCCTCGCGGCCGACTCGGGCGCCGACCTTCGAGACGAGGCCAGCCCTCGGAACCTGGCCTACGTCATCTACACCTCCGGGTCCACGGGGGCACCGAAGGGCGTGATGGTCGAGCACCGCAACGCCGCGAATTTCTTCACCGCGATGGACGAGCGGGTGACCCTGGGCGCCGGGCCGCGATGGTTGTCCGTCACCAGTCTTTCCTTCGACATCTCGGTGCTGGAACTGTTGTGGACCCTGACGCGCGGCGTGGGCATCGTCCTCTACACGGGCGCAGACCGGACGGGCGCCGTGTCCGCCATCGCCCCGAAGCCGCGCGCCAACGACACGCCCATCGACTTCAGCCTGTTCTACTTCGCCAGCGACGAGGGGGAACGTCATGACGGCAGGGGTGCAAACGGCAGGGGCCCGGCCGACAAGTACCGGCTCCTCGTGGAAGGTGCGAAGTTCGCCGACGCGAACGGCTTCGTGGCCGTCTGGACCCCGGAACGACATTTCCACGCCTTCGGCGGCCTCTATCCGAACCCCTCGGTGGTGAGCGCCGCACTGGCGACCATCACGGAGCATGTCCAGCTTCGTGCGGGGAGCTGCGTGCTGCCCCTGCATGACCCGATCCGGATCGCCGAGGAGTGGGCGCTGGTCGACAACCTGTCCAACGGCCGGGTCGGCATCTCCTTCGCTTCCGGCTGGCAGCCCAACGATTTCGTGCTCGCGCCGGACCGTTACGAAAACCGGCACGAGGTCATGGCCGAAGGTATCGAGACCGTCCGCGCCCTGTGGCGCGGTGACAGCGTGCGGCGGACCAATCCGCTCGGCAAGGAGGTGGAACTGGCCACCTTGCCGCGACCGGTGCAGGAAGAGTTGCCGTTCTGGGTGACCGCCGCGGGCAACCCGGCCACTTTCCAGGCGGCAGGCCGGCAGGGTGCGAACCTGCTGACGCACCTGCTGGGTCAGGACCAGGAGGAACTGGCCGGGAAGATCGAGGCCTACCGCTCGGCCTGGCGGGAGGCGGGCCATCCGGGCGAAGGAATCGTGACACTCATGCTGCATACCTTCGTCGGAGACGACGAGGAGGCGGTCAAGGCCGCGGTGCACGAGCCGCTGAAGGCGTACCTCCGCAGCTCCGTCGGCCTCATCCGCAAGTTCGCCGACACCTTTCCCGCCTTCAGGAATCGCGGCGGTGATGGCGGGACGATCGACTTCGACGCGCTCGCCCCGGAGGACATGGAGGCGCTGCTCGAATTCGCCTTCGAGCGGTACTACCGGGACAGCGGCCTGTTCGGCGCCCCGGAGCGCTGCGCCCGGATGGTCGATTCGCTGAAGGGCATCGGCGTGAACGAGATCGCCTGCCTGGTCGATTTCGGCGTGCCCTCCGAACAGGTGCTCGAACACCTGCCGGACATCGCGGAGGTCATGCGACGGTCGAAACCCCGGTCCGAGCTTCCGGCGGGATCGGTGGCGGCCTTGATCCAGGCCCACGGCGCCACGCACCTGCAATGCACCCCCTCGCAGGCGCAGATGCTGCTGGCCGACCCGGACAACCACCCCGCAGTGGCCGGCCTGCGGGGCTGGCTGGTGGGCGGCGAGGCGCTGCCGGAAGAACTCGCCAGGCGCCTCCGAACCGTGGCGCGGGGGACGGTGATCAACATGTACGGCCCCACGGAAACCACGATCTGGTCCACGACGTGGGCCCTGCCAGAGGATCCCGGCCCGGTGCTGATCGGCACGCCCATCGCCAACACCCGCTGCTACGTGCTCGACGATGCCCTCCGGCTTCGGCCGCCGGGCGCGCCCGGCGAACTGTTCATCGGCGGCCAGGGCGTGACCCGTGGGTATCTCGGCAAGGAGGCATTGACGGCGTCCCGCTTCCTGGAGGACCCCTTCGGTGATCCGGGCGACCGCATGTACCGGACCGGCGACCGCGTGCGCTGGGTCGACGGGGAGCTGGAGTTCCTCGGCCGTATGGACGACCAGGTCAAGGTGCGCGGCTACCGGATCGAACTGGGCGACATCGAGTCGGCACTCGCCGCCTTCGACGGCCCCCAGCAGGTGGTGGCCGCCATCAAGACGGACGCCGCCGGCGATCCGGCCATCGTTGCTTATGCCCTGATGCCCCCGGGGACCGGCCTCGACGAAGTGGCCCTGCGGCGCCATCTCAACCGCACACTGCCGCCGTACATGGTCCCCCAGGTCTTCATCGAGATCGACGAGGTGCCGCTGACCCCGAACGGGAAGGTGGACCGGCGCGCCTTGCCGGACCTCGATGCCGGCCGGCGCGGCCGGCGCGGCGCCTTCGTGCCCCCGTCAACGGAGACCGAGAAGGCCCTTGCGGCCATCTGGGGCGAGGTGCTCTCGGTGGCGCAGGTGGGCTCGCAGGACACCTTCTTCGAACTGGGCGGGGATTCCCTGGCGGCCGTCCGGGTCGCGGTTCGCATCCGCGAGGTGATCGGCGAGCGGCTGCCCCTGGAAACCCTCCTTCGCGCGACGCTGGCCCAATCGGCGAGGTCCCTGGACGGCGCGCGGGCGGGCGAGCGCCCTGGTGCGGGGCCCGCGACCCGGGAACCCGCGGACGCCACTGGGCGCAAGTCCGGACTGTTGCACCGCCTGACCCGGCGCAAGCCCAGGGCCTGA",
    "translation": "MSDAELAWLSAASKAEPGWIALRGSETPLDVEWLFQDEGQPVQSRTSRVEIPEIVNLEAGVTVVLLALLRLSGDQRGLVALLDATLEDFPLVESFRPVLASLREDESVASFTERMGARIAAAGRKGPLLRDQGLRSTRDLGSTPCVAVSAGAALAAGRGFDLWVHVDVGEAGASIETRFERATSARKVAQFEQALRGVARDVSTRSTRPAAAIDIVAETDRAQVLDQWNPPPTASKEECIHHAFLRVASEQGAAPAVLCDGRVLSFAELAQQAQSVARHLQGLEVGPDDRVGICLERNEALLIAVLGVLASGAAYVPLDPEYPAARLRHIVADAEPALTLVSEDTRHRLEGTTAPLLSWDEALAADSGADLRDEASPRNLAYVIYTSGSTGAPKGVMVEHRNAANFFTAMDERVTLGAGPRWLSVTSLSFDISVLELLWTLTRGVGIVLYTGADRTGAVSAIAPKPRANDTPIDFSLFYFASDEGERHDGRGANGRGPADKYRLLVEGAKFADANGFVAVWTPERHFHAFGGLYPNPSVVSAALATITEHVQLRAGSCVLPLHDPIRIAEEWALVDNLSNGRVGISFASGWQPNDFVLAPDRYENRHEVMAEGIETVRALWRGDSVRRTNPLGKEVELATLPRPVQEELPFWVTAAGNPATFQAAGRQGANLLTHLLGQDQEELAGKIEAYRSAWREAGHPGEGIVTLMLHTFVGDDEEAVKAAVHEPLKAYLRSSVGLIRKFADTFPAFRNRGGDGGTIDFDALAPEDMEALLEFAFERYYRDSGLFGAPERCARMVDSLKGIGVNEIACLVDFGVPSEQVLEHLPDIAEVMRRSKPRSELPAGSVAALIQAHGATHLQCTPSQAQMLLADPDNHPAVAGLRGWLVGGEALPEELARRLRTVARGTVINMYGPTETTIWSTTWALPEDPGPVLIGTPIANTRCYVLDDALRLRPPGAPGELFIGGQGVTRGYLGKEALTASRFLEDPFGDPGDRMYRTGDRVRWVDGELEFLGRMDDQVKVRGYRIELGDIESALAAFDGPQQVVAAIKTDAAGDPAIVAYALMPPGTGLDEVALRRHLNRTLPPYMVPQVFIEIDEVPLTPNGKVDRRALPDLDAGRRGRRGAFVPPSTETEKALAAIWGEVLSVAQVGSQDTFFELGGDSLAAVRVAVRIREVIGERLPLETLLRATLAQSARSLDGARAGERPGAGPATREPADATGRKSGLLHRLTRRKPRA",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 750,
    "end": 4464,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 4464,
    "product": "NRPS-like",
    "category": "NRPS",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "NRPS-like",
  "products": [
   "NRPS-like"
  ],
  "product_categories": [
   "NRPS"
  ],
  "cssClass": "NRPS NRPS-like",
  "anchor": "r313c1"
 },
 "r314c1": {
  "start": 1,
  "end": 23478,
  "idx": 1,
  "orfs": [
   {
    "start": 1,
    "end": 75,
    "strand": -1,
    "locus_tag": "ctg314_1",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1 - 75,\n (total: 75 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCCAATGGTCACTCACCGAGCGGCTGCAACCTTCCCTGCTCGATCGCCTCACCGACGAGGAGCCGGACAAG",
    "translation": "MSQWSLTERLQPSLLDRLTDEEPDK",
    "product": ""
   },
   {
    "start": 83,
    "end": 868,
    "strand": -1,
    "locus_tag": "ctg314_2",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 83 - 868,\n (total: 786 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGACGCTGAACTGCTGCTCAAGGCCGGCGATCCGGCCGCAGCCCTCGAGTCACTCAAGAACAAGGTGCGGGCCGATCCATCGAACGCGTCCCTGCGCACCTTCCTGTTCCAGCTGATGGCGATCAACGGAGACTGGGACAAGGCGACCAAGCAGTTGGACGTGGTCAAGGACCTCGACGACGGCACCATCGCCATGGCCCGTGTCTACGAGGATGTCATCAATTGCGAGAAGCACCGCGACGCGGTGTTCGCCGGCAAGGTGCGCCCCATCGTGTTCGGAGAACCCGAGCCCTGGGTGGCCAGGCTGGTCGAGGCGCAGCAGGCGCTGGCCCAGGGCGATGTCGATCGGCATCTTTCCCTCCAGCAGCAGGCCTTCGAGGAGGCTCCTGCCGTTTCGGGCCGCATCAACGACGAAGGCTTCGAGTGGCTGGCCGACGCGGACACCCGCTTTGGCCCGGTGCTCGAAATGATGTTCAACCAGCATTATTACTGGGTTCCGCTCAACCGGGTGCGCAGCCTGAAGACCGAAGCGCCTTCCGACCTGCGCGACCTGGTCTGGCTCCCGGCGGAGGTGACCTGGGTCAACGGCGGCCAGGTGATGGTGATGATGCCGGCGCGCTATCCGGGACTGGAAGGCCTCGACGGCAACCACCTCCTGGGCCGCAAGACCGAGTGGCGCGAGTCGCACCCCGGGGTGTTCGAAGGCGTCGGCCAGAAGATGCTGGGCACCGACCAGGGCGAGTACCCGCTGCTGCAGGTCCGCACCATCGAATTCGACGCCTGA",
    "translation": "MDAELLLKAGDPAAALESLKNKVRADPSNASLRTFLFQLMAINGDWDKATKQLDVVKDLDDGTIAMARVYEDVINCEKHRDAVFAGKVRPIVFGEPEPWVARLVEAQQALAQGDVDRHLSLQQQAFEEAPAVSGRINDEGFEWLADADTRFGPVLEMMFNQHYYWVPLNRVRSLKTEAPSDLRDLVWLPAEVTWVNGGQVMVMMPARYPGLEGLDGNHLLGRKTEWRESHPGVFEGVGQKMLGTDQGEYPLLQVRTIEFDA",
    "product": ""
   },
   {
    "start": 980,
    "end": 1345,
    "strand": -1,
    "locus_tag": "ctg314_3",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 980 - 1,345,\n (total: 366 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_3\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_3\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCACACCGCGACCGGTGGTGCGGCGTCCTCCTCGATGGTGGGCGACTTCAGCTGCTCGGTCCCGTGCGGCAAGGGTGACCCCAACTTCGCCCAGTACTGCGCGCTCGGCAAGCACATTCCCACCGTCAAGGTGCACCTGTGCAAATCGTCCGGCGACACGCTGGTGGAGTGGTACACCTACACCTTCAATACCGTCATCATCTCGAGCTACAGCGTTTCGGGCGGCGGTGGAGCACCGGGCTACGCGAACATCAGCTTCAACTTCGCCGATTTCCAGCTCCAGCAGTTCGACCAGGACGACAAGGGTTCGGTCAAGGCCGGCCCGGACGTGAAGTACAGCGCTCGCTTGAAGAAGCCGCTCTGA",
    "translation": "MHTATGGAASSSMVGDFSCSVPCGKGDPNFAQYCALGKHIPTVKVHLCKSSGDTLVEWYTYTFNTVIISSYSVSGGGGAPGYANISFNFADFQLQQFDQDDKGSVKAGPDVKYSARLKKPL",
    "product": ""
   },
   {
    "start": 1656,
    "end": 3158,
    "strand": -1,
    "locus_tag": "ctg314_4",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,656 - 3,158,\n (total: 1503 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_4\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_4\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCTGAAGAGAAACTCGCCACAAAGGGCGCGGCGGCAGCCGTCACCGAGGAAAGCAGTGATTTCGCGGCCCTGCTCCAGAAGGAGTTCCGCCCGAAGTCCGACCGTATCTCGGACGAAATCAATTCCGCGGTCGGCACGCTGGCCGAGTACGTGCTCAAGGACACCAACCTGGTGTCCGAGGACGCGGTGACCTCGATCCAGGCGATGATCGCCCAGATTGACGCCAAGCTGACCGAGCAGGTCAACCAGATCATCCACCATGAGGAGTTCCAGAAACTCGAGAGCGCCTGGCGCGGCCTGTCCTACATGGTGAACAACACCGAAACCGACGAGTCCCTGAAGATCAAGGTCATGAACATCTCCAAGGAGGAGCTGGGCAAGACCCTGAAGAAGTTCAAGGGAACCGCCTGGGACCAGAGCCCCTTGTTCAAGCAGATGTACGAAGAGGAATACGGGCAGTTCGGTGGTGAGCCCTTCGGGCAGATCGTGGGTGACTACTACTTCGACCACGGACCCGCGGACGTTGAAATTCTTCGTGGCATGGCGCAGATCAGCGCGGCCATGCACGCGCCGTTCATTTCCGCGGTGTCGCCGACGGCGATGCAGTTCGACTCCTGGGCCGAGCTGAGCAACCCGCGCGACCTCACCAAGATCTTCCAGACGCCGGAATACGCGGCCTGGCGGTCGCTGCGTGAATCCGAGGACTCGCGTTACCTCGGCCTGACCATGCCGCGCTTCCTCGCTCGCCTGCCTTATGGCGCGAACACCGACCCGGTCGAGGCCTTCGACTTCGAGGAGGAAACCGAGGGCGCGGATTCCAGCAAGTACTCCTGGGCCAACTCGGCCTATGCCATGGCGACCAACATCAACCGCTCCTTCAAGGTGTTCGGCTGGTGTTCGCGGATCCGCGGCATCGAGTCCGGCGGCGCGGTGGAGGAGCTTCCGACCCACACCTTCCCGACGGACGACGGCGGCGTGGCGATGAAGTGCCCGACCGAGATCGCCATCAGCGACCGGCGCGAGGCGGAACTCGCGAAGAACGGCTTCATGCCGCTCATTCATCGCAAGAACTCCGATTTCGCGGCCTTCATCGGCGCCCAGTCCTTGCAGAAGCCGCAGGAGTACGAGGATCCGGACGCCACGGCCAACGCCAACCTGGCTGCGCGCCTGCCGTACCTGTTCGCCACCTGCCGCTTCGCGCACTATCTCAAGTGCATCGTTCGCGACAAGATCGGTTCCTTCAAGGAGCGCGACGACATGCAGCGCTGGCTGAACAACTGGATCCAGCAGTACGTGGACGGCGACCCCGCGAACTCCACCGAGTCCACCAAGGCGCGCAAGCCCCTGGCGGCGGCGGAGGTCGTGGTGGAAGCGGACGAGAGCAACCCGGGCTACTACCGGTCGCGTTTCTACCTGCGGCCGCACTACCAGCTCGAAGGCCTGACCGTGTCCCTGCGACTGGTGTCCAAGCTGCCTTCCGTCAAGGAAGGGGGCGGCTGA",
    "translation": "MAEEKLATKGAAAAVTEESSDFAALLQKEFRPKSDRISDEINSAVGTLAEYVLKDTNLVSEDAVTSIQAMIAQIDAKLTEQVNQIIHHEEFQKLESAWRGLSYMVNNTETDESLKIKVMNISKEELGKTLKKFKGTAWDQSPLFKQMYEEEYGQFGGEPFGQIVGDYYFDHGPADVEILRGMAQISAAMHAPFISAVSPTAMQFDSWAELSNPRDLTKIFQTPEYAAWRSLRESEDSRYLGLTMPRFLARLPYGANTDPVEAFDFEEETEGADSSKYSWANSAYAMATNINRSFKVFGWCSRIRGIESGGAVEELPTHTFPTDDGGVAMKCPTEIAISDRREAELAKNGFMPLIHRKNSDFAAFIGAQSLQKPQEYEDPDATANANLAARLPYLFATCRFAHYLKCIVRDKIGSFKERDDMQRWLNNWIQQYVDGDPANSTESTKARKPLAAAEVVVEADESNPGYYRSRFYLRPHYQLEGLTVSLRLVSKLPSVKEGGG",
    "product": ""
   },
   {
    "start": 3162,
    "end": 3680,
    "strand": -1,
    "locus_tag": "ctg314_5",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,162 - 3,680,\n (total: 519 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_5\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_5\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGTAAAGAAAGCAGTCAGAAATTCATTCAGCGCAATCGTGCGCCCAGGGTACAGATCGAATACGACGTCGAACTGTACGGTTCGGAGAAGAAGGTCCACCTGCCCTTCGTGGCCGGGGTGCTCGCCGACCTTTCCGGCAAGTCCGAAAACACGCCGCCGCCCGTGGCGGACCGCAAGTTCCAGGAATTCGACATCGACAACTTCGATGACCGCATGAAGGCCATCAAGCCGCGTGCCGCTTTCCGGGTGGACAACACCCTGACGGGCGAGGGCCAGCTCAACGTGGACCTGACCTTCGAAAGCATGGACGACTTCTCACCCGAAGCCGTGGCGCGCAAGGTCGATTCACTCAACAAGCTGCTGGAAGCACGGACCCAGCTCAGCAACCTGGTGACCTACATGGACGGCAAGAGCGGGGCGGAAGAGCTCATCGCCAAGGCCATGAACGACCCGGCGCTCATGCAGTCCCTGGTTTCTGCGCCCAACCCCGACGACGCTTCCGAGAAAGAGGACTGA",
    "translation": "MGKESSQKFIQRNRAPRVQIEYDVELYGSEKKVHLPFVAGVLADLSGKSENTPPPVADRKFQEFDIDNFDDRMKAIKPRAAFRVDNTLTGEGQLNVDLTFESMDDFSPEAVARKVDSLNKLLEARTQLSNLVTYMDGKSGAEELIAKAMNDPALMQSLVSAPNPDDASEKED",
    "product": ""
   },
   {
    "start": 3795,
    "end": 5138,
    "strand": -1,
    "locus_tag": "ctg314_6",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 3,795 - 5,138,\n (total: 1344 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_6\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_6\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAGTTCAGTGGTCTCCTCTCGGTCCTGGCCTGTACGGAAATCGCCCGGCATTCGCCGGTCCCGCCCACGTCACGGGGCTGCCTGGAAAAAGTCCAGTTCGCAGTCCGTCCCCCGATCGTTTTCCCGGGACGGCCAGCGAAGGCGGGAATGTCAGTTGCGGGTCGACCCGTTTCCCCTATACTCAAGTGGTCCTGAGTTCTTGTTCAGTCATCATAGTCCAAGAATAGCAAAAGCAATCAGTGAACTTCCGGCACGGGTCCATCGCCTGGCGAGAACCCCGACGGGGTCCCTACGACTTCACGCAATTCGGCATTGGGGAGAATGCATGCGTATTTCCGCTGACGAGCTGAGCCAGCCTATTTCCGAGGATCAACCCTGCGGGGAAGATCTCGAGTACGACGCCGCCTTCCAGGCGATGGAAACCGCCCTGCAATCGCAGGACGCCCAGGAGATGGGCGATTCAACGAAAGAAGCCCAGGGTCCCGACTGGCAGGCCGTGGGCGCCAACGCCCTCGACCTCCTGGGCCGCACGCGCGACCTGCGCGTGTTCGTCAATCTCGCCATGGCGGGCCTTCACACCGACGGACTCCCGGCGTTTCACCAGGCCCTGGTGGCCCTGAACAACTGCATGGACCAGTTATGGGAAACGGTGCATCCCCAGCTCGATCCGGATGATGACAACGACCCCATGATGCGCATGAACGTGCTGCAGAACCTCGACGACTACGCCAACGTCCGCATGGGCCTGAAGCGTTGTCCGCTGGTGGAGCTCAAGGGCTTCGGCGCATTCAGCCTGCATGACATCGAACTGGCCACCGGCGCGCGCGAGGCCGGCGAAGGCGAGGAGGTGACGGACCTGGCGATCATTCAGGGCGCCTTCGTCGACTCCGACCGTGACCAGCTCACCCTGGTGTCGGAAGCGGCGGCGGGTGCGCTGGCCGAGTTCGCGCGGATGTCGGAACTGTGGTCCGAGCGCACCGGCGGGTACGAGCAGCCCGGCATCGACAACGTGATCGCCTCCCTGCGTGAAATCAGCCGAACCCTGGTGGAGTACGCGCCCGCGGGCACCGTGGCGGGTACGGAGGAGGAGGCGGCAGCCGAAGGCGAAAGCGGTTCGGCGGCGCCCGCGGCGCCCGGTACGATCAACAGTCCTGCCGATGTCATCCTGGCCCTGGACCGGATTTGCGATTACTACGCAAAGACCGAACCTTCCAGCCCCATTCCCTTCATCCTCAGGCGCGCCCAGCGGCTGGTGTCGAAATCGTTCTACGAAATCCTCCAGGACATTGCCCCTGACGGGATCACACAGTTCGACACGATCACCGGGCACATGCAGGAGTGA",
    "translation": "MSSVVSSRSWPVRKSPGIRRSRPRHGAAWKKSSSQSVPRSFSRDGQRRRECQLRVDPFPLYSSGPEFLFSHHSPRIAKAISELPARVHRLARTPTGSLRLHAIRHWGECMRISADELSQPISEDQPCGEDLEYDAAFQAMETALQSQDAQEMGDSTKEAQGPDWQAVGANALDLLGRTRDLRVFVNLAMAGLHTDGLPAFHQALVALNNCMDQLWETVHPQLDPDDDNDPMMRMNVLQNLDDYANVRMGLKRCPLVELKGFGAFSLHDIELATGAREAGEGEEVTDLAIIQGAFVDSDRDQLTLVSEAAAGALAEFARMSELWSERTGGYEQPGIDNVIASLREISRTLVEYAPAGTVAGTEEEAAAEGESGSAAPAAPGTINSPADVILALDRICDYYAKTEPSSPIPFILRRAQRLVSKSFYEILQDIAPDGITQFDTITGHMQE",
    "product": ""
   },
   {
    "start": 5140,
    "end": 6798,
    "strand": 1,
    "locus_tag": "ctg314_7",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,140 - 6,798,\n (total: 1659 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_7\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_7\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGCCGATCAGCCTGAGAATCAGCAGTTACCAGCGACTCACGCCGGGCCAGCAGGAACGGTTCTGGTCCGATGCCGGCGCCTTCACGATCGGCCGAGGCAAGGACAACGACTGGGTGATGCCCGACCCGCAGCGTTTCCTGTCGGGCGTTCATTGCCGCGTGGAGCGCAAGGGTGACGACTACTACCTCACCGACCTGAGCACCAATGGAACCTTCGTCAACGGTTCGGATACCCGGATGGAGCGCAACGGCTCCGTGCAGATCAACGACCACGACAAGTTCCGGATCGGCGACTACGAGTTCGTTGTGGAACTCGGGGACTCCACGGTCGAAGTCCGCGAGGACGTGGAGGAGCCGTTGACGGAAGGCTTCACCGCTTTCGACCAGCCCGTGGCGCCCGCCGCCGACCCCTTTGCCGACGACGACGGGGAAGACCCGTTCGCCGAACCGAAACCCGCGCCGCCCGCGCCGGCTTTCGACGATCCCGACGAACGCGAGATCAACACCCCCCTGTCTCAGCTCGATCACAACGCGCTGGACCGCGGCGTCAATATCGACAGCATCCTGAATCTCGATGACACCGGCGGGAAGCGCTCGCCGCCCCCGGCCGAGTCGGGCTTCGAAGTGATCAACGAACCCATCCGGGAAGCACGGCCGGTATCACAGCCATCGGCCGGTAGCGGTCTCGAGATCCCCGACGACTGGGACGAAGCAACGGGAATGATGCGATCCCCGCTGGCGGAGAAGAAGGAAGAGGATACCGACGAGGATTTCGGCTTTTCCGACGACTGGGGCGATACCGGCACCTTCAGCGCCGACATCGACGAACCGTTCGGTTCCGACGACGCCCTGGAAAGCGACCCGGCGCCGGAGCCCCCTGCCCCGCCGCCCTCCGCGCCCGAGCCCGAGCCCGAACCCACGCCGGCGCCCGCCCCGCCGCCACCCGCGCCGGAACCGCCACGGGCCGCGGTGGAACCCGAACCGACACCACCCGCGAAGCCGGCGCCCGCCGCGAAGCCCGCACGCGAGCCCACCCCTGCCCCGAAACGCCCGACGCCGGGCGCGGACTCGCCGTTGGCGGCCTTCGCCCGGGGTGCGCGCGTCGATGCCGCCGGCCTGAACGTGGATGACCCGGACGCCTTTTTCGAATTCCTCGGACGGGTGAACCGGGCCTTTACCGAGGGCATCATGCGTGCATTGAGCGGACGGGCCTCGGTGAAGAACGAGTTCCGCCTGGACCAGACCATGATCCGGCCCTCGGAGAACAACCCCCTGAAGTTCTCGCCCATGCCGGATGACGCGCTGGTGCGCATGCTGCGCCAGAACGACGACCACGCCTACCTGCAGGGCGAGAGCGCGGTCAAGGAAGCCTTCGAGGACATCAACGCCCACCAGATCGCCGTGATGGCCGGCATGGAAGCGGCATTGCAGGGACTGCTGCGGCGGTTCAGCCCGGAAACCCTGGAGAAGAAACTCGTGTCCAGCTCCGTGCTGGACAACATCCTGCCGGGCGCAAAAAAAGCCAGATACTGGGATATATTTAATTCCATGTACGCCGAGATCGCGAACGAGGCGGAAGACGATTTCCAGCAACTCTTCGGTTCGGAATTCATCCGCGCTTACGAGGCGCAAATGAGCCGACTCAAGAACAAGACCTAG",
    "translation": "MPISLRISSYQRLTPGQQERFWSDAGAFTIGRGKDNDWVMPDPQRFLSGVHCRVERKGDDYYLTDLSTNGTFVNGSDTRMERNGSVQINDHDKFRIGDYEFVVELGDSTVEVREDVEEPLTEGFTAFDQPVAPAADPFADDDGEDPFAEPKPAPPAPAFDDPDEREINTPLSQLDHNALDRGVNIDSILNLDDTGGKRSPPPAESGFEVINEPIREARPVSQPSAGSGLEIPDDWDEATGMMRSPLAEKKEEDTDEDFGFSDDWGDTGTFSADIDEPFGSDDALESDPAPEPPAPPPSAPEPEPEPTPAPAPPPPAPEPPRAAVEPEPTPPAKPAPAAKPAREPTPAPKRPTPGADSPLAAFARGARVDAAGLNVDDPDAFFEFLGRVNRAFTEGIMRALSGRASVKNEFRLDQTMIRPSENNPLKFSPMPDDALVRMLRQNDDHAYLQGESAVKEAFEDINAHQIAVMAGMEAALQGLLRRFSPETLEKKLVSSSVLDNILPGAKKARYWDIFNSMYAEIANEAEDDFQQLFGSEFIRAYEAQMSRLKNKT",
    "product": ""
   },
   {
    "start": 6812,
    "end": 7306,
    "strand": 1,
    "locus_tag": "ctg314_8",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,812 - 7,306,\n (total: 495 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_8\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_8\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAAGGAAGGATCGAAGTCCATGGCCAGAACTGGGGCCATCGCGCGGTGGTGTCTCGCCGCAGTGCTGATGGCCGGGCTGGCCGCCTGTGGCGGCGCCCCGAAAAAGCCGGACCCCATCACGGTCAGCATCCAGGCCGCGCCGGACGTGAATCCGGACCTCCAGGGACGGCCGTCTCCCATCGTGCTGCACATCCTGGAACTGAAGTCCGCGGAGACCTTCAACAGCCTCGATTACGTCAGCCTCACGGATCCTTCGGGCGCGGCGCTGGGCGCTGATCGACTGAACGGGATTCAGCTGGTCGTGGCGCCGGGCGGTTCCAACCTGCAGACGCTGGAAATCGACTCCGGGACTTCCGCCATCGGATTCGTCGCGGGCTACCGCGACATCGACAACGCGAGCTGGCGCCAGGTCGTGCCCATCGTGGCGGGAACCACCACCACGATCGCGGTGAACCTGGGGCAGTTCCAGGTCACCACCTCCTCCCAGAACTGA",
    "translation": "MKEGSKSMARTGAIARWCLAAVLMAGLAACGGAPKKPDPITVSIQAAPDVNPDLQGRPSPIVLHILELKSAETFNSLDYVSLTDPSGAALGADRLNGIQLVVAPGGSNLQTLEIDSGTSAIGFVAGYRDIDNASWRQVVPIVAGTTTTIAVNLGQFQVTTSSQN",
    "product": ""
   },
   {
    "start": 7320,
    "end": 8654,
    "strand": 1,
    "locus_tag": "ctg314_9",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,320 - 8,654,\n (total: 1335 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_9\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_9\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCCTGGACATCCAAGATCATCTGGTCGGAGGGCATGTTTCTCCGACCCCAGCATTTCCAGCAGAACGACCGCTACTTCGAGGCCCTGCTGGAGAATCGCACCGCGCCCCTGCGTCCGTACGCCTGGGGCGTGGTTGAACTGACACTCAGCCAGGAGGCCCTGAGCCTGGGGAAAATCGAGATCGCTTCCTGCCGGGCCGTCATGCCCGACGGGACCGCGGTCGTGATCCCCGGAGCCGACGCGGCGCCGCCGCCCATGGTGCCGGACAAGAATCTCAAGAACGAGAACGTCTACCTCTGCCTGCTGGAACGGCGGCCCAACGCCACCGAATCGAGCCGGGAGGAAAGCGACCGGGAAGAGACCCGCTTCGGCGTCCAGATTTCCGACGTGCGTGACACCAGCCTGCCCGAGGACAGCGTCGCGCCCATCGAACTGGCGCGGCCGCGACTGCGGCTGCTCGGCGAGCACGACGAACGGGAGGAGTTCGCCTGCATTCCCATCGGGCGACTGGTGGAGGTGCGCGCCGACCAGCAACTGGTGATGGACGCCGAGTACATCCCCACCTGCATGGACTGCCGCAACGAGGTCACGCTCAACGGATACATCAAGGAACTGCAGGGGCTGCTCAAGCACCGCGCGGAGGAAATCGCAGCGCGCCTGGCCGCCGAAGGCCGGGGCGGCACGCCCCAGGTCCAGGATTACCTCATCCTGCAGGTGGTGAACCGCTACGAGCCGCTGTTCGCCCACCTGGCGTCCCTGCCGCACTACCACCCCGAGTCGTTGTTCCAGGTCTGCCTCATGCTGGCCGGTGAACTGGCGACCTTCCTGGACGAGGGCAAGCGGCCCAAGAACCTGCCGGACTACGTGCACACGGACATCGCCGCGGGCTTCACGCCGCTCATGCACGAGCTTCGCAACCTCCTCGGCCACATCATCGAGTCCAGCGCCGAACAGCTGGTGCTGAAGGAATACACCAAGGTCGGCATCCACCTCGCGGTGGTGAACGACAAGGGCCTGTTCGAGAACGCGGATTTCGTGCTCGCGGTCAAGGCGGCGATGCCTTCCGAAACGCTGCGCTCGCAGTTCCCGCGCCAGGCGAAGATCGGGCCGAAGGAAAAGATGAAGACGCTGATCACCTCGCAGTTGCCGGGCATCGGGCTCGAGTCCCTGCCGGTGGCGCCGCGGGAAATTCCCTTCCATTCCGGGTTCAACTATTTCCGCCTGGACCGGACGGCCGAGCTGTGGCGTGAGCTGCCCACCTCGGGCGGTCTCGGTCTGCACCCGGGCAAGTTTCCGGACCTCGAGCTCGAACTCTGGGCCATCAGGGGCTAG",
    "translation": "MSWTSKIIWSEGMFLRPQHFQQNDRYFEALLENRTAPLRPYAWGVVELTLSQEALSLGKIEIASCRAVMPDGTAVVIPGADAAPPPMVPDKNLKNENVYLCLLERRPNATESSREESDREETRFGVQISDVRDTSLPEDSVAPIELARPRLRLLGEHDEREEFACIPIGRLVEVRADQQLVMDAEYIPTCMDCRNEVTLNGYIKELQGLLKHRAEEIAARLAAEGRGGTPQVQDYLILQVVNRYEPLFAHLASLPHYHPESLFQVCLMLAGELATFLDEGKRPKNLPDYVHTDIAAGFTPLMHELRNLLGHIIESSAEQLVLKEYTKVGIHLAVVNDKGLFENADFVLAVKAAMPSETLRSQFPRQAKIGPKEKMKTLITSQLPGIGLESLPVAPREIPFHSGFNYFRLDRTAELWRELPTSGGLGLHPGKFPDLELELWAIRG",
    "product": ""
   },
   {
    "start": 8660,
    "end": 10009,
    "strand": 1,
    "locus_tag": "ctg314_10",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_10</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_10</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 8,660 - 10,009,\n (total: 1350 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_10\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_10\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCTGAACACGACGACCCGTTCTTCGATCCAGACGAAGAAAAGACCATCATCAAGCCCAGTCCCGGGGGGCGCCGGCCGACCGCCCCACCCCCCGGCGGCGGGGCGCCGCCGCCGCCCTCGACACCGCGCGGCCGGGTCGAACTGAAAGGCCGCCAGGGCCTGAACCCCCTGGAGCGTTCCGCGGCCATCCTGCTCAACCTGCTCAGCCAGATTCGCAACACGCCGACGCACCCCAACCCGGAAGGACTGCACCAGCAGCTCGCCGGTGAAATCACCCAGTTCGAACGGCGCGCCCAGGCCGAGGGCATTCCGCCGGAAACCATTTATATCGCACGTTACGCCCTGTGTTCGACCATCGACGAATTCGTGATGGCCACCCCCTGGGGCGCCCAGAGCAACTGGTCACGCCAGAGCCTGCTGAGCCTGTTTCACAAGGAAACCTTCGGCGGTGAGAAATTCTTCCGGCTCCTGAACAAGCTGGAGCAGGACGCGGCCCGCAATCTCGACCTCCTGGAACTGTTCTACCTCTGTCTCGCCCTCGGTTTTCGGGGCCGCTACGCGGTATCCAATGACGGGATCAATGAGCTGGAACGCGTCCGGGAAAATCTCTACCACGTCATCCGCAACCACCGCGGCGAGTACGAGACGGGCCTGTCGCCGCATTGGGAAGGACTGGACAAGCACGCCACGGCGCGGGGGCCCCTGGTGCCCGCGTGGCTGGCCGCCTGTATCGCGATCCTGCTGCTGGTGGGTCTGTTCAGTCTCTGGCGCTTCAGTCTCAGCGGCCATGCCGACCCGGTGCACGCCGAAGTGATGGGCATCGGCCGCGAGGCCGGCCTCATCCCCAACCACATCCTGGCACCCGAGCCGGTGATGAACATTCCCGACCCCGAACCACCACGCTTCTCCCTGGCGCGTTTCCTGGCGCCCGAGATCCAGGCCGGCAAGGTCAGCGTGGACGAGTTCCCCGACCGCATGGTGGTGTCGATCAAGGGCGATGGCCTGTTCGAGTCCGGCAGTGAACGGATCAAGTCGGAGTACCTGCCCATCCTGCGTCGCATCGGCGAGGGACTGGAGCAGACCACGGGCCGTGTCCGGATCGTCGGCCACTCAGACAACGTCCCCATGCGCGCCAGCGGGCGTTTTCCCTCCAACTTCGAACTGTCCCAGGCAAGGGCGGAATCGGTGGTGACCGTGATCCATGAACAGATGCTCGACCCGGCGCGAACCGTTGCCGAAGGGCTCGGCGAAACGCAGCCCATCGCCAGCAACGACACGCGTGAGGGCCGGGCCCAGAACCGACGGGTCGAAGTGGTCGTGATGCAGCGCGCCGGGGGGGCAGGCTGA",
    "translation": "MAEHDDPFFDPDEEKTIIKPSPGGRRPTAPPPGGGAPPPPSTPRGRVELKGRQGLNPLERSAAILLNLLSQIRNTPTHPNPEGLHQQLAGEITQFERRAQAEGIPPETIYIARYALCSTIDEFVMATPWGAQSNWSRQSLLSLFHKETFGGEKFFRLLNKLEQDAARNLDLLELFYLCLALGFRGRYAVSNDGINELERVRENLYHVIRNHRGEYETGLSPHWEGLDKHATARGPLVPAWLAACIAILLLVGLFSLWRFSLSGHADPVHAEVMGIGREAGLIPNHILAPEPVMNIPDPEPPRFSLARFLAPEIQAGKVSVDEFPDRMVVSIKGDGLFESGSERIKSEYLPILRRIGEGLEQTTGRVRIVGHSDNVPMRASGRFPSNFELSQARAESVVTVIHEQMLDPARTVAEGLGETQPIASNDTREGRAQNRRVEVVVMQRAGGAG",
    "product": ""
   },
   {
    "start": 10009,
    "end": 13530,
    "strand": 1,
    "locus_tag": "ctg314_11",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_11</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_11</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,009 - 13,530,\n (total: 3522 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_11\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_11\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGGGCCCCTCATGTCCATGCTGATCACCTATGGCGTGTTCTCCGGGCTGGCCGTGGGCGCCCTGGCGATCATGGTCTGGTACTACGGGCCGCTGATCCGCTTCGGCAGCTTTGACCCACTAGGGCCGCCGGTGAACCGGATCATCGTGATCGTCGTCCTGATCCTCGGCTATTTCCTGGTTCGCGGGTTCAAGGCCTGGCGCAACCGCAAGAAGTCCGAGGCGATCTCCAAGGACCTGGCCAAGGGCGCCGCGGCCGCGGACCCCACGGCCGAGCAGTCCGCCGAGGAAATGGCCGAACTCAAGGGCCGCTTCGACGAGGCCCTGTCCGTCCTGAAGAAAAGCGAGGTCGGCGGCAAGAAGATCAAGTCCATCTACCAGCTGCCCTGGTACATCATCATCGGTCCCCCGGGGTCCGGAAAGACCACCGTGCTGGTCAATTCCGGCCTCCAGTTCCCGCTGGCCGAAAGCCTGGGCGACCAGAAGGTCCAGGGCGTGGGCGGTACGCGTTACTGCGACTGGTGGTTCACCGACGAGGCGGTGCTGATCGACACGGCCGGCCGCTACACCACCCAGGACAGCAACCAGGATGTCGACAACTCGGCCTGGCTGGGCTTCCTCAAGCTGCTCAAGAAGCACCGCGCGCGGCGGCCCATCAACGGCATCATCCTGGCCATCAGCACGGAAGAGCTGCTGCGCCAGAGCGAGCGCGACAAGGAGCGCACGGCCAAGGCCATCAGCGACCGAATCCAGGAGCTCTACGATCAGCTGGGGGTGCGGTTCCCGATCTACCTGATGTTCACGAAGTCCGACCTGCTGGCCGGCTTCATGGAGTTCTACGGCGACCTGGACCGCAATGAGCGGGCGCAGGTCTGGGGCTTCACCCTCGGGCTCGACGAGGACCCGCTGAAGGCCTTCGACGGCGAATTCTCCGCGCTGCAGCAGCGCATGGAGGAACGGCTGGTGCAGCGCCTCCAGGAGGAGCGCGACGTCCAGCGCCGCGAGCTGATCTACAACTTCCCCCTGCAGATGGCCTCTTCCCGCGAAGCCATCGAGCAGTTCCTGGGCCAGGTGTTCAAACCCAGCCGCTTCAAGACCACGCCCCTGCTTCGCGGCGTGTACTTCACCAGCGGCACCCAGGAGGGCACGCCCTTCAACCGGATCATGAGCCAGCTGGCCAGCAACTTCAGCCTGAGCCGCTCGGCCACGCAGTCCATGCCCTCCAAGGGCAAGGCCTTCTTCATCCAGGACCTGATGATGAAGGTGATCTTCGGCGAATCGGGCCTGGCCGGCGCGAACCTGAAGGTCGAGCGCATGTACGGCATTGCGCGCAAGGCCGGCTGGGCGGCGCTGATCGCCGTCCCCATCCTGCTGAACATCGCCTGGTGGATCAGCCATGGCGCCAACAAGGGCCTGATCGCCGATGTCGACCAGTCCGCCGTGGAAATCCGCGAGACCATCGACGACGTCAAGCCCAGCGATGCCTCCATGCGCGGCATCCTGCCCCTGCTCAACGAGGCCCGGGCGCTGCCCGTGGGCTACGAGGCGAGCTTTGAGTCCCCGCCCCTGCGCATGCGCTGGGGCCTGTACCAGGGGGACCGGCTGGGTGAGAACGGCACCATTCCGGCCTACAAGCGCATCCTCGAACAGGCGTTCCTGCCCCGACTCATGATCGGCATGGAGCAGGACCTGAACGCGAGCATGAACGACCCGAACCGGGTCTACGAACTGCTGAAGGCCTACCTGATGCTGGGCACGCCCGACCGCCTGGACGAGGACTACGTCCGCGAGGTCGTCACGGCCGACTGGGACAGGGACCTGGCCCGCGTCATGACCAACGAGCAACTGGACGAGCTGAAGGGGCATCTCGACGCCCTGCTCGACCTGCAGCCCCTGTCACCGCCCTTCGACCTGGACCGCAACCTGGTGACCAGCGCGCGCATCGTGCTCGGCCGGACCACCCTGGCCCAGCGCATCTACTCCGTCATCAAGAGCGAGCACATCGACGAGGGCGAAACCTACTCTCTCGGCACCATGACCGGCCCCGACGGCCCCCTGGTGTTCACCCGCTCCAGCGGCGCGCCCTTCAACAGCGGCGTGCCCGCGTTCTTCTCGCCCCTGGGCTACCAGGAGATGTACCTGCCGGCGGAAGAGGACGCCATCGAGCAGGTCGAGGACGAGGCCTGGATCTTCGCCACGGAGGCCACGGACGCCGTCCAGGTCTCGGAAACGGACCTGATCAACGGGATCCGGCTGGCCTACCTCGAGGACTACGTTCGCAGCTGGATCGATTTCCTGGAAGACGTGCGCATCCGGCCGTTCAGCGGCATGGAACAGGCCGCCAGCATCCTGCTGGTGCTCTCCGGCGATGCCTCGCCACTGCGGCAGTTGCTGGTGAACGTGTCCAACGCCACCCGCCTCACGCCCGAGGAGGTCATACGTGGCGCCCAGGAGGACGCCTCCCTGCGCGAGAAGTTCGAAGCCATCCTGCGCAGCCAGGGCACCAACCCCGACCTCGTGGACCCGGCCATGGTGGACCGGAGCTTCGCCGGCGTGCATCAACTCGCCGGGGGCGCCGACGACGGCAGGCCCTCGCCGCTGGACACGCTGATCGCGGACCTGGACAACCTGTACCGCTACATCGAGACCCTGTCACGGGCCTCGGCCGACGCGCTCATCAGCGACATGCAGAACGAGGCGAGTTCCGCCCTCACGGCAGTGCGCCAGCGGGGGCAGCGCACGCCGGCGCCCATCCGGGACTGGGTGCTGGACGTGGTCTCGCAGAGCGACAACCTGATCGCCGGGGACGCGTCCACGGCCATCCAGGCCGCCTGGTCCGCGGAGGTGGCGCCGTTCTGCCGCCAGGCCATCAATGGCCGGTACCCCTTCAATCGCGACAGCACGCAGGCCGTGCCGCTGTACGATTTCGGCACCTTCTTCGCGCCGAACTCGGGCATTCTCGACACCTTCTTCAACAAGTACCTGGCCCAGGTGGTGGACACCACCCGGCCGACCTGGGCGTTGCGCCCGGCGTACGCCAACACGGTCCGCATCAACCCGTCTTCGCTGCGCTACATGCAGCAGGCGAAGAACATCCAGCGGGCCTTCTTCTCCGGCGGTGGCGCCCTGCCCTCGGTCACCTTCGAGATGCGCCCGGTACGCCTGGATGCGGCCGCCACGAACTTCACGCTCAGCATCAATGGCGAGAGCACCAGCTACAGCCACGGCCCCATCATCGCCAAGACCTTCCGCTGGCCGGGTGACGCCGTCCAGGGCATGGTGGGTTACCAGTTCGTGCCGGCGAGCAGCGCGGGCCGCTCGGGCAATTCGGAAACCGGCCCCTGGTCCCTGTTCCGCATGTTCGACCGCTCGGGGCTGCAGGCCTCGGGCAACTCGGAAGCCTTCCAGGTGCGGTTCGAACTGGACGAGCGCTGGGCGGAGTACGAGATCCGCGCCGCGAGCGCCTTCAACCCCTTCGACCTGCGCGACCTGCGCAGCTTCCGCTGCCCGGACCAGCTGTGA",
    "translation": "MGPLMSMLITYGVFSGLAVGALAIMVWYYGPLIRFGSFDPLGPPVNRIIVIVVLILGYFLVRGFKAWRNRKKSEAISKDLAKGAAAADPTAEQSAEEMAELKGRFDEALSVLKKSEVGGKKIKSIYQLPWYIIIGPPGSGKTTVLVNSGLQFPLAESLGDQKVQGVGGTRYCDWWFTDEAVLIDTAGRYTTQDSNQDVDNSAWLGFLKLLKKHRARRPINGIILAISTEELLRQSERDKERTAKAISDRIQELYDQLGVRFPIYLMFTKSDLLAGFMEFYGDLDRNERAQVWGFTLGLDEDPLKAFDGEFSALQQRMEERLVQRLQEERDVQRRELIYNFPLQMASSREAIEQFLGQVFKPSRFKTTPLLRGVYFTSGTQEGTPFNRIMSQLASNFSLSRSATQSMPSKGKAFFIQDLMMKVIFGESGLAGANLKVERMYGIARKAGWAALIAVPILLNIAWWISHGANKGLIADVDQSAVEIRETIDDVKPSDASMRGILPLLNEARALPVGYEASFESPPLRMRWGLYQGDRLGENGTIPAYKRILEQAFLPRLMIGMEQDLNASMNDPNRVYELLKAYLMLGTPDRLDEDYVREVVTADWDRDLARVMTNEQLDELKGHLDALLDLQPLSPPFDLDRNLVTSARIVLGRTTLAQRIYSVIKSEHIDEGETYSLGTMTGPDGPLVFTRSSGAPFNSGVPAFFSPLGYQEMYLPAEEDAIEQVEDEAWIFATEATDAVQVSETDLINGIRLAYLEDYVRSWIDFLEDVRIRPFSGMEQAASILLVLSGDASPLRQLLVNVSNATRLTPEEVIRGAQEDASLREKFEAILRSQGTNPDLVDPAMVDRSFAGVHQLAGGADDGRPSPLDTLIADLDNLYRYIETLSRASADALISDMQNEASSALTAVRQRGQRTPAPIRDWVLDVVSQSDNLIAGDASTAIQAAWSAEVAPFCRQAINGRYPFNRDSTQAVPLYDFGTFFAPNSGILDTFFNKYLAQVVDTTRPTWALRPAYANTVRINPSSLRYMQQAKNIQRAFFSGGGALPSVTFEMRPVRLDAAATNFTLSINGESTSYSHGPIIAKTFRWPGDAVQGMVGYQFVPASSAGRSGNSETGPWSLFRMFDRSGLQASGNSEAFQVRFELDERWAEYEIRAASAFNPFDLRDLRSFRCPDQL",
    "product": ""
   },
   {
    "start": 13527,
    "end": 14276,
    "strand": 1,
    "locus_tag": "ctg314_12",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_12</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_12</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,527 - 14,276,\n (total: 750 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_12\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_12\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GTGAGCGAACTCGACCGCGTCTCCGACCCGGGGTTCTACGGCAAGCTGCCGGCCTACGGGGACTTCATCCAGAAGCGCCTGCCGCGCGATTTCACCGCGCCCTGGGACGACTGGTTGCAGGCCGGCATCGCCGCCGCCAAGGAACGCCTTCCGCAGGAGTGGCTGACCTTCTATCTCAGCTGCCCCGCCTGGACCTTCGTCCTGGGGAATGGCATCTGTGGGGAACAGGCCGTGGCGGGGGTGACCATTCCCAGCGTCGACAAGGTGGGGCGTTACTTCAACTTCACCCTGGCCGCGCTGCTGCCGGCGGGGACTTCTCCCGCCCTCTTCCTGGCCCGGCACCACGCCTGGCTGGGTGACCTTGAGGACCTGGCGCTGACGGCCCTGGGCGACGAATGGGACCAGGACCGCATCGACCAATCGCTCAATGAACTGCCGACACCGGAGGTCGAGGGCCTGCGTTCACCCGGTACGCTGGAACGCGGCGACGACTGGATGCGCCTGGCGTTCACCGGCGCCGACACGGCCACCGGCCGCCTCGACGCACTGCTGCATGCCCTGGTCCAGGAGGGACGGGAAGGCAGCTACGGCCTGTGGTTGCAGGACGGATCCAACCAGGTGGGCCCACAGCTGCTGTGCTGCCGTCACCTGCCGGCCACGTCCCTGTTCCTCGACATGATGGTCAGCACGGACGCTGAAGACCCCAAGAGCGAGGGCGACGATGTCCTCGACGAGTTCCTGTCCCAATGA",
    "translation": "MSELDRVSDPGFYGKLPAYGDFIQKRLPRDFTAPWDDWLQAGIAAAKERLPQEWLTFYLSCPAWTFVLGNGICGEQAVAGVTIPSVDKVGRYFNFTLAALLPAGTSPALFLARHHAWLGDLEDLALTALGDEWDQDRIDQSLNELPTPEVEGLRSPGTLERGDDWMRLAFTGADTATGRLDALLHALVQEGREGSYGLWLQDGSNQVGPQLLCCRHLPATSLFLDMMVSTDAEDPKSEGDDVLDEFLSQ",
    "product": ""
   },
   {
    "start": 14296,
    "end": 15057,
    "strand": 1,
    "locus_tag": "ctg314_13",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_13</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_13</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,296 - 15,057,\n (total: 762 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_13\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_13\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAACATCCTTTCAAAGGCCGCGACCCACGTCGGCATGGTGCGAGAACTCAATGAGGACTCCTTTCTCGACCTCGGCGAGGAAGGTGTCTGGGTGGTCGCCGACGGCATGGGCGGCCACGAGTCCGGAGAGGTGGCCAGCCAGGCCGTCGTCGGCGAAGTGGGGCGCATGTCACGCTCCGACAGTTTCGAGGCGTCACTGGAGCACCTACAGCAACACATCCTCGACGTGAACGAGGCCCTGGTGAACGATGCGGAGCGGTTCAGCCGCGACCGCCAACCGGGGAGCACCATCGTCGCGCTGCTGATCCAGGACGGCCAGGGCGCCGTGGTCTGGGCCGGCGACAGCCGTATCTACCGGCGGCGGTCCGACACCTTCGAGCAGCTCACGCGCGACCACAGCCATGTCCAGGAACTGCTCGACAACCACCTGATCCGCCCGGAAGAGGCGGAAAAACACCCCATGTCGAACGTGATCACCCGGGCCGTCGGCATCGACGTTCCCCTGGAAATCGACACCCGCACCTTCCAGGTCCTGGACGGCGACCAGTTTCTGCTGTGCTCCGACGGGCTGACGCGGCTGGTCGAGGACCGGGAAATCGACGAAATGATGAACAACAGCGACAGCGAGGAAGTCGTCCAGTCCCTGTTGCACACGGCCCTGGTCCGCGGCGCGCCGGACAATGTCACCCTGATCTACGTGGCCTGCGGAGACATCGGCGACGGCTCGACCGTCGTCATGAACATCGACGACCTGCTCTGA",
    "translation": "MNILSKAATHVGMVRELNEDSFLDLGEEGVWVVADGMGGHESGEVASQAVVGEVGRMSRSDSFEASLEHLQQHILDVNEALVNDAERFSRDRQPGSTIVALLIQDGQGAVVWAGDSRIYRRRSDTFEQLTRDHSHVQELLDNHLIRPEEAEKHPMSNVITRAVGIDVPLEIDTRTFQVLDGDQFLLCSDGLTRLVEDREIDEMMNNSDSEEVVQSLLHTALVRGAPDNVTLIYVACGDIGDGSTVVMNIDDLL",
    "product": ""
   },
   {
    "start": 15150,
    "end": 15710,
    "strand": 1,
    "locus_tag": "ctg314_14",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_14</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_14</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,150 - 15,710,\n (total: 561 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_14\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_14\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGATTCTAGGCCTGGTGCTGTTCATCGGCAGCCACTCCGTGGCCGTCGTCGCTCCCGGCTGGCGCGACCGTTTCGCCGACAAGCACAAGGCGGCCTGGAAAGCCCTGGTGGTCTTCGTCGCCCTCGCGGGTGTGGTCGGCATCGTGAAAGGCTACGCGGAAGCCCGCCTGGATCCGGTGCTGCTCTGGGTGCCGCCCACCTGGCTGCGCCACGTGGCGGCCCTGCTGCTCCTGCCGGTGTTCGTGTTCTTCCTGGCGCCCTACTTTCCGGGCCGCATCAAGACCACCCTGAAGCACCCCCAGCTGGTCGCGCTCAAGCTCTGGGCCCTCGCCCACCTGCTGGTGAACGGCACCCTGGCGGACATCGTCCTGTTCGGCAGCCTGCTGGCCTGGGCCGTGGTCTGCCGCATCTCCTACCGCTGGCGGCCCGCCAACGAGACCCCGGTGGTGACCCACAGCCGGGCCAACGACTTCATCCTGCTGGCCCTGGGGCTGGCGCTCTACGTGCTTTTCGTGCGCTGGTGGCACCTGGCCTGGATCGGCGTGGCGCCGTTCGGCTGA",
    "translation": "MILGLVLFIGSHSVAVVAPGWRDRFADKHKAAWKALVVFVALAGVVGIVKGYAEARLDPVLLWVPPTWLRHVAALLLLPVFVFFLAPYFPGRIKTTLKHPQLVALKLWALAHLLVNGTLADIVLFGSLLAWAVVCRISYRWRPANETPVVTHSRANDFILLALGLALYVLFVRWWHLAWIGVAPFG",
    "product": ""
   },
   {
    "start": 15712,
    "end": 17889,
    "strand": -1,
    "locus_tag": "ctg314_15",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_15</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_15</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,712 - 17,889,\n (total: 2178 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PF00561<br>\n \n  biosynthetic-additional (rule-based-clusters) Peptidase_S9<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_15\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_15\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGTCCGATGAGCTCGATATTGCACGGCTCGAGGCCAGCCCGGGCCTCGACGGCCCCGTGGCCCGGGGCGTGGAAATCGCCCCGGACGCTTCCCGTGTCACTTTCCTGCGCGGCCGCGAGGACGACCGGCAGCAACTCGACCTGTGGGAATTCCACATCGCCGACGGGGTGGAGCGCCGGCTGGTCGACAGCCAAGCCCTGCTGGGCGCGCCGGAGGTCCTGGACGAGGTCGAGAAGGCGCGCCGGGAACGCCAGCGCGTGTTCTTCACCGGCATCGTGGAATATGCGTGGGCCCCGGACGGCCGGTCACTGCTCTTTCCGCTGGGCGGCGACCTCTACCACCTGCCCCTGGGGGGCGAGCCCCGCCGCCTGACGGACACGGAGGCGACGGAAACCGACGCCCGGGTCTCGCCCGGCGGGCGCTATGTCTCCTTCATCCGCGACCGGAACCTGCACCTCGTCGACCTGGCATCCGGCGATGCCCGGGCCCTGACCGATGGCGCCACGGACACGGTGTCCTTCGGCATGGCCGAATTCGTGGCCCAGGAAGAGATGTACCGCTTCACCGGCTACTGGTGGTCGCCGGACGATCGCCGGCTGGCCTTCACCCGGGTGGACGAGGCGGGCGTGAGCCTGGTCAACCGTTACGAGATCGGCGCGGACGGTGTCACCACGGTGCCCCAGCGCTATCCCTTCGCCGGCGAAGCCAATGCCCGGGTGCAGCTGTTCCTCCTGGACCTGGCGACCGGTGAACAGCGCGAAGTGGCGTTCGACGCCTCGGGTGACGACTACCTCGCCCGGGTCGATTTCGCCCCCGACGGCACCCTGGTGTTCCAGCGCCAGTCCCGGGACCAGCGCCGGCTGGACCTGGTGTTCGTCGACCCGGTCACGCTCGAGCAGACCGTGGTCCTGACGGAACGCGCCGACACCTGGATCAACCTGCACAGCGATCTGCACTTCACCGCCGACGCGCAGCGCTTTCTCTGGACTTCGGAGCGCGACGGTCAGCGCCATCTCTACGTGTTCTCGCGGGATGGACAGTTGCTGCGACAGCTCACGGACGGCGACGGGTCCGTGGCGGAAACCGGCCGCGGCGGCGGGGGCGTGCGCGCGCTCGACGAAGCCAACGGCCTGGCCTGGTTCCTGGCCGGACGCGAGACGCCGATCGAGCAGCATCTCTACCGGGTTCCACTGGATGGCTCGGCCGGGCCGGAGCGCGTCACGGAGGCCGGTGGCTGGCACGAAGCCACGGTCGCCCGCGACGGGTCCTTTTTCGTCGACCGGGGCCAGTCCCCGGACCGTCCTCCCTACACGGCCATCCGCGACGGGGAAGGCGGCCTGCTGGCCTGGGTGCTGGAAAACGCGCTGGACGACTCGCATCCCTATCACCCCTACCTGGCCGGTCACCGCCCCGCGGAGTTCGGCACCCTGCCCGGGGCCGACGGCACGCCGCTGTACTGGGAGATGATTCGACCGGTGGGCTTCGATCCTTCCGGAAAGCACCCGGCGGTGGTGTTCGTCTACGGCGGGCCGGGCGGCGCCCAGGTGCGTCGCGACTGGACCGTGGATTTCCGCCAGGTGCTCGCCCGGGAAGGCTTCGTGGTGTTCACCGTGGACAACCGGGGGACGGGCGGGCGAGGGACGGCCTTCGATGCCCCGATTCACCACCGGCTGGGCTTCGCCGAACTGGAGGACCAGGTCGCGGGGGTCGACTGGTTGGCGCAGCAGCCCGGCGTGGACGGCGAACGCATCGGTATCTACGGCGGTTCCTACGGCGGCACCATGACCCTGCTGTCCCTGTTCCGCGCCCCTGAGCGCTTCGCCGCGGGCGTCGCCCTGGCCCCGGTGACCGACTGGCGCCTCTACGACACCCACTACACGGAACGCTACCTGGGTGATCCGGCGGCCGGCGACGCCTACGAGATCACCAGCCCGATGCGCTATGTCGACGGCCTGGCGGATCCACTGTTGCTGGTGCACGGCATGGCCGACGACAACGTGTTCTTCGACCACAGCGTCAAGCTGATGGCCAGCCTGCAGGGCGCCGGCAAGACCTTCGAACTGATGACCTATCCGGGCAAACGCCACCGCATCACCGGTGAGGCGGAACGCACCCACCTGTACACGATGATGCTGGAATTCTTCCGGCGCCACCTCGCACCGGCGGAAGAGGGTTGA",
    "translation": "MSDELDIARLEASPGLDGPVARGVEIAPDASRVTFLRGREDDRQQLDLWEFHIADGVERRLVDSQALLGAPEVLDEVEKARRERQRVFFTGIVEYAWAPDGRSLLFPLGGDLYHLPLGGEPRRLTDTEATETDARVSPGGRYVSFIRDRNLHLVDLASGDARALTDGATDTVSFGMAEFVAQEEMYRFTGYWWSPDDRRLAFTRVDEAGVSLVNRYEIGADGVTTVPQRYPFAGEANARVQLFLLDLATGEQREVAFDASGDDYLARVDFAPDGTLVFQRQSRDQRRLDLVFVDPVTLEQTVVLTERADTWINLHSDLHFTADAQRFLWTSERDGQRHLYVFSRDGQLLRQLTDGDGSVAETGRGGGGVRALDEANGLAWFLAGRETPIEQHLYRVPLDGSAGPERVTEAGGWHEATVARDGSFFVDRGQSPDRPPYTAIRDGEGGLLAWVLENALDDSHPYHPYLAGHRPAEFGTLPGADGTPLYWEMIRPVGFDPSGKHPAVVFVYGGPGGAQVRRDWTVDFRQVLAREGFVVFTVDNRGTGGRGTAFDAPIHHRLGFAELEDQVAGVDWLAQQPGVDGERIGIYGGSYGGTMTLLSLFRAPERFAAGVALAPVTDWRLYDTHYTERYLGDPAAGDAYEITSPMRYVDGLADPLLLVHGMADDNVFFDHSVKLMASLQGAGKTFELMTYPGKRHRITGEAERTHLYTMMLEFFRRHLAPAEEG",
    "product": ""
   },
   {
    "start": 18005,
    "end": 19972,
    "strand": -1,
    "locus_tag": "ctg314_16",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_16</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_16</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,005 - 19,972,\n (total: 1968 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: PP-binding<br>\n \n  biosynthetic (rule-based-clusters) NRPS-like: AMP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1002:AMP-dependent synthetase and ligase (Score: 313.3; E-value: 4e-95)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_16\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_16\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGAGCCCGGCAAAGGACACCCTGGGCGGCCTGCTGTCCGCCGCCATCGCCCGTGGACCGCGTTCGGTGACCTTCATCGAGGGCGCGCAGGAAGAAGTCCGCGTTTCCTACGACGACCTCCGCGCCCGCGCCCTGGGCGTGCTGCGTCACTTCCAGGCCGCCGGCCTGGAGCCGGGCGACGAACTGATCCTGTTCACCAACAGCAACGAGCAGTTCGTCGACGCCTTCTGGGCCTGCATCCTCGGCGGTATCGTGCCGGTACCCGTGGCCGTGGGCATCAGCGACGACCACCGCGCCAAGCTGCTGCGGATCTTCGCCTCGCTGCGCAATCCCTGGCTGTACACGGAGCGCAACCTCGCACGGCGCCTGGAGCGCTTCGGGGAAGGTCATGACCGCCTGGCCGAGATTGCCCGCCTGCTCGAGCGAACCCTGGTGGTGGACGACATCGAGGACATCGGCACCCCTGGCCGGGTGCATGCCGCGGCGCCGGACGACGTGGCCTTCATCCAGTTTTCCTCCGGCTCCACCAGCGAGCCCAAGGGCGTGGTGCTGACCCACCGCAACGTGATCACCAACATCCGCGCCATCTGCGAGGGTTACGGCAGCCGCGACGACGACGTCGCCGTCAGCTGGATGCCGCTGACCCACGACATGGGCCTGATCGGTTTCCACCTGTGCATGATCGCGGCCAACAACGACCACCACGTCATGGCCACGAGCCTGTTCGTCCGGCGTCCCCTGTTGTGGATGCAGAAGGCGGCTGAGAAGGGTGCGACCCTGACGTGCTCGCCCAACTTCGGCTACAAGCACTTCCTCAAGGTGTTCGAGTCGAAGGGATTGGACGGCATCGACCTGGGCCGCGTGCGCCTGGTGTTCAACGGGGCCGAGCCCATCTCCGCCGCGCTCGCGCGGCAGTTCCTGGAAGCGCTCGCACCCCACGGCCTGGACCCGGACTGCATGTTTCCGGTCTACGGTCTCGCCGAGGCCAGCCTGGGCGTGACCTTCCCCGAGCCCGGGGCGCCCCTGCGCACCGTGATGGCCCATCGCCACGGCCTGGCCGTCGGGGAACCCTGGTCGCCCGCCGAAGGCGACGACCAGGATGCCGTGGAGTTCGTCCTGCTCGGCACGCCGATCCGCGACTGCCAGGTCCGGCTCTGCGACGACCAGGACCACGTCCTGGAGGAAGGGCGGGTCGGCCACGTGCAGATCCGCGGCGGCAACGTCACGCGGGGCTATTACGGCTACCGCGGCAGGAGCCGGGATGTGTTCGCCGACCTCGACTGGCTGCGGACCGGCGACCTGGGCTTCTTCCACGAAGGCCAGCTGGTGATCACCGGTCGCTCCAAGGACATCATTTTCGTCAACGGCCAGAACTACTACCCCCACGACATCGAGGCCCTGGCGGGGGAGCTCGACGGGCTGGAACTGGGCAAGGTCGTGGCCGCCGGCGTCACCAGCCCTGAAGCGGGCACGGACGAACTGCTGCTGTTCGTGCTCGACCGCGGGGAGGTCGCCACCTTCGCGGACCTCGCGCGCCGCCTGCGGGCCCACGTGGGCGAGACCACGGGCCTGGAAGTCGGCCAGGTCATCCCGGTGACGCGCATTCCCAAGACCACCAGCGGCAAGGTGCAGCGGCACAAGCTGACGGAGGCCTACCTGGACGGGGAGTACGCCCCGGTACTGGCCGAACTCGCGGCCCTGGAGACGGTGACCGAGGAAGACCCGGTCCCGGCCGGCGGCATGGAGCAGGCTCTGGCGCAGATCTGCAACAGCATCGTGGTCGACCGCCCGGTCGGCCTGGACGACAACCTGTTCGAGATCGGCATCAGCTCGCTGGCCCTGGCGCAGATCCACGCCCGCGTGGACGAGCTGTACCCCGGTGAAATGGACATTGCCGACGTGTTCGAGTACCCGACCATCCGCGAGCTGGCCGCCTTCCTGGAAGCGCGGCGCGCCGGCGGCGCCTGA",
    "translation": "MSPAKDTLGGLLSAAIARGPRSVTFIEGAQEEVRVSYDDLRARALGVLRHFQAAGLEPGDELILFTNSNEQFVDAFWACILGGIVPVPVAVGISDDHRAKLLRIFASLRNPWLYTERNLARRLERFGEGHDRLAEIARLLERTLVVDDIEDIGTPGRVHAAAPDDVAFIQFSSGSTSEPKGVVLTHRNVITNIRAICEGYGSRDDDVAVSWMPLTHDMGLIGFHLCMIAANNDHHVMATSLFVRRPLLWMQKAAEKGATLTCSPNFGYKHFLKVFESKGLDGIDLGRVRLVFNGAEPISAALARQFLEALAPHGLDPDCMFPVYGLAEASLGVTFPEPGAPLRTVMAHRHGLAVGEPWSPAEGDDQDAVEFVLLGTPIRDCQVRLCDDQDHVLEEGRVGHVQIRGGNVTRGYYGYRGRSRDVFADLDWLRTGDLGFFHEGQLVITGRSKDIIFVNGQNYYPHDIEALAGELDGLELGKVVAAGVTSPEAGTDELLLFVLDRGEVATFADLARRLRAHVGETTGLEVGQVIPVTRIPKTTSGKVQRHKLTEAYLDGEYAPVLAELAALETVTEEDPVPAGGMEQALAQICNSIVVDRPVGLDDNLFEIGISSLALAQIHARVDELYPGEMDIADVFEYPTIRELAAFLEARRAGGA",
    "product": ""
   },
   {
    "start": 19969,
    "end": 21369,
    "strand": -1,
    "locus_tag": "ctg314_17",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_17</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_17</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 19,969 - 21,369,\n (total: 1401 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) p450<br>\n \n  biosynthetic-additional (smcogs) SMCOG1034:cytochrome P450 (Score: 350.2; E-value: 3e-106)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_17\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_17\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGCCGGTCCCGCCCGGCTCCGGTGTATAATTCGCCGCTTGTATCACGCGGCCCCGTGGGGCCCCGGCGGCAAGCGCGACCCCATGAGCCAGACCCCCCAGACCACGCCCACAGCACCCGGACCGGTGGACCCCCACCCCCTGGACTGCGACGAGGCCACTTTTCACCTGATTCCGCGCCTCGTGGCGGAACATGGCGAAGTGGTGCGCGTGGCCGTGCCCAACCTGGACCGGCCCACCTGGGTGATCGCCGACCCGGCCGACATCCGGCGGGTGCTGGTGAGCAACCATCGCAACTACGTCAAGGGCGTGGGCTTCGAGCGCGTGGAGATGCTGCTGGGCAACGGCATCATCGTCAGCGACGGCGCCTTCTGGCGCCGGCAGCGCACCATGATCCAGCCGGCCTTCAGCCGCGGCAACATGCCGCGTTTCTTCGATATGGTGCGCGAGGTGACCCTGCGCCTGAAGGAAGAATGGCTGGCCGCGGCCCGCGAGGGTGGGGAAATCGACATCACCCGGGCGACCAGCGACTACGCGCTGGAAATCATCCTGCGACTGATCTTCAGCGACGACCTGGAGTTCTTTGTCGACCAGGAAGGCATCAACCCCTTCCTGTTCCTGACCGAGGATCCCTCGCGGGACCTGCGGGTGGCCATGAAATTCCGCCAGTTGCTCAAGCAGGTCCGGGTGCTGATCGAACGACGCCGCGAGACCGGCGAGCGACCGTTCGACCTCTTGTCCATGATGATGGACGCCCGCGCCAGCCGCACCGAGGAAGCCATGAGCGACAAGGAGCTCGTCGACGAGGTCGCCACGCTGATCATCGCCGGACACGAGACCTCCGCCGGCACGCTGAACTGGGCCTGGACGCTCTTGTCCGGCGACGAGGACAGCGCCCGGGCCCTGCGCGAGGAATCGCGACGCGTCTGCCCCGACGGCGAGCTCACCTACGAGCACCTGGAAGAACTGGTCTTCACCCGCCAGGTGCTGGATGAAACCCTGCGCCTCTATCCCCCGGTCTGGCTGTTCACCCGCCGTGCGGTCGAGGCCGACGAACTCGGCGGCCATGCCATCGAGGCCGGGGACAACGTGTTCCTGTCGCCCTGGCTCACCCAGCGGCTCGAGCGCCTCTGGCCGGAGCCGGACGCCTTCCGGCCGGAACGCTTCGCGCCGGGCCGGGACGAGGCACGCGAGGACCAGGCCTTCTTTCCCTTCTCCGCCGGGCCGCGCCGTTGCATCGGCGAATTCTTCTCCTACGTGGAAATGCGGACCCACCTGGCCTTGCTGGCCCCGGTGTTCCGCCTGCGGCTCGTGCCCGGGCAGGACATCGCGCTGGAGCCGGCCATCAACCTGCGCACGAAACACAACCTGCGCATGACCGTGGAGGCCCTGCAGCCATGA",
    "translation": "MAGPARLRCIIRRLYHAAPWGPGGKRDPMSQTPQTTPTAPGPVDPHPLDCDEATFHLIPRLVAEHGEVVRVAVPNLDRPTWVIADPADIRRVLVSNHRNYVKGVGFERVEMLLGNGIIVSDGAFWRRQRTMIQPAFSRGNMPRFFDMVREVTLRLKEEWLAAAREGGEIDITRATSDYALEIILRLIFSDDLEFFVDQEGINPFLFLTEDPSRDLRVAMKFRQLLKQVRVLIERRRETGERPFDLLSMMMDARASRTEEAMSDKELVDEVATLIIAGHETSAGTLNWAWTLLSGDEDSARALREESRRVCPDGELTYEHLEELVFTRQVLDETLRLYPPVWLFTRRAVEADELGGHAIEAGDNVFLSPWLTQRLERLWPEPDAFRPERFAPGRDEAREDQAFFPFSAGPRRCIGEFFSYVEMRTHLALLAPVFRLRLVPGQDIALEPAINLRTKHNLRMTVEALQP",
    "product": ""
   },
   {
    "start": 21502,
    "end": 22275,
    "strand": 1,
    "locus_tag": "ctg314_18",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_18</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_18</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,502 - 22,275,\n (total: 774 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_18\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_18\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGACCGACCCACAACGCAGCTACGCGCCAAGCCAGAAGGCCCAGCGCTCGCGGACCACCGGCGAGGAAGCGACCTCGCGCCGGCGCATGTCCGCCGGACGCAAGGTCTGGTACGCCTTCCTGGTGGCGCTGGCCAAGGTGCTGGTCAAGTCGCTGTGGTCCACCTGCCGCGTTGAGAAGGTGATCGGCGCCGAGCACATGGACGCGGCGCTGGCCGCCGGCGAACCCATCATTCCCTGCTACTGGCACCAGATGCACCTGTTCTGCACCCGCTACATGCTGGAACTGAAGGAAGGCGGCCTGAACGTCGGTTTCCTGATCAGCCCCTCGGTGAGCGGCGAGGTGCCCGCGGCCATGGCGCGCTCCTGGGGCGCGGCGGTGGTGCGCGGTTCCCCCACCCGCACCGGCGGGCAGGCCCTGCGCGACATGTACCTGACCGTCCGCAAGGAAGGCGTGTCCCCGGTGATCACCGTCGACGGTCCCAAGGGCCCGGCGGAAGTGGTGAAGATCGGCGCCGTGCTGCTCGCCCGGCTGACCGCCACGGCCATGGTCCCGGTGGCCTGCGGCGCCAGTTCGGCGCTGCTGTGGAACAGCTGGGACCGCTTCATGGTGCCCCGGCCCTTCTCCCGCATCGTCATCGTCGTCGGTGAGCCGCTGCGCGTCCCGGAAGGCACCCCCATCGACGAGCTGGAGCCCATCCGGCTGGAACTGGAACAACGGCTGAAGGACGCCGACCGGCAGGCGAAGGCCTACTTCGACACCCGGCCCGCCTGA",
    "translation": "MTDPQRSYAPSQKAQRSRTTGEEATSRRRMSAGRKVWYAFLVALAKVLVKSLWSTCRVEKVIGAEHMDAALAAGEPIIPCYWHQMHLFCTRYMLELKEGGLNVGFLISPSVSGEVPAAMARSWGAAVVRGSPTRTGGQALRDMYLTVRKEGVSPVITVDGPKGPAEVVKIGAVLLARLTATAMVPVACGASSALLWNSWDRFMVPRPFSRIVIVVGEPLRVPEGTPIDELEPIRLELEQRLKDADRQAKAYFDTRPA",
    "product": ""
   },
   {
    "start": 22366,
    "end": 23319,
    "strand": 1,
    "locus_tag": "ctg314_19",
    "type": "other",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg314_19</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg314_19</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,366 - 23,319,\n (total: 954 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg314_19\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg314_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg314_19\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "ATGGTGGTCGGCAATCAAGCATCGGCCGGACACACCCGCGTGGACACGACAGGCGCACTGAACGCCGCATCGAAGACAGCACCGGCTCACGGACTGCGCCCGCTGGGGGAACTCAGCGCCGCGGAGCGCCTCAATTTCCTGCTCACCAACCGCATCCCGCGGCAGGCGGCCACCCGCTTCATGGGCTGGTTCAGCCGCATCGAAAACCGGCTGCTGGCGAAGGCGAGCATCGGCCTGTGGCAATGCTTCGTCGACGACCTGCGCCTGTTCGAGGCCGAGCAGACCCGGTTTGCCAGCCTGCAGCAGTGCTTCACCCGGCGCCTGAGGCCCGGCGCCCGCCCGGTGGACCCACGGCCGGAGGTGTTCACCAGTCCCTGCGACGCCATCATCGGCGCCCATGGCGAACTGGACGGCCTGGCGGCGCTGCAGGCGAAGGGCTTTCCCTATGGCATCGACGAACTGCTGGGTGACCCGGAGGCCGCCGAACGCCATCGCGGCGGCTTCTACCTCACGCTGCGGCTCAAATCGAGCATGTACCACCGCTTCCACGCCCCGACCGACGGTCGCGTCGGGCGCATCCGCTATCTCTCGGGCGACACCTGGAACGTGAACCCGGTGGCCCTGAAAGTGGTCGAGCGCCTGTTCTGCCGCAACGAGCGGGTGGTGTTTCCGTTCCAACCCGCCGATGACGGCCCCCCTCTGACCCTGGTGGCGGTGGCCGCCGTGCTGGTGGCCAGCGTCGGCATCCACGGCCTCGAGCACCCCCTGGACCTCGACTGGGGCGGCCCCACGCTGATCGACCTCGACCGGGATTACACCCGCGGCGAGGAGATGGGCTGGTTCCAGCATGGCTCGACCCTGGTGGTTCTGGCGCCGCGGGGCGCCACCCTGTGCGAAGGATGGCGGCAGGGCGACACCGTCCGCATGGGCCAGGCCCTCCTGCAACGGCTCTGA",
    "translation": "MVVGNQASAGHTRVDTTGALNAASKTAPAHGLRPLGELSAAERLNFLLTNRIPRQAATRFMGWFSRIENRLLAKASIGLWQCFVDDLRLFEAEQTRFASLQQCFTRRLRPGARPVDPRPEVFTSPCDAIIGAHGELDGLAALQAKGFPYGIDELLGDPEAAERHRGGFYLTLRLKSSMYHRFHAPTDGRVGRIRYLSGDTWNVNPVALKVVERLFCRNERVVFPFQPADDGPPLTLVAVAAVLVASVGIHGLEHPLDLDWGGPTLIDLDRDYTRGEEMGWFQHGSTLVVLAPRGATLCEGWRQGDTVRMGQALLQRL",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 18004,
    "end": 19972,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 23478,
    "product": "NRPS-like",
    "category": "NRPS",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [
    {
     "start": 4497,
     "end": 4499,
     "strand": -1,
     "containedBy": [
      "ctg314_6"
     ]
    }
   ],
   "bindingSites": []
  },
  "type": "NRPS-like",
  "products": [
   "NRPS-like"
  ],
  "product_categories": [
   "NRPS"
  ],
  "cssClass": "NRPS NRPS-like",
  "anchor": "r314c1"
 },
 "r374c1": {
  "start": 1,
  "end": 7328,
  "idx": 1,
  "orfs": [
   {
    "start": 2,
    "end": 5755,
    "strand": 1,
    "locus_tag": "ctg374_1",
    "type": "biosynthetic",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg374_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg374_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2 - 5,755,\n (total: 5754 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) NRPS: Condensation<br>\n \n  biosynthetic (rule-based-clusters) NRPS: AMP-binding<br>\n \n  biosynthetic-additional (rule-based-clusters) PKS_AT<br>\n \n  biosynthetic-additional (rule-based-clusters) Aminotran_3<br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1013:aminotransferase class-III (Score: 284; E-value: 3.2e-86)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg374_1\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg374_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg374_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg374_1\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "GCGACACCCGACCAGCTGGCCGAGTTCATCGACGACGAAGTCTGCGTCGCGGCCCGGAATGCGCCGGAGGCCTGCGTGCTGTCCGGACCGTCGGAACGACTGGAAGCGATCGCGGAAACGCTCCGGGCCCGGGACCTGCGCGTGGCCATGCTCAAGACTTCCCACGCCTTCCATTCGAGCATGATGGATGGCGCCCTGGAAGCATTCACCGCGGTCGTCGACGGCGTCGCGCGGCACGCGCCCCGGATACCGATCATCTCGACCTGCACCGGCCAGTTGCTCAGCGACGAGGAGGCCCGGTCCACGGAATACTGGGTGCAACAGCTGCGCCGGCCGGTCCGGTTCAGCGACGCCGCCACAAGCCTGCAGTCGTACACCGCCTCTCAAGGCATCGCCCTGCTGGAACTCGGCCCCGGCAGGACGCTCGCCTCCCTGTTCTCCCAGCAATGCAGCGCTGACCATTTCGCGACCCCGTCCCTGGGCCTCGTCGAGGACGAGGCGTACGTGGCCTCCTGGCTGGCCCTGGGCGCGCTCTGGTGCGCCGGCTACCCCTTGCCGGTCGAGGACTGGTGGAGCGAGGACGCACACCAACGGGTCCGGCTGCCCACCTACCCCTTCCGCAGGGACCGGCACTGGCTCGAGCCCGTGTCGGCGCCGGCGCCGCGGGACGCGGACGACGCGCCGGAGGAAGCCGCCGAGCCGGTCGTGCAGGACATCAAGACCCAGGTCACGACGGTGTTCCGTGACGTCACCGGATTCGAACTGATCGCCAGCGACAGCGGCAAGACCTTCACGGACCTTGGCCTCGATTCCCTGCTGCTCACCCAGGTGGCGGTCGCCCTCCAGCAGACCTTCGGGGTCGTGCTGACCATCAAGGACCTTAGCCAGACCCTGGACACCATCGACAAGGTGTCGGCGCGGGTGGAGAGCCAGGCCCCGGATGCTGCCGACGCCAGGAAACCGGCCCCCGCGGCCCGCAGTGGCTCCGGCCAGGACGGCACGCCCATCCGCTCGTCCCTGCCCCGGCGCGCGCCGAAACGGAAAAAGAAGGGCCACCACCGGCGCGACACGCGCCCCACCAGTTTCAGCGCCTGGTCCGAACTGGGCGAACAGCGCACGCGGGCCATCCGGGATTTCATCGAAGTCCACGTCGCGAAAACCGCCGGTTCCAAGGCGCACACCGCCCGGTACCGACCCGCCCATGCCGACCCAAGGACCGCCGCGGGCTTCAACCGCGTGTGGAAGGAGATGGTCTATCCACTGGTCTGCACCCGCAGCCAGGGCTCGGAGATCTGGGACATCGATGGCAATCGTTACATCGACATGCTGAGCGGCTTCGGGCCCAATCTGCTCGGGCACGCCGAACCGGACATCAACGCGGCCATCAGGGAACAGCTCGACGCCGGCATCGAGATCGGTCCCCAGTCGAACCTGGCCGGCGAAACGGCCGACCTCGTGTGCCAGCTCACCGGCATGGATCGTGCGAGCTTCATGTGCACAGGCTCCGAAGCCGTCCAGGCGGCCATTCGCTGCGCCCGGACCTACACGCGGCGTTCGAAGATCGTGATCTTCGAAGGGTCCTATCACGGCAATTTCGACGAGGTACTGACGCGCTCGGCCAACGCCCCGGGCCTGCTCAGGACCGTGCCGGGCTCGCCGGGCATTCCCGCGACCAGCGTGGCCGAGGTGGTCGTCCTGCCCTGGAACAGTGACGCCAGTCTCGAGGTCCTCGACGAGATCGGGGATGCGGTGGCTGCCGTGCTGCTCGAGCCCGTGCAGAGCCGCACCCCTGACATCCGGCCGGCGGCCTTCCTGAAGTCCATCCGCGAGATCACGCGCCGCCATGGCACCGTCCTGATCTTCGACGAGGTGGTCACCGGCTTCCGCTGCCATCCGGGCGGGGCCCAGGCCTGGTTCGGTATCGAGGCCGACCTCGCCACTTACGGCAAGGTGGCGGGCGGCAACATGCCCATCGGCATCGTCGCCGGACGCAGAGACATCATGAACACCTTCGACGGGGGCGACTGGAATTACGGCGACGACTCCGGGCCGGACGCCGGCGTGACCTTTTTCGCGGGCACCTTCGTGCGCCACCCCCTGGCGATCGCCGCCTGCCGCACCATGCTCGGAAAGCTGCGGAAGGCCGGCCCCGAGCTGCAGAAGGACCTCACCGAACGCACCGAGCGATTCGCCGCCCGGGTCAATGCGATCTTCCGGCGCTACGAGGCGCCGTTCGAACTCGCGCATTTCACCTCGGTGATGTACCTGCGCAACAGCGACGTCAGCGCGCTGGGGTCACTGTTCTGGTATGCGCTGCGACAGAACGGCGTGTTCGCCCTGGAAGGCTTTCCTTCCTACATGACGCTGGCGCACACCGAGGCGCATCTCGAGGAGGTGGTCGAAGCCATCGAGAACAGCCTGGCCTGGATGGTCGAATCAGGCCTCCTGGTGGAACCCCGACAGCTCAACCCCGACGCTGTGTCGGCCCCGGCCGTTCCGCTGCAGGCGCCGGACGAGACCGCCCGCCTGGGCGAGGACCCGGAAGGCCACCCGGGCTGGTTCCGGGCGGCCGACGGCGCCTGGGTCGATACCGTGTCCGGCAAGGTCGTGGCCGCCGACCCGTGGACGACGAAACTCGCGCGGATCTTCCCCGCCAGCGAGTCCCAGCAGGAAATCTGGTCGTCGGCGCAACTGGGCGACGACGCTTCCTGCGCCTTCAACGATTCGGTCAGTGTCGCGATGCCGGCGGACCTGGATGTCGGCCTGCTGCAAAAGGCGATCGACGACATCGCGATGCGCCACGAGGCCCTGCGCGCCTGCGTGTCGCCCGACGGCGCCCTGGTCAAGGTCACGGCGGAGTCGCACATCGCCCTGCGCACCAGCGACGAGCCGTTGGGGCAGATCATCGAGACGGACGTGCGCACGCCGTTCGACCTCGTCAGGGGCCCCCTCTTCCGATTCACCCTGGCCGGCCGGGGCGGCGACCGCCCGACCCTGGTGGTGACCTGTCACCACATCGTCTGCGACGGCTGGTCCATCCAATTGTTGATCAAGGAACTGGTCCGGCTGTACCGCTCGCATTGCGAAGGCGGAGAGGCCACCCTACCCCCGGCCGACAACCTGGGCGACTACAACCGGGACGCGTCCGACCTCGCCGACACCGAGGCCGAGGACTACTGGCTCGACGAGTACCACACGATTCCGCCGGTGCTGGACTTCCCGGCGGACCGTCCACGACCGAAAATGCGGACCTTCGAGTCGAAGCTCGTCGAATTGCGGGTGGACCGCGCGCGCCTGGACCGGCTGAGGGCCCTGGCCACGTCCCGCAACGCCAGCCTCTTCAACGTGCTGCTCGCCGGCTGGTTCGCTTTCACGGCGCGACTGACGGGCAACCACGACCTCGTCGTGGGCATCCCGACGGCCGGCCAGGTGGTTTCCGGCATGCCGAACCTGGTCGGGCACTGCGTGAACCTGTTGCCCTTGCGTGTGCAGGTCGACGTCAACGACCCCTTCGAGCGCCTGGTGGGGAACGTCCAGGAAAAACTGACCGACGGCCTCGAGCACCAGGGCTACACCTTCGGGCGCCTCATCAAACGCCTGCCCATCGCCCGGGATCCCAGCCGGCTGCCCATCGTCTCCGTGCAGTTCAACCTCGACCCGCCGGCGGATGCCTCCGATTTCGACTTCGGCTCGGCCAGCCCGGGACTCACGACCAATCCGCGGGCCTTCGAGAACTTCGAACTGTTCGTCAACATCGCCGAGGACCAGGACGGCCTCCTCGTTCACCTGCAGTACAACAGCAACCTGTTCGAAGAGGCCTCGATCCGCAACCGCATGGCGGAATACTTCACCCTGCTGGACGCCGCCTGCGAGGCGCCGCAGGCACGGACCGCGGAACTCGAGCTGCTGACGCAGGCGGACCGCGACCGGCTCCTGCAAGTGGCGACGGGTCCGGACGGACTGGACCATGGCCGCCATTTCCTCGATCTGTTCCGGGCGCAGGTCACAGACACCCCGGACGCCGTCGCCGTTGTCGGCGAAGACGGGCGACTGACCTACCGCGAACTGGACGACCATTCCTCGAAACGCGCCGCCCGGCTGGCCGCCCTGGTTGCGGATTCCGCGGAGGCCCTGATCGGGGTCGCCCTGCCCCGCAATGCGGACATGCTGGTCTCCCTGCTGGCCATCTGGAAGCTCGGCGCCGCCTACGTGCCCCTCGACCCCGAGTTCCCGGCGGATCGACTGCAGTTCATGATGGAGGACGCCGGCCTGTCCGCGCTGATCACGAGCCGCGCGACGCAGCCGGGCGCCGGCCCGGAGCTGCCCACCCTGTTCGTGGACGACGCGGCCGGCGTCGACGAAGCGGCGGCGCCGGTCGGGCGCCATTCCGCCGACCAGCGCGCTTACGTGATCTACACCTCCGGGTCCACGGGCCGCCCCAAGGGCGTGGACATCCCCCACCGGGCCTTCAGCAATTTCCTGCAGAGCATGTGTCTCCTGCCGGGACTGGACGCGGACAGCCGCTTGGTGGCCGTCACCACGTTGTCCTTCGATATCGCGGGGCTGGAACTGTTCGGCCCGCTCCTTGCCGGCGGTACGACCATCATCGCCAGCCACGGGCAGTCCCAGGAAGGCCGTGCGCTGGTGCGCCTGCTGGAGGACGCCGATGCCAACGTCATGCAGGCGACACCCGTCACCTGGCGAATGCTGCTGGAAGCGGGCTGGTCCTGCCCCGAGGGCTTCAAGGTGCTGTGTGGCGGCGAGGCCTTCCCCGGCGACCTGGCCACGGAGCTGTTGAAGGCCACGAGCCGCGTCTACAACCTGTACGGACCCACGGAAGCCACGGTCTGGTCCACCGTCCATCCACTCGACGCCGAATCATGGCCGGCCGCCCCCGAGGCGACCGTGCCCATCGGAGCGCCCATCCATGGCACGCAGGTGTACGTGCTCGACCGGCAGCTGAACGTCCTGCCCGCCGGGGTGCCGGGCGAACTCTTCATCGGCGGCGTCGGACTGGCCTCGGGATATCTCGGGCGCGACGAACTCACCCGTGAACGGTTCATCGAACACCGGCAGTTCGGGCTCCTGTACCGCACCGGCGACGTCGTCACGCTCGGCGCGGATGGCGCGCTGCGCTTCCGCGAGCGCATCGATACCCAGGTCAAGGTCCGGGGCTTCCGCATCGAACTGGGCGAGATCGAGGCCGCGCTCGCCGCGGTCCCCGGGGTCACCGAGGCCGTCGCCACGGTGTACGAGCCGGCGCCGGGCGACACCCGCCTGGCCGCCTACTACGTGTCATCGACGGGCGAGATCGACGAGAACGAGCTGCGCGAGCAGCTCCAGGGCCGGTTGCCCCGCTACATGCTCCCGCAGCACTTCGTCGCCATGGAAGCGCTGCCGTTGACGCCGAACCGAAAGGTCGACCGGAAAGCCCTGCCGAAACCGGTGTCGCCGAGGGCTGCGGTCGTCGCTCCCAGGAACGATACCGAGGCGCTGGTCGCCGGTCTCTGGCGGGAACTGCTGCATGTCGAGGACGTCGGCGTCGAGGATGACTTCTTCAATCTGGGCGGCCACTCCATCCTGGCCACCAGGATGATCTCCCTGCTCGAAGACCGCTCCGGCCTGCGCGTACCGCTGCGAACCCTGTTCGCCCATTCGGTGCTGGCGGACTTCGCGGGACATGCGGCGGCGGCCGGACTGGTCCAGGACAACGTGGCGGACGAATCCAGGGAAAGAGAGGTCCTGGAATTTTGA",
    "translation": "MTPDQLAEFIDDEVCVAARNAPEACVLSGPSERLEAIAETLRARDLRVAMLKTSHAFHSSMMDGALEAFTAVVDGVARHAPRIPIISTCTGQLLSDEEARSTEYWVQQLRRPVRFSDAATSLQSYTASQGIALLELGPGRTLASLFSQQCSADHFATPSLGLVEDEAYVASWLALGALWCAGYPLPVEDWWSEDAHQRVRLPTYPFRRDRHWLEPVSAPAPRDADDAPEEAAEPVVQDIKTQVTTVFRDVTGFELIASDSGKTFTDLGLDSLLLTQVAVALQQTFGVVLTIKDLSQTLDTIDKVSARVESQAPDAADARKPAPAARSGSGQDGTPIRSSLPRRAPKRKKKGHHRRDTRPTSFSAWSELGEQRTRAIRDFIEVHVAKTAGSKAHTARYRPAHADPRTAAGFNRVWKEMVYPLVCTRSQGSEIWDIDGNRYIDMLSGFGPNLLGHAEPDINAAIREQLDAGIEIGPQSNLAGETADLVCQLTGMDRASFMCTGSEAVQAAIRCARTYTRRSKIVIFEGSYHGNFDEVLTRSANAPGLLRTVPGSPGIPATSVAEVVVLPWNSDASLEVLDEIGDAVAAVLLEPVQSRTPDIRPAAFLKSIREITRRHGTVLIFDEVVTGFRCHPGGAQAWFGIEADLATYGKVAGGNMPIGIVAGRRDIMNTFDGGDWNYGDDSGPDAGVTFFAGTFVRHPLAIAACRTMLGKLRKAGPELQKDLTERTERFAARVNAIFRRYEAPFELAHFTSVMYLRNSDVSALGSLFWYALRQNGVFALEGFPSYMTLAHTEAHLEEVVEAIENSLAWMVESGLLVEPRQLNPDAVSAPAVPLQAPDETARLGEDPEGHPGWFRAADGAWVDTVSGKVVAADPWTTKLARIFPASESQQEIWSSAQLGDDASCAFNDSVSVAMPADLDVGLLQKAIDDIAMRHEALRACVSPDGALVKVTAESHIALRTSDEPLGQIIETDVRTPFDLVRGPLFRFTLAGRGGDRPTLVVTCHHIVCDGWSIQLLIKELVRLYRSHCEGGEATLPPADNLGDYNRDASDLADTEAEDYWLDEYHTIPPVLDFPADRPRPKMRTFESKLVELRVDRARLDRLRALATSRNASLFNVLLAGWFAFTARLTGNHDLVVGIPTAGQVVSGMPNLVGHCVNLLPLRVQVDVNDPFERLVGNVQEKLTDGLEHQGYTFGRLIKRLPIARDPSRLPIVSVQFNLDPPADASDFDFGSASPGLTTNPRAFENFELFVNIAEDQDGLLVHLQYNSNLFEEASIRNRMAEYFTLLDAACEAPQARTAELELLTQADRDRLLQVATGPDGLDHGRHFLDLFRAQVTDTPDAVAVVGEDGRLTYRELDDHSSKRAARLAALVADSAEALIGVALPRNADMLVSLLAIWKLGAAYVPLDPEFPADRLQFMMEDAGLSALITSRATQPGAGPELPTLFVDDAAGVDEAAAPVGRHSADQRAYVIYTSGSTGRPKGVDIPHRAFSNFLQSMCLLPGLDADSRLVAVTTLSFDIAGLELFGPLLAGGTTIIASHGQSQEGRALVRLLEDADANVMQATPVTWRMLLEAGWSCPEGFKVLCGGEAFPGDLATELLKATSRVYNLYGPTEATVWSTVHPLDAESWPAAPEATVPIGAPIHGTQVYVLDRQLNVLPAGVPGELFIGGVGLASGYLGRDELTRERFIEHRQFGLLYRTGDVVTLGADGALRFRERIDTQVKVRGFRIELGEIEAALAAVPGVTEAVATVYEPAPGDTRLAAYYVSSTGEIDENELREQLQGRLPRYMLPQHFVAMEALPLTPNRKVDRKALPKPVSPRAAVVAPRNDTEALVAGLWRELLHVEDVGVEDDFFNLGGHSILATRMISLLEDRSGLRVPLRTLFAHSVLADFAGHAAAAGLVQDNVADESREREVLEF",
    "product": ""
   },
   {
    "start": 5752,
    "end": 7326,
    "strand": 1,
    "locus_tag": "ctg374_2",
    "type": "biosynthetic-additional",
    "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg374_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg374_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,752 - 7,326,\n (total: 1575 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Condensation<br>\n \n  biosynthetic-additional (smcogs) SMCOG1127:condensation domain-containing protein (Score: 279.2; E-value: 1.2e-84)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"ctg374_2\">NCBI BlastP on this gene</a><br>\n <span class=\"asdb-linkout link-like wildcard-container\" data-locus=\"ctg374_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Blast against antiSMASH-database</span><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg374_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!translation!@\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy wildcard-container\" data-locus=\"ctg374_2\" data-wildcard-attrs=\"data-seq\" data-seq=\"@!dna!@\">Copy to clipboard</span><br>\n</div>",
    "dna": "TTGACCGTCGTCGATCTGCTGGAGACGCTTCGGCGTCTCAAGGTCAGTGTCCGCGCCAATGGCGACAAGCTGGTCATCGACGCACCCGCCGGGGTGATCGATGAGACGCTCGCCGGGAACATCCGTGCGAACAAGTACCAACTGCTCGAACTCATCCGTTCGGCAGGCCAGGGCGAGGACAGCAGCAAGGTCGAACTGGCCCGTGCACCGGACGAGGACCGGCTCTCACTGACGCAGGAGCGGGTCTGGGCGATCCATCAACTGGACCCGGAGAGCAGCCAGTTCAATCTGCCCGGGGCCTGGTGGCTCGACGGCCCACTGGACACCGGGGCCCTTCGCCAGGCCATCGCGGCGTTCGAGTCCCACCATGAGATCTTCCGGCGACGGTTCGTCTCGAAGGACGGAAGCCCGAGGGTTTCGCCCCCCGAACACGACGGCGTTGCGTTCAGCATGACGACGCTCGGTGAGATCGGGCTCGAAGCCGAAGACACCCACCGCCTGGCGCGGTGGTTCGAGGACATTTCAGCTTCGCCGTTCGACCTGGCCGCCGACGCCTTGCTCCGTGTCGTGCTGCTGCGTGTGAGCGAGACCCGTCACCTGCTCTCGGTCATCAGCCACTCCATCGTCTGGGATGCCTGGTGCTACGACATCTTCCTGGCGGAACTCGGCCGGAACTACGAGGCCCTGCTGGCCGGCGAGCCGCTCGCCGGACCGGACCACCAGTATTCCGACTTCGTGCACTGGCAACGCGCCGACCAGGATCGGCGGGCCGCCCGCGAAGCCCTTCAAGCCGCCATCGACCGTCTCGAAGGCCACCGGCAAAGACTCGTGCTGCCCAGGACCCGGCAGTCGGTCGACCCCCGGGAGCACTCGGGCGCCCGGTTCAATTTCGACATTCCGGTGGAGCTGCGTGAAGCCTTGCGCGCCTTCTGCCGGCAACAGGGCGTCACGCCCTTCATGGTCTTCCTGTCGTCCTACGCCTATCTCCTGTGCCGCTACGCCGGCAAGGGAAGCGCGCTCATCACCGTGCCCCTGCGGGGACGCGAACGACCCGAGTTCGAAACCATCCCCGGACCGTTCACGAAGAACCTGTTTCTCCCGGTCGAGGTGGAAGACCGGTCGTTCGCGAGTCTGCTCGCATCCGTCAAGCAGGAAACCGGGCAGGCCTTCGGGGGCGAGGTCCCGAGCTTCGAACGGCTGATCGAAGCCATCAACCAGAACCTGGCCGACTCCGCGTTCTTTCAGCTGCAGTTCTCCTACCAGAATGTCGAGAATCGGGGCACCGAGTGGGCCAGGGGCATCCGGATGTCGGCCGGACCGGCCCACGACTCGGACCACGTCCATGCCGAGATCAGTTTCTGGATGCGGGAGGGCAGGAACAGCATGGACGGGGCGATCGACTACCGGACGTCCCTGTTCGACGAGGCGTTCATCGCACGGTTCTACGAGCGACTGCTGGCGGTGATCCGGGCCGGAATCGCAACGCCCGATGCAGCCCTGCTCGACCTGGACATCGAAGCACCCGGCGCCACGACCGACGCCCCGACGCCGCCGACACGCATCGACACCCTGTCC",
    "translation": "MTVVDLLETLRRLKVSVRANGDKLVIDAPAGVIDETLAGNIRANKYQLLELIRSAGQGEDSSKVELARAPDEDRLSLTQERVWAIHQLDPESSQFNLPGAWWLDGPLDTGALRQAIAAFESHHEIFRRRFVSKDGSPRVSPPEHDGVAFSMTTLGEIGLEAEDTHRLARWFEDISASPFDLAADALLRVVLLRVSETRHLLSVISHSIVWDAWCYDIFLAELGRNYEALLAGEPLAGPDHQYSDFVHWQRADQDRRAAREALQAAIDRLEGHRQRLVLPRTRQSVDPREHSGARFNFDIPVELREALRAFCRQQGVTPFMVFLSSYAYLLCRYAGKGSALITVPLRGRERPEFETIPGPFTKNLFLPVEVEDRSFASLLASVKQETGQAFGGEVPSFERLIEAINQNLADSAFFQLQFSYQNVENRGTEWARGIRMSAGPAHDSDHVHAEISFWMREGRNSMDGAIDYRTSLFDEAFIARFYERLLAVIRAGIATPDAALLDLDIEAPGATTDAPTPPTRIDTLS",
    "product": ""
   }
  ],
  "clusters": [
   {
    "start": 1,
    "end": 5755,
    "tool": "rule-based-clusters",
    "neighbouring_start": 0,
    "neighbouring_end": 7328,
    "product": "NRPS",
    "category": "NRPS",
    "height": 2,
    "kind": "protocluster",
    "prefix": ""
   }
  ],
  "sites": {
   "ttaCodons": [],
   "bindingSites": []
  },
  "type": "NRPS",
  "products": [
   "NRPS"
  ],
  "product_categories": [
   "NRPS"
  ],
  "cssClass": "NRPS NRPS",
  "anchor": "r374c1"
 }
};
var details_data = {
 "nrpspks": {
  "r170c1": {
   "id": "r170c1",
   "orfs": [
    {
     "id": "ctg170_3",
     "sequence": "MNRRVVVTGAAGLTGLGADWPTIRAGLEAGRSAVRYFPEWEEIRGLNCKLGAPAADFELPEHYTRKRTRTMGRNALMAVRATELAVEQAGLAGHEVLGSGRTGVSYGSSSGSTDALAEMAHVRVSDNARKVNATSYVRLMGHTAAANIGMFFGLRGRVIPTISACTAGSQGIGYAWEAIRHGLQDVMLAGGSEELCPSHVAVFDVLYATSTSNDRPEHTPRPFDADRNGLVVGEGAATLVLESLDHARDRNAPILAELTGFATNSDGNHVTRPDRDSMARVMRMALERADRAPADIGYVNAHGTATEAGDVAESLATEQVFGSDTPVASLKGYLGHTLGACGAIEAWLSMEMMQAGWFAPNHNLERPDPDCGRLDYLMGEARALGVRAVMSNNFAFGGINTSLVFERFEG",
     "domains": [
      {
       "type": "PKS_KS(Iterative-KS)",
       "start": 76,
       "end": 408,
       "predictions": [],
       "napdoslink": "https://npdomainseeker.sdsc.edu/cgi-bin/process_request_napdos2.cgi?query_type=aa&amp;ref_seq_file=all_KS_191020_1877.faa&amp;Sequence=%3Eall_KS_191020_1877.faa_domain_from_antiSMASH%0D@!sequence!@",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "MAVRATELAVEQAGLAGHEVLGSGRTGVSYGSSSGSTDALAEMAHVRVSDNARKVNATSYVRLMGHTAAANIGMFFGLRGRVIPTISACTAGSQGIGYAWEAIRHGLQDVMLAGGSEELCPSHVAVFDVLYATSTSNDRPEHTPRPFDADRNGLVVGEGAATLVLESLDHARDRNAPILAELTGFATNSDGNHVTRPDRDSMARVMRMALERADRAPADIGYVNAHGTATEAGDVAESLATEQVFGSDTPVASLKGYLGHTLGACGAIEAWLSMEMMQAGWFAPNHNLERPDPDCGRLDYLMGEARALGVRAVMSNNFAFGGINTSLVFERF",
       "dna_sequence": "ATGGCGGTGCGGGCCACGGAGCTGGCGGTGGAACAGGCGGGCCTGGCCGGCCACGAGGTACTGGGCTCGGGCCGGACCGGCGTGTCCTACGGCTCATCCTCCGGCAGCACCGACGCGCTGGCCGAAATGGCCCACGTCCGGGTCTCGGACAACGCCCGCAAGGTCAACGCCACCAGCTACGTGCGCCTGATGGGCCACACGGCCGCAGCCAACATCGGCATGTTCTTCGGCCTGCGTGGCCGGGTGATCCCCACCATCAGCGCCTGCACGGCGGGCAGCCAGGGCATCGGCTATGCCTGGGAAGCCATCCGCCACGGGCTGCAGGACGTGATGCTGGCCGGCGGCAGCGAAGAACTGTGTCCCTCCCACGTGGCCGTGTTCGACGTCCTGTACGCCACCAGCACCTCGAACGACCGGCCGGAGCACACGCCGCGCCCCTTCGACGCGGACCGGAACGGGCTGGTGGTGGGCGAGGGCGCGGCGACACTGGTGCTGGAGTCGCTGGACCACGCCCGGGACAGAAACGCGCCGATTCTCGCCGAACTGACGGGATTTGCGACGAACTCTGATGGAAATCACGTGACACGTCCCGATCGCGATTCCATGGCGCGGGTCATGCGCATGGCGCTGGAGCGCGCGGACCGGGCGCCGGCGGACATCGGCTACGTGAACGCCCACGGCACCGCCACGGAAGCCGGGGACGTGGCCGAAAGCCTGGCCACGGAGCAGGTGTTCGGCAGCGACACGCCCGTGGCCTCGCTCAAGGGCTACCTGGGCCACACGCTCGGCGCCTGCGGCGCCATCGAGGCCTGGCTGAGCATGGAAATGATGCAAGCGGGATGGTTCGCGCCCAACCACAACCTGGAACGGCCGGATCCGGACTGCGGCCGGCTGGATTACCTGATGGGCGAGGCGCGCGCGTTGGGCGTGCGCGCGGTGATGAGCAACAACTTCGCCTTCGGCGGGATCAACACCTCCCTGGTGTTCGAGCGGTTC",
       "abbreviation": "KS",
       "html_class": "jsdomain-ketosynthase"
      }
     ],
     "modules": []
    },
    {
     "id": "ctg170_4",
     "sequence": "MSESRPSVLVTGSSRGIGRAIALDLAAHGYDPVVHCRGSREAAEGVAAEARQAGAGARVLQFDVCDRAATRAALEADVAEHGAYYGVVLNSGIARDGAFPMLGEEDWDAVLRTNLDGFYNVLHPLVMPLVRARRPARIVTLSSVSGVVGNRGQVNYSASKAGIIGATKALATELASRNITVNCVAPGLVDTDMMEAIPEDLRERMIEHIPLGRAARPEEVAAVVRFLLSPEASYVTRQVIGVNGGMA",
     "domains": [
      {
       "type": "PKS_KR",
       "start": 6,
       "end": 161,
       "predictions": [
        [
         "KR activity",
         "inactive"
        ],
        [
         "KR stereochemistry",
         "C2"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "SVLVTGSSRGIGRAIALDLAAHGYDPVVHCRGSREAAEGVAAEARQAGAGARVLQFDVCDRAATRAALEADVAEHGAYYGVVLNSGIARDGAFPMLGEEDWDAVLRTNLDGFYNVLHPLVMPLVRARRPARIVTLSSVSGVVGNRGQVNYSASKA",
       "dna_sequence": "TCCGTCCTCGTCACCGGCTCCAGCCGCGGCATCGGCCGAGCGATCGCGCTCGACCTCGCCGCGCACGGCTACGACCCGGTGGTTCATTGCCGCGGCAGCCGTGAAGCGGCCGAGGGCGTGGCCGCCGAAGCCCGGCAGGCCGGGGCGGGAGCCCGCGTGCTGCAGTTCGACGTCTGCGACCGGGCGGCGACCCGCGCGGCGCTGGAAGCGGACGTTGCCGAACACGGCGCGTACTACGGGGTCGTGCTGAACTCGGGCATCGCGCGCGACGGCGCGTTCCCCATGCTGGGCGAGGAAGACTGGGACGCGGTACTGCGCACCAACCTGGACGGCTTCTACAACGTGCTCCATCCCCTGGTCATGCCGCTGGTGCGGGCGCGCCGGCCGGCGCGCATCGTCACCCTGTCCTCGGTCTCCGGCGTGGTCGGCAATCGCGGGCAGGTGAACTACAGCGCTTCCAAGGCC",
       "abbreviation": "KR",
       "html_class": "jsdomain-mod-kr"
      }
     ],
     "modules": []
    },
    {
     "id": "ctg170_7",
     "sequence": "MAEARPANPTEPSAPPVIDRVHDGDTAQWRLRVGGDCPWLEGHFPERPVLPGVVLLRWAIQAAVDTWPELDTVTGVSNLKFRNPVLPPAEVVLHLAFDASRRHIDFRYARDGKDCAQGRVRFA",
     "domains": [
      {
       "type": "PKS_DH",
       "start": 20,
       "end": 105,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "VHDGDTAQWRLRVGGDCPWLEGHFPERPVLPGVVLLRWAIQAAVDTWPELDTVTGVSNLKFRNPVLPPAEVVLHLAFDASRRHID",
       "dna_sequence": "GTGCACGACGGCGACACGGCGCAGTGGCGTCTCCGGGTCGGCGGCGACTGCCCGTGGCTCGAAGGCCATTTTCCCGAACGTCCCGTCCTGCCCGGCGTGGTGCTGCTGCGCTGGGCCATCCAGGCCGCGGTTGACACCTGGCCCGAACTGGACACCGTCACGGGCGTGAGCAATCTCAAGTTCCGCAACCCGGTTCTGCCGCCGGCCGAGGTGGTCCTTCACCTGGCGTTCGACGCCTCCCGGCGCCACATCGAT",
       "abbreviation": "DH",
       "html_class": "jsdomain-mod-dh"
      }
     ],
     "modules": []
    },
    {
     "id": "ctg170_8",
     "sequence": "MNTDIDSYQYVRNLLVDQFDVPADAIRPEALLADDLGIDSIDAVDMIVHMREVTGERITPERFRQVRTVQDVVDIVDRVLA",
     "domains": [
      {
       "type": "PP-binding",
       "start": 8,
       "end": 74,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "QYVRNLLVDQFDVPADAIRPEALLADDLGIDSIDAVDMIVHMREVTGERITPERFRQVRTVQDVVD",
       "dna_sequence": "CAGTACGTTCGAAACCTGCTCGTCGACCAGTTCGACGTGCCGGCGGACGCCATTCGCCCGGAGGCCCTGCTGGCCGACGACCTGGGCATCGACAGCATCGACGCCGTGGACATGATCGTGCACATGCGCGAAGTGACCGGCGAGCGCATCACGCCCGAACGCTTCCGGCAGGTGCGCACCGTGCAGGACGTGGTGGAC",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      }
     ],
     "modules": []
    }
   ]
  },
  "r272c1": {
   "id": "r272c1",
   "orfs": [
    {
     "id": "ctg272_2",
     "sequence": "MKGAPLGLPKGEAVTHDHDICGGDSGHLGAVRDVVARFEHIVAHHADAIAVIEATPDSTRSDPSYSYARLNERRLEIAGALVEQHGLGPGDWVGLVQSRRFDTLAAMLGIATIGASYVPLDAEWPEERRRYLLSDAKVRVLLTAGRSAPSGALPLSECRGSARSFEGAAPDTPLYVMYTSGSTGEPKGVVVPHRAVVRLVVGTDFMPLDPHTRFLHAAPQSFDAATLEIWGPLLNGGTCVLHPEGIFDPAGLDPLADKHDINALWLTAALFNQWVQLRPRGLEGAATVLFGGERASVPHVRQAAALWPRTTLVNGYGPTENTTFTCCHTVRPQDLDEQATELPIGKAITGTAVWIVNGALEDVPAGTVGELVTGGEGLALEYLGRPELTSERFVTDAGGERWYRTGDLARQDDDGVIHFHGRADRQLKLHGHRIEPGEIEAALLADPRLHHAHVLAVETPEGDQKLAAYLVGEFDRTELQNRLAGALPRFMVPSVYVCISELPTTANGKVDVGALPYPFHGKDPAPANGGGNDMARLVAATWRNVVSGIDLKGNDDNFFDVGGTSMDMIRVKQALEKQLATEIPLVSLFQYPTVSKLASHLDALAQPESAAATATDRAARRRQQLARRKAGRVRT",
     "domains": [
      {
       "type": "AMP-binding",
       "start": 37,
       "end": 429,
       "predictions": [
        [
         "substrate consensus",
         "Val"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "FEHIVAHHADAIAVIEATPDSTRSDPSYSYARLNERRLEIAGALVEQHGLGPGDWVGLVQSRRFDTLAAMLGIATIGASYVPLDAEWPEERRRYLLSDAKVRVLLTAGRSAPSGALPLSECRGSARSFEGAAPDTPLYVMYTSGSTGEPKGVVVPHRAVVRLVVGTDFMPLDPHTRFLHAAPQSFDAATLEIWGPLLNGGTCVLHPEGIFDPAGLDPLADKHDINALWLTAALFNQWVQLRPRGLEGAATVLFGGERASVPHVRQAAALWPRTTLVNGYGPTENTTFTCCHTVRPQDLDEQATELPIGKAITGTAVWIVNGALEDVPAGTVGELVTGGEGLALEYLGRPELTSERFVTDAGGERWYRTGDLARQDDDGVIHFHGRADRQLKL",
       "dna_sequence": "TTCGAACACATCGTCGCGCACCACGCGGATGCCATTGCCGTCATCGAAGCAACACCGGATTCCACCCGTTCGGACCCGAGTTACAGCTATGCCAGGCTGAATGAGCGGCGCCTGGAAATTGCCGGCGCCCTCGTCGAACAACACGGACTGGGACCCGGCGACTGGGTCGGCCTGGTGCAATCCCGCCGCTTCGACACCCTGGCGGCCATGCTGGGGATTGCCACGATCGGCGCGAGCTATGTTCCACTGGATGCCGAGTGGCCGGAAGAGCGCCGTCGATACCTCCTGTCGGATGCCAAGGTGCGGGTGCTCCTGACGGCGGGACGCTCCGCGCCGTCCGGCGCCCTGCCCCTTTCGGAGTGCCGCGGATCGGCCCGTTCATTCGAGGGCGCAGCCCCGGACACGCCGCTCTACGTCATGTACACCTCCGGCTCGACCGGGGAACCCAAGGGCGTCGTGGTGCCGCACCGGGCCGTGGTCCGGCTCGTGGTCGGGACCGATTTCATGCCCCTGGACCCGCACACCCGGTTCCTGCACGCCGCGCCCCAGTCCTTCGACGCGGCGACCCTGGAAATCTGGGGACCGCTGCTTAACGGCGGAACCTGCGTGCTGCACCCGGAGGGCATTTTCGACCCCGCCGGCCTGGACCCCCTGGCTGACAAGCACGACATCAACGCCCTGTGGCTGACGGCCGCACTGTTCAACCAATGGGTCCAGTTACGCCCAAGGGGGCTCGAAGGCGCGGCCACCGTGCTGTTCGGCGGCGAAAGAGCCTCCGTTCCGCACGTACGCCAGGCCGCCGCGCTCTGGCCCCGGACCACGCTGGTCAACGGCTACGGTCCGACCGAGAACACGACCTTCACCTGCTGTCACACGGTCCGCCCGCAGGACCTCGACGAACAGGCCACGGAACTCCCCATCGGAAAGGCCATTACGGGCACGGCGGTGTGGATCGTGAACGGCGCCTTGGAAGACGTTCCCGCCGGCACGGTCGGCGAACTGGTGACCGGCGGCGAGGGCCTGGCGCTGGAATACCTGGGCCGCCCTGAATTGACATCCGAACGCTTCGTCACCGACGCCGGGGGCGAGCGCTGGTACCGGACGGGCGACCTCGCCAGGCAGGACGACGACGGCGTCATCCATTTTCACGGCCGGGCCGACCGCCAGTTGAAGCTG",
       "abbreviation": "A",
       "html_class": "jsdomain-adenylation"
      },
      {
       "type": "PP-binding",
       "start": 552,
       "end": 601,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "GNDDNFFDVGGTSMDMIRVKQALEKQLATEIPLVSLFQYPTVSKLASHL",
       "dna_sequence": "GGCAACGACGACAACTTTTTTGACGTGGGGGGCACGTCGATGGACATGATCCGGGTCAAGCAGGCCCTGGAAAAGCAGTTGGCTACGGAGATTCCGCTGGTCAGCCTGTTCCAGTACCCCACGGTTTCGAAGCTGGCGTCTCATCTC",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      }
     ],
     "modules": [
      {
       "start": 37,
       "end": 601,
       "complete": true,
       "iterative": false,
       "monomer": "Val",
       "multi_cds": null,
       "match_id": null
      }
     ]
    },
    {
     "id": "ctg272_3",
     "sequence": "MNQQALPENAVAIVGIACRYPGAQDLEAFWRNLREGRESITFFSADEIDASIPDAIKSQPNYVRAKGRLDDVDRFDAKFFDIPPVEASLMDPQQRLLLELSWAALEDAGIVPGEGDNLVGVWVGTNWNRYYARHVRGSAAEQRYGEFNAQLANEFDFPASRIAYKLNLTGPAITLATACSTSLVAIGQAMQSLLNFECNAALAGGASISVPLNAGYLHHEGEMLSADGHCRPFDAHSSGTTFNDGAAVIALKRLEDAVADGDDIYAVIRGVGINNDGADKVSYTAPSVNGQIDALSAALAIADVDPASVGLIETHGTATRLGDPIEVAAIRTVYGADPSAGPCALGALKSNIGHAIHAAGIAGVIKAALAVRDGVIPPTINFETPNPDLQLEGSRFYVNSEAVAWPDATPRRAGVSSFGVGGTNAHALVEQPPAATKAPRAPSADTPPLLLLSARDTETCMRQAMNLSDQARTQPDMPDLADVGYTLARSRKRFDTRAALFATGIEELAAFDEQSTRIVRGKARPLDTLVWAFPGQGAQRAGMGAALEGRSDAYREALSRAIEQLNPHLDLDLRQLLQRDGELPGDAAERISETKYAQPALFAVGYALAAHYRAAGLEPDLLVGHSIGEFAAACIAGVFSLEDAALLVCERGRLMQAQPRGA",
     "domains": [
      {
       "type": "PKS_KS(Hybrid-KS)",
       "start": 10,
       "end": 432,
       "predictions": [],
       "napdoslink": "https://npdomainseeker.sdsc.edu/cgi-bin/process_request_napdos2.cgi?query_type=aa&amp;ref_seq_file=all_KS_191020_1877.faa&amp;Sequence=%3Eall_KS_191020_1877.faa_domain_from_antiSMASH%0D@!sequence!@",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "VAIVGIACRYPGAQDLEAFWRNLREGRESITFFSADEIDASIPDAIKSQPNYVRAKGRLDDVDRFDAKFFDIPPVEASLMDPQQRLLLELSWAALEDAGIVPGEGDNLVGVWVGTNWNRYYARHVRGSAAEQRYGEFNAQLANEFDFPASRIAYKLNLTGPAITLATACSTSLVAIGQAMQSLLNFECNAALAGGASISVPLNAGYLHHEGEMLSADGHCRPFDAHSSGTTFNDGAAVIALKRLEDAVADGDDIYAVIRGVGINNDGADKVSYTAPSVNGQIDALSAALAIADVDPASVGLIETHGTATRLGDPIEVAAIRTVYGADPSAGPCALGALKSNIGHAIHAAGIAGVIKAALAVRDGVIPPTINFETPNPDLQLEGSRFYVNSEAVAWPDATPRRAGVSSFGVGGTNAHALVEQP",
       "dna_sequence": "GTCGCAATCGTCGGCATCGCCTGCCGTTATCCCGGGGCCCAGGATCTCGAGGCCTTCTGGCGGAACCTGCGCGAGGGGCGCGAGTCGATCACCTTCTTTTCCGCGGACGAGATCGACGCGAGTATTCCCGACGCGATCAAGTCCCAGCCCAATTACGTCCGGGCCAAGGGGCGGCTGGACGATGTCGACCGGTTCGATGCGAAGTTTTTCGACATCCCGCCCGTCGAAGCCAGCCTCATGGATCCACAGCAGCGCCTGCTGCTCGAACTGTCCTGGGCGGCCCTCGAGGACGCGGGCATCGTTCCCGGCGAGGGCGACAACCTGGTCGGCGTCTGGGTCGGCACCAACTGGAACCGGTACTACGCCCGGCACGTGCGCGGCAGCGCGGCCGAGCAGCGCTACGGTGAATTCAACGCCCAGTTGGCGAACGAGTTCGACTTCCCCGCCTCCAGAATCGCCTACAAGTTGAACCTGACCGGACCGGCGATCACGCTGGCCACCGCCTGCTCGACCTCGCTGGTCGCCATCGGCCAGGCCATGCAGTCGTTGCTCAACTTCGAGTGCAATGCCGCGCTGGCCGGCGGCGCCAGCATCTCGGTACCCCTGAACGCCGGTTACCTGCACCACGAGGGCGAGATGCTGTCCGCCGACGGGCATTGCCGGCCCTTCGACGCGCACTCCAGCGGCACGACCTTCAATGACGGCGCCGCGGTCATCGCGCTCAAGCGCCTCGAGGACGCCGTCGCCGACGGCGACGACATCTACGCGGTGATCCGGGGCGTCGGCATCAACAACGACGGCGCCGACAAGGTCAGTTACACCGCCCCCAGCGTCAATGGACAGATCGACGCCCTGAGCGCCGCCCTGGCCATCGCGGATGTGGATCCCGCCTCGGTCGGCCTGATCGAGACGCACGGTACGGCGACCCGTCTCGGAGACCCGATCGAAGTCGCGGCCATCCGCACGGTGTACGGCGCCGACCCTTCTGCGGGGCCGTGTGCGCTCGGCGCCCTGAAAAGCAACATCGGCCATGCCATCCACGCCGCGGGCATCGCCGGCGTGATCAAGGCCGCGCTGGCGGTCCGCGACGGCGTCATTCCGCCGACCATCAACTTCGAGACGCCCAATCCGGACCTGCAACTCGAGGGCAGCCGCTTCTACGTCAACTCCGAGGCCGTGGCCTGGCCTGACGCCACGCCCCGCCGCGCCGGCGTGAGCTCCTTCGGGGTCGGTGGAACCAATGCCCACGCCCTGGTCGAGCAACCC",
       "abbreviation": "KS",
       "html_class": "jsdomain-ketosynthase"
      }
     ],
     "modules": []
    }
   ]
  },
  "r313c1": {
   "id": "r313c1",
   "orfs": [
    {
     "id": "ctg313_2",
     "sequence": "MSDAELAWLSAASKAEPGWIALRGSETPLDVEWLFQDEGQPVQSRTSRVEIPEIVNLEAGVTVVLLALLRLSGDQRGLVALLDATLEDFPLVESFRPVLASLREDESVASFTERMGARIAAAGRKGPLLRDQGLRSTRDLGSTPCVAVSAGAALAAGRGFDLWVHVDVGEAGASIETRFERATSARKVAQFEQALRGVARDVSTRSTRPAAAIDIVAETDRAQVLDQWNPPPTASKEECIHHAFLRVASEQGAAPAVLCDGRVLSFAELAQQAQSVARHLQGLEVGPDDRVGICLERNEALLIAVLGVLASGAAYVPLDPEYPAARLRHIVADAEPALTLVSEDTRHRLEGTTAPLLSWDEALAADSGADLRDEASPRNLAYVIYTSGSTGAPKGVMVEHRNAANFFTAMDERVTLGAGPRWLSVTSLSFDISVLELLWTLTRGVGIVLYTGADRTGAVSAIAPKPRANDTPIDFSLFYFASDEGERHDGRGANGRGPADKYRLLVEGAKFADANGFVAVWTPERHFHAFGGLYPNPSVVSAALATITEHVQLRAGSCVLPLHDPIRIAEEWALVDNLSNGRVGISFASGWQPNDFVLAPDRYENRHEVMAEGIETVRALWRGDSVRRTNPLGKEVELATLPRPVQEELPFWVTAAGNPATFQAAGRQGANLLTHLLGQDQEELAGKIEAYRSAWREAGHPGEGIVTLMLHTFVGDDEEAVKAAVHEPLKAYLRSSVGLIRKFADTFPAFRNRGGDGGTIDFDALAPEDMEALLEFAFERYYRDSGLFGAPERCARMVDSLKGIGVNEIACLVDFGVPSEQVLEHLPDIAEVMRRSKPRSELPAGSVAALIQAHGATHLQCTPSQAQMLLADPDNHPAVAGLRGWLVGGEALPEELARRLRTVARGTVINMYGPTETTIWSTTWALPEDPGPVLIGTPIANTRCYVLDDALRLRPPGAPGELFIGGQGVTRGYLGKEALTASRFLEDPFGDPGDRMYRTGDRVRWVDGELEFLGRMDDQVKVRGYRIELGDIESALAAFDGPQQVVAAIKTDAAGDPAIVAYALMPPGTGLDEVALRRHLNRTLPPYMVPQVFIEIDEVPLTPNGKVDRRALPDLDAGRRGRRGAFVPPSTETEKALAAIWGEVLSVAQVGSQDTFFELGGDSLAAVRVAVRIREVIGERLPLETLLRATLAQSARSLDGARAGERPGAGPATREPADATGRKSGLLHRLTRRKPRA",
     "domains": [
      {
       "type": "A-OX",
       "start": 264,
       "end": 1045,
       "predictions": [
        [
         "substrate consensus",
         "X"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "SFAELAQQAQSVARHLQGLEVGPDDRVGICLERNEALLIAVLGVLASGAAYVPLDPEYPAARLRHIVADAEPALTLVSEDTRHRLEGTTAPLLSWDEALAADSGADLRDEASPRNLAYVIYTSGSTGAPKGVMVEHRNAANFFTAMDERVTLGAGPRWLSVTSLSFDISVLELLWTLTRGVGIVLYTGADRTGAVSAIAPKPRANDTPIDFSLFYFASDEGERHDGRGANGRGPADKYRLLVEGAKFADANGFVAVWTPERHFHAFGGLYPNPSVVSAALATITEHVQLRAGSCVLPLHDPIRIAEEWALVDNLSNGRVGISFASGWQPNDFVLAPDRYENRHEVMAEGIETVRALWRGDSVRRTNPLGKEVELATLPRPVQEELPFWVTAAGNPATFQAAGRQGANLLTHLLGQDQEELAGKIEAYRSAWREAGHPGEGIVTLMLHTFVGDDEEAVKAAVHEPLKAYLRSSVGLIRKFADTFPAFRNRGGDGGTIDFDALAPEDMEALLEFAFERYYRDSGLFGAPERCARMVDSLKGIGVNEIACLVDFGVPSEQVLEHLPDIAEVMRRSKPRSELPAGSVAALIQAHGATHLQCTPSQAQMLLADPDNHPAVAGLRGWLVGGEALPEELARRLRTVARGTVINMYGPTETTIWSTTWALPEDPGPVLIGTPIANTRCYVLDDALRLRPPGAPGELFIGGQGVTRGYLGKEALTASRFLEDPFGDPGDRMYRTGDRVRWVDGELEFLGRMDDQVKVRGYRIELGDIESALAAFDGPQQV",
       "dna_sequence": "TCCTTTGCCGAACTGGCGCAACAGGCGCAGTCGGTGGCCCGGCACCTGCAGGGCCTCGAGGTCGGCCCCGACGACCGGGTCGGCATCTGCCTGGAGCGCAACGAGGCACTGCTCATCGCCGTCCTGGGCGTGTTGGCGTCCGGGGCCGCCTACGTTCCGCTGGACCCCGAATACCCGGCCGCCCGGCTCCGGCACATCGTGGCGGACGCCGAGCCGGCGTTGACGCTGGTGAGCGAGGACACCCGGCACCGGCTGGAAGGCACGACCGCGCCCCTGCTGTCATGGGACGAGGCCCTCGCGGCCGACTCGGGCGCCGACCTTCGAGACGAGGCCAGCCCTCGGAACCTGGCCTACGTCATCTACACCTCCGGGTCCACGGGGGCACCGAAGGGCGTGATGGTCGAGCACCGCAACGCCGCGAATTTCTTCACCGCGATGGACGAGCGGGTGACCCTGGGCGCCGGGCCGCGATGGTTGTCCGTCACCAGTCTTTCCTTCGACATCTCGGTGCTGGAACTGTTGTGGACCCTGACGCGCGGCGTGGGCATCGTCCTCTACACGGGCGCAGACCGGACGGGCGCCGTGTCCGCCATCGCCCCGAAGCCGCGCGCCAACGACACGCCCATCGACTTCAGCCTGTTCTACTTCGCCAGCGACGAGGGGGAACGTCATGACGGCAGGGGTGCAAACGGCAGGGGCCCGGCCGACAAGTACCGGCTCCTCGTGGAAGGTGCGAAGTTCGCCGACGCGAACGGCTTCGTGGCCGTCTGGACCCCGGAACGACATTTCCACGCCTTCGGCGGCCTCTATCCGAACCCCTCGGTGGTGAGCGCCGCACTGGCGACCATCACGGAGCATGTCCAGCTTCGTGCGGGGAGCTGCGTGCTGCCCCTGCATGACCCGATCCGGATCGCCGAGGAGTGGGCGCTGGTCGACAACCTGTCCAACGGCCGGGTCGGCATCTCCTTCGCTTCCGGCTGGCAGCCCAACGATTTCGTGCTCGCGCCGGACCGTTACGAAAACCGGCACGAGGTCATGGCCGAAGGTATCGAGACCGTCCGCGCCCTGTGGCGCGGTGACAGCGTGCGGCGGACCAATCCGCTCGGCAAGGAGGTGGAACTGGCCACCTTGCCGCGACCGGTGCAGGAAGAGTTGCCGTTCTGGGTGACCGCCGCGGGCAACCCGGCCACTTTCCAGGCGGCAGGCCGGCAGGGTGCGAACCTGCTGACGCACCTGCTGGGTCAGGACCAGGAGGAACTGGCCGGGAAGATCGAGGCCTACCGCTCGGCCTGGCGGGAGGCGGGCCATCCGGGCGAAGGAATCGTGACACTCATGCTGCATACCTTCGTCGGAGACGACGAGGAGGCGGTCAAGGCCGCGGTGCACGAGCCGCTGAAGGCGTACCTCCGCAGCTCCGTCGGCCTCATCCGCAAGTTCGCCGACACCTTTCCCGCCTTCAGGAATCGCGGCGGTGATGGCGGGACGATCGACTTCGACGCGCTCGCCCCGGAGGACATGGAGGCGCTGCTCGAATTCGCCTTCGAGCGGTACTACCGGGACAGCGGCCTGTTCGGCGCCCCGGAGCGCTGCGCCCGGATGGTCGATTCGCTGAAGGGCATCGGCGTGAACGAGATCGCCTGCCTGGTCGATTTCGGCGTGCCCTCCGAACAGGTGCTCGAACACCTGCCGGACATCGCGGAGGTCATGCGACGGTCGAAACCCCGGTCCGAGCTTCCGGCGGGATCGGTGGCGGCCTTGATCCAGGCCCACGGCGCCACGCACCTGCAATGCACCCCCTCGCAGGCGCAGATGCTGCTGGCCGACCCGGACAACCACCCCGCAGTGGCCGGCCTGCGGGGCTGGCTGGTGGGCGGCGAGGCGCTGCCGGAAGAACTCGCCAGGCGCCTCCGAACCGTGGCGCGGGGGACGGTGATCAACATGTACGGCCCCACGGAAACCACGATCTGGTCCACGACGTGGGCCCTGCCAGAGGATCCCGGCCCGGTGCTGATCGGCACGCCCATCGCCAACACCCGCTGCTACGTGCTCGACGATGCCCTCCGGCTTCGGCCGCCGGGCGCGCCCGGCGAACTGTTCATCGGCGGCCAGGGCGTGACCCGTGGGTATCTCGGCAAGGAGGCATTGACGGCGTCCCGCTTCCTGGAGGACCCCTTCGGTGATCCGGGCGACCGCATGTACCGGACCGGCGACCGCGTGCGCTGGGTCGACGGGGAGCTGGAGTTCCTCGGCCGTATGGACGACCAGGTCAAGGTGCGCGGCTACCGGATCGAACTGGGCGACATCGAGTCGGCACTCGCCGCCTTCGACGGCCCCCAGCAGGTG",
       "abbreviation": "A-OX",
       "html_class": "jsdomain-adenylation"
      },
      {
       "type": "PCP",
       "start": 1133,
       "end": 1198,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "EKALAAIWGEVLSVAQVGSQDTFFELGGDSLAAVRVAVRIREVIGERLPLETLLRATLAQSARSL",
       "dna_sequence": "GAGAAGGCCCTTGCGGCCATCTGGGGCGAGGTGCTCTCGGTGGCGCAGGTGGGCTCGCAGGACACCTTCTTCGAACTGGGCGGGGATTCCCTGGCGGCCGTCCGGGTCGCGGTTCGCATCCGCGAGGTGATCGGCGAGCGGCTGCCCCTGGAAACCCTCCTTCGCGCGACGCTGGCCCAATCGGCGAGGTCCCTG",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      }
     ],
     "modules": [
      {
       "start": 264,
       "end": 1198,
       "complete": true,
       "iterative": false,
       "monomer": "?",
       "multi_cds": null,
       "match_id": null
      }
     ]
    }
   ]
  },
  "r314c1": {
   "id": "r314c1",
   "orfs": [
    {
     "id": "ctg314_16",
     "sequence": "MSPAKDTLGGLLSAAIARGPRSVTFIEGAQEEVRVSYDDLRARALGVLRHFQAAGLEPGDELILFTNSNEQFVDAFWACILGGIVPVPVAVGISDDHRAKLLRIFASLRNPWLYTERNLARRLERFGEGHDRLAEIARLLERTLVVDDIEDIGTPGRVHAAAPDDVAFIQFSSGSTSEPKGVVLTHRNVITNIRAICEGYGSRDDDVAVSWMPLTHDMGLIGFHLCMIAANNDHHVMATSLFVRRPLLWMQKAAEKGATLTCSPNFGYKHFLKVFESKGLDGIDLGRVRLVFNGAEPISAALARQFLEALAPHGLDPDCMFPVYGLAEASLGVTFPEPGAPLRTVMAHRHGLAVGEPWSPAEGDDQDAVEFVLLGTPIRDCQVRLCDDQDHVLEEGRVGHVQIRGGNVTRGYYGYRGRSRDVFADLDWLRTGDLGFFHEGQLVITGRSKDIIFVNGQNYYPHDIEALAGELDGLELGKVVAAGVTSPEAGTDELLLFVLDRGEVATFADLARRLRAHVGETTGLEVGQVIPVTRIPKTTSGKVQRHKLTEAYLDGEYAPVLAELAALETVTEEDPVPAGGMEQALAQICNSIVVDRPVGLDDNLFEIGISSLALAQIHARVDELYPGEMDIADVFEYPTIRELAAFLEARRAGGA",
     "domains": [
      {
       "type": "CAL_domain",
       "start": 35,
       "end": 478,
       "predictions": [
        [
         "Minowa",
         "fatty_acid"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "SYDDLRARALGVLRHFQAAGLEPGDELILFTNSNEQFVDAFWACILGGIVPVPVAVGISDDHRAKLLRIFASLRNPWLYTERNLARRLERFGEGHDRLAEIARLLERTLVVDDIEDIGTPGRVHAAAPDDVAFIQFSSGSTSEPKGVVLTHRNVITNIRAICEGYGSRDDDVAVSWMPLTHDMGLIGFHLCMIAANNDHHVMATSLFVRRPLLWMQKAAEKGATLTCSPNFGYKHFLKVFESKGLDGIDLGRVRLVFNGAEPISAALARQFLEALAPHGLDPDCMFPVYGLAEASLGVTFPEPGAPLRTVMAHRHGLAVGEPWSPAEGDDQDAVEFVLLGTPIRDCQVRLCDDQDHVLEEGRVGHVQIRGGNVTRGYYGYRGRSRDVFADLDWLRTGDLGFFHEGQLVITGRSKDIIFVNGQNYYPHDIEALAGELDGLELGK",
       "dna_sequence": "TCCTACGACGACCTCCGCGCCCGCGCCCTGGGCGTGCTGCGTCACTTCCAGGCCGCCGGCCTGGAGCCGGGCGACGAACTGATCCTGTTCACCAACAGCAACGAGCAGTTCGTCGACGCCTTCTGGGCCTGCATCCTCGGCGGTATCGTGCCGGTACCCGTGGCCGTGGGCATCAGCGACGACCACCGCGCCAAGCTGCTGCGGATCTTCGCCTCGCTGCGCAATCCCTGGCTGTACACGGAGCGCAACCTCGCACGGCGCCTGGAGCGCTTCGGGGAAGGTCATGACCGCCTGGCCGAGATTGCCCGCCTGCTCGAGCGAACCCTGGTGGTGGACGACATCGAGGACATCGGCACCCCTGGCCGGGTGCATGCCGCGGCGCCGGACGACGTGGCCTTCATCCAGTTTTCCTCCGGCTCCACCAGCGAGCCCAAGGGCGTGGTGCTGACCCACCGCAACGTGATCACCAACATCCGCGCCATCTGCGAGGGTTACGGCAGCCGCGACGACGACGTCGCCGTCAGCTGGATGCCGCTGACCCACGACATGGGCCTGATCGGTTTCCACCTGTGCATGATCGCGGCCAACAACGACCACCACGTCATGGCCACGAGCCTGTTCGTCCGGCGTCCCCTGTTGTGGATGCAGAAGGCGGCTGAGAAGGGTGCGACCCTGACGTGCTCGCCCAACTTCGGCTACAAGCACTTCCTCAAGGTGTTCGAGTCGAAGGGATTGGACGGCATCGACCTGGGCCGCGTGCGCCTGGTGTTCAACGGGGCCGAGCCCATCTCCGCCGCGCTCGCGCGGCAGTTCCTGGAAGCGCTCGCACCCCACGGCCTGGACCCGGACTGCATGTTTCCGGTCTACGGTCTCGCCGAGGCCAGCCTGGGCGTGACCTTCCCCGAGCCCGGGGCGCCCCTGCGCACCGTGATGGCCCATCGCCACGGCCTGGCCGTCGGGGAACCCTGGTCGCCCGCCGAAGGCGACGACCAGGATGCCGTGGAGTTCGTCCTGCTCGGCACGCCGATCCGCGACTGCCAGGTCCGGCTCTGCGACGACCAGGACCACGTCCTGGAGGAAGGGCGGGTCGGCCACGTGCAGATCCGCGGCGGCAACGTCACGCGGGGCTATTACGGCTACCGCGGCAGGAGCCGGGATGTGTTCGCCGACCTCGACTGGCTGCGGACCGGCGACCTGGGCTTCTTCCACGAAGGCCAGCTGGTGATCACCGGTCGCTCCAAGGACATCATTTTCGTCAACGGCCAGAACTACTACCCCCACGACATCGAGGCCCTGGCGGGGGAGCTCGACGGGCTGGAACTGGGCAAG",
       "abbreviation": "CAL",
       "html_class": "jsdomain-other"
      },
      {
       "type": "PCP",
       "start": 581,
       "end": 650,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "EQALAQICNSIVVDRPVGLDDNLFEIGISSLALAQIHARVDELYPGEMDIADVFEYPTIRELAAFLEAR",
       "dna_sequence": "GAGCAGGCTCTGGCGCAGATCTGCAACAGCATCGTGGTCGACCGCCCGGTCGGCCTGGACGACAACCTGTTCGAGATCGGCATCAGCTCGCTGGCCCTGGCGCAGATCCACGCCCGCGTGGACGAGCTGTACCCCGGTGAAATGGACATTGCCGACGTGTTCGAGTACCCGACCATCCGCGAGCTGGCCGCCTTCCTGGAAGCGCGG",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      }
     ],
     "modules": [
      {
       "start": 35,
       "end": 650,
       "complete": false,
       "iterative": false,
       "monomer": "",
       "multi_cds": null,
       "match_id": null
      }
     ]
    }
   ]
  },
  "r374c1": {
   "id": "r374c1",
   "orfs": [
    {
     "id": "ctg374_1",
     "sequence": "MTPDQLAEFIDDEVCVAARNAPEACVLSGPSERLEAIAETLRARDLRVAMLKTSHAFHSSMMDGALEAFTAVVDGVARHAPRIPIISTCTGQLLSDEEARSTEYWVQQLRRPVRFSDAATSLQSYTASQGIALLELGPGRTLASLFSQQCSADHFATPSLGLVEDEAYVASWLALGALWCAGYPLPVEDWWSEDAHQRVRLPTYPFRRDRHWLEPVSAPAPRDADDAPEEAAEPVVQDIKTQVTTVFRDVTGFELIASDSGKTFTDLGLDSLLLTQVAVALQQTFGVVLTIKDLSQTLDTIDKVSARVESQAPDAADARKPAPAARSGSGQDGTPIRSSLPRRAPKRKKKGHHRRDTRPTSFSAWSELGEQRTRAIRDFIEVHVAKTAGSKAHTARYRPAHADPRTAAGFNRVWKEMVYPLVCTRSQGSEIWDIDGNRYIDMLSGFGPNLLGHAEPDINAAIREQLDAGIEIGPQSNLAGETADLVCQLTGMDRASFMCTGSEAVQAAIRCARTYTRRSKIVIFEGSYHGNFDEVLTRSANAPGLLRTVPGSPGIPATSVAEVVVLPWNSDASLEVLDEIGDAVAAVLLEPVQSRTPDIRPAAFLKSIREITRRHGTVLIFDEVVTGFRCHPGGAQAWFGIEADLATYGKVAGGNMPIGIVAGRRDIMNTFDGGDWNYGDDSGPDAGVTFFAGTFVRHPLAIAACRTMLGKLRKAGPELQKDLTERTERFAARVNAIFRRYEAPFELAHFTSVMYLRNSDVSALGSLFWYALRQNGVFALEGFPSYMTLAHTEAHLEEVVEAIENSLAWMVESGLLVEPRQLNPDAVSAPAVPLQAPDETARLGEDPEGHPGWFRAADGAWVDTVSGKVVAADPWTTKLARIFPASESQQEIWSSAQLGDDASCAFNDSVSVAMPADLDVGLLQKAIDDIAMRHEALRACVSPDGALVKVTAESHIALRTSDEPLGQIIETDVRTPFDLVRGPLFRFTLAGRGGDRPTLVVTCHHIVCDGWSIQLLIKELVRLYRSHCEGGEATLPPADNLGDYNRDASDLADTEAEDYWLDEYHTIPPVLDFPADRPRPKMRTFESKLVELRVDRARLDRLRALATSRNASLFNVLLAGWFAFTARLTGNHDLVVGIPTAGQVVSGMPNLVGHCVNLLPLRVQVDVNDPFERLVGNVQEKLTDGLEHQGYTFGRLIKRLPIARDPSRLPIVSVQFNLDPPADASDFDFGSASPGLTTNPRAFENFELFVNIAEDQDGLLVHLQYNSNLFEEASIRNRMAEYFTLLDAACEAPQARTAELELLTQADRDRLLQVATGPDGLDHGRHFLDLFRAQVTDTPDAVAVVGEDGRLTYRELDDHSSKRAARLAALVADSAEALIGVALPRNADMLVSLLAIWKLGAAYVPLDPEFPADRLQFMMEDAGLSALITSRATQPGAGPELPTLFVDDAAGVDEAAAPVGRHSADQRAYVIYTSGSTGRPKGVDIPHRAFSNFLQSMCLLPGLDADSRLVAVTTLSFDIAGLELFGPLLAGGTTIIASHGQSQEGRALVRLLEDADANVMQATPVTWRMLLEAGWSCPEGFKVLCGGEAFPGDLATELLKATSRVYNLYGPTEATVWSTVHPLDAESWPAAPEATVPIGAPIHGTQVYVLDRQLNVLPAGVPGELFIGGVGLASGYLGRDELTRERFIEHRQFGLLYRTGDVVTLGADGALRFRERIDTQVKVRGFRIELGEIEAALAAVPGVTEAVATVYEPAPGDTRLAAYYVSSTGEIDENELREQLQGRLPRYMLPQHFVAMEALPLTPNRKVDRKALPKPVSPRAAVVAPRNDTEALVAGLWRELLHVEDVGVEDDFFNLGGHSILATRMISLLEDRSGLRVPLRTLFAHSVLADFAGHAAAAGLVQDNVADESREREVLEF",
     "domains": [
      {
       "type": "PKS_AT",
       "start": 2,
       "end": 156,
       "predictions": [
        [
         "substrate consensus",
         "mal"
        ],
        [
         "PKS signature",
         "(unknown)"
        ],
        [
         "Minowa",
         "mal"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "PDQLAEFIDDEVCVAARNAPEACVLSGPSERLEAIAETLRARDLRVAMLKTSHAFHSSMMDGALEAFTAVVDGVARHAPRIPIISTCTGQLLSDEEARSTEYWVQQLRRPVRFSDAATSLQSYTASQGIALLELGPGRTLASLFSQQCSADHFA",
       "dna_sequence": "CCCGACCAGCTGGCCGAGTTCATCGACGACGAAGTCTGCGTCGCGGCCCGGAATGCGCCGGAGGCCTGCGTGCTGTCCGGACCGTCGGAACGACTGGAAGCGATCGCGGAAACGCTCCGGGCCCGGGACCTGCGCGTGGCCATGCTCAAGACTTCCCACGCCTTCCATTCGAGCATGATGGATGGCGCCCTGGAAGCATTCACCGCGGTCGTCGACGGCGTCGCGCGGCACGCGCCCCGGATACCGATCATCTCGACCTGCACCGGCCAGTTGCTCAGCGACGAGGAGGCCCGGTCCACGGAATACTGGGTGCAACAGCTGCGCCGGCCGGTCCGGTTCAGCGACGCCGCCACAAGCCTGCAGTCGTACACCGCCTCTCAAGGCATCGCCCTGCTGGAACTCGGCCCCGGCAGGACGCTCGCCTCCCTGTTCTCCCAGCAATGCAGCGCTGACCATTTCGCG",
       "abbreviation": "AT",
       "html_class": "jsdomain-acyltransferase"
      },
      {
       "type": "PP-binding",
       "start": 241,
       "end": 308,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "QVTTVFRDVTGFELIASDSGKTFTDLGLDSLLLTQVAVALQQTFGVVLTIKDLSQTLDTIDKVSARV",
       "dna_sequence": "CAGGTCACGACGGTGTTCCGTGACGTCACCGGATTCGAACTGATCGCCAGCGACAGCGGCAAGACCTTCACGGACCTTGGCCTCGATTCCCTGCTGCTCACCCAGGTGGCGGTCGCCCTCCAGCAGACCTTCGGGGTCGTGCTGACCATCAAGGACCTTAGCCAGACCCTGGACACCATCGACAAGGTGTCGGCGCGGGTG",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      },
      {
       "type": "Aminotran_3",
       "start": 422,
       "end": 742,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "CTRSQGSEIWDIDGNRYIDMLSGFGPNLLGHAEPDINAAIREQLDAGIEIGPQSNLAGETADLVCQLTGMDRASFMCTGSEAVQAAIRCARTYTRRSKIVIFEGSYHGNFDEVLTRSANAPGLLRTVPGSPGIPATSVAEVVVLPWNSDASLEVLDEIGDAVAAVLLEPVQSRTPDIRPAAFLKSIREITRRHGTVLIFDEVVTGFRCHPGGAQAWFGIEADLATYGKVAGGNMPIGIVAGRRDIMNTFDGGDWNYGDDSGPDAGVTFFAGTFVRHPLAIAACRTMLGKLRKAGPELQKDLTERTERFAARVNAIFRRYE",
       "dna_sequence": "TGCACCCGCAGCCAGGGCTCGGAGATCTGGGACATCGATGGCAATCGTTACATCGACATGCTGAGCGGCTTCGGGCCCAATCTGCTCGGGCACGCCGAACCGGACATCAACGCGGCCATCAGGGAACAGCTCGACGCCGGCATCGAGATCGGTCCCCAGTCGAACCTGGCCGGCGAAACGGCCGACCTCGTGTGCCAGCTCACCGGCATGGATCGTGCGAGCTTCATGTGCACAGGCTCCGAAGCCGTCCAGGCGGCCATTCGCTGCGCCCGGACCTACACGCGGCGTTCGAAGATCGTGATCTTCGAAGGGTCCTATCACGGCAATTTCGACGAGGTACTGACGCGCTCGGCCAACGCCCCGGGCCTGCTCAGGACCGTGCCGGGCTCGCCGGGCATTCCCGCGACCAGCGTGGCCGAGGTGGTCGTCCTGCCCTGGAACAGTGACGCCAGTCTCGAGGTCCTCGACGAGATCGGGGATGCGGTGGCTGCCGTGCTGCTCGAGCCCGTGCAGAGCCGCACCCCTGACATCCGGCCGGCGGCCTTCCTGAAGTCCATCCGCGAGATCACGCGCCGCCATGGCACCGTCCTGATCTTCGACGAGGTGGTCACCGGCTTCCGCTGCCATCCGGGCGGGGCCCAGGCCTGGTTCGGTATCGAGGCCGACCTCGCCACTTACGGCAAGGTGGCGGGCGGCAACATGCCCATCGGCATCGTCGCCGGACGCAGAGACATCATGAACACCTTCGACGGGGGCGACTGGAATTACGGCGACGACTCCGGGCCGGACGCCGGCGTGACCTTTTTCGCGGGCACCTTCGTGCGCCACCCCCTGGCGATCGCCGCCTGCCGCACCATGCTCGGAAAGCTGCGGAAGGCCGGCCCCGAGCTGCAGAAGGACCTCACCGAACGCACCGAGCGATTCGCCGCCCGGGTCAATGCGATCTTCCGGCGCTACGAG",
       "abbreviation": "AmT",
       "html_class": "jsdomain-other"
      },
      {
       "type": "Condensation_LCL",
       "start": 882,
       "end": 1166,
       "predictions": [],
       "napdoslink": "https://npdomainseeker.sdsc.edu/cgi-bin/process_request_napdos2.cgi?query_type=aa&amp;ref_seq_file=all_C_190411_273.faa&amp;Sequence=%3Eall_C_190411_273.faa_domain_from_antiSMASH%0D@!sequence!@",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "FPASESQQEIWSSAQLGDDASCAFNDSVSVAMPADLDVGLLQKAIDDIAMRHEALRACVSPDGALVKVTAESHIALRTSDEPLGQIIETDVRTPFDLVRGPLFRFTLAGRGGDRPTLVVTCHHIVCDGWSIQLLIKELVRLYRSHCEGGEATLPPADNLGDYNRDASDLADTEAEDYWLDEYHTIPPVLDFPADRPRPKMRTFESKLVELRVDRARLDRLRALATSRNASLFNVLLAGWFAFTARLTGNHDLVVGIPTAGQVVSGMPNLVGHCVNLLPLRVQVD",
       "dna_sequence": "TTCCCCGCCAGCGAGTCCCAGCAGGAAATCTGGTCGTCGGCGCAACTGGGCGACGACGCTTCCTGCGCCTTCAACGATTCGGTCAGTGTCGCGATGCCGGCGGACCTGGATGTCGGCCTGCTGCAAAAGGCGATCGACGACATCGCGATGCGCCACGAGGCCCTGCGCGCCTGCGTGTCGCCCGACGGCGCCCTGGTCAAGGTCACGGCGGAGTCGCACATCGCCCTGCGCACCAGCGACGAGCCGTTGGGGCAGATCATCGAGACGGACGTGCGCACGCCGTTCGACCTCGTCAGGGGCCCCCTCTTCCGATTCACCCTGGCCGGCCGGGGCGGCGACCGCCCGACCCTGGTGGTGACCTGTCACCACATCGTCTGCGACGGCTGGTCCATCCAATTGTTGATCAAGGAACTGGTCCGGCTGTACCGCTCGCATTGCGAAGGCGGAGAGGCCACCCTACCCCCGGCCGACAACCTGGGCGACTACAACCGGGACGCGTCCGACCTCGCCGACACCGAGGCCGAGGACTACTGGCTCGACGAGTACCACACGATTCCGCCGGTGCTGGACTTCCCGGCGGACCGTCCACGACCGAAAATGCGGACCTTCGAGTCGAAGCTCGTCGAATTGCGGGTGGACCGCGCGCGCCTGGACCGGCTGAGGGCCCTGGCCACGTCCCGCAACGCCAGCCTCTTCAACGTGCTGCTCGCCGGCTGGTTCGCTTTCACGGCGCGACTGACGGGCAACCACGACCTCGTCGTGGGCATCCCGACGGCCGGCCAGGTGGTTTCCGGCATGCCGAACCTGGTCGGGCACTGCGTGAACCTGTTGCCCTTGCGTGTGCAGGTCGAC",
       "abbreviation": "C",
       "html_class": "jsdomain-condensation"
      },
      {
       "type": "AMP-binding",
       "start": 1330,
       "end": 1724,
       "predictions": [
        [
         "substrate consensus",
         "Gly"
        ]
       ],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "FRAQVTDTPDAVAVVGEDGRLTYRELDDHSSKRAARLAALVADSAEALIGVALPRNADMLVSLLAIWKLGAAYVPLDPEFPADRLQFMMEDAGLSALITSRATQPGAGPELPTLFVDDAAGVDEAAAPVGRHSADQRAYVIYTSGSTGRPKGVDIPHRAFSNFLQSMCLLPGLDADSRLVAVTTLSFDIAGLELFGPLLAGGTTIIASHGQSQEGRALVRLLEDADANVMQATPVTWRMLLEAGWSCPEGFKVLCGGEAFPGDLATELLKATSRVYNLYGPTEATVWSTVHPLDAESWPAAPEATVPIGAPIHGTQVYVLDRQLNVLPAGVPGELFIGGVGLASGYLGRDELTRERFIEHRQFGLLYRTGDVVTLGADGALRFRERIDTQVKVR",
       "dna_sequence": "TTCCGGGCGCAGGTCACAGACACCCCGGACGCCGTCGCCGTTGTCGGCGAAGACGGGCGACTGACCTACCGCGAACTGGACGACCATTCCTCGAAACGCGCCGCCCGGCTGGCCGCCCTGGTTGCGGATTCCGCGGAGGCCCTGATCGGGGTCGCCCTGCCCCGCAATGCGGACATGCTGGTCTCCCTGCTGGCCATCTGGAAGCTCGGCGCCGCCTACGTGCCCCTCGACCCCGAGTTCCCGGCGGATCGACTGCAGTTCATGATGGAGGACGCCGGCCTGTCCGCGCTGATCACGAGCCGCGCGACGCAGCCGGGCGCCGGCCCGGAGCTGCCCACCCTGTTCGTGGACGACGCGGCCGGCGTCGACGAAGCGGCGGCGCCGGTCGGGCGCCATTCCGCCGACCAGCGCGCTTACGTGATCTACACCTCCGGGTCCACGGGCCGCCCCAAGGGCGTGGACATCCCCCACCGGGCCTTCAGCAATTTCCTGCAGAGCATGTGTCTCCTGCCGGGACTGGACGCGGACAGCCGCTTGGTGGCCGTCACCACGTTGTCCTTCGATATCGCGGGGCTGGAACTGTTCGGCCCGCTCCTTGCCGGCGGTACGACCATCATCGCCAGCCACGGGCAGTCCCAGGAAGGCCGTGCGCTGGTGCGCCTGCTGGAGGACGCCGATGCCAACGTCATGCAGGCGACACCCGTCACCTGGCGAATGCTGCTGGAAGCGGGCTGGTCCTGCCCCGAGGGCTTCAAGGTGCTGTGTGGCGGCGAGGCCTTCCCCGGCGACCTGGCCACGGAGCTGTTGAAGGCCACGAGCCGCGTCTACAACCTGTACGGACCCACGGAAGCCACGGTCTGGTCCACCGTCCATCCACTCGACGCCGAATCATGGCCGGCCGCCCCCGAGGCGACCGTGCCCATCGGAGCGCCCATCCATGGCACGCAGGTGTACGTGCTCGACCGGCAGCTGAACGTCCTGCCCGCCGGGGTGCCGGGCGAACTCTTCATCGGCGGCGTCGGACTGGCCTCGGGATATCTCGGGCGCGACGAACTCACCCGTGAACGGTTCATCGAACACCGGCAGTTCGGGCTCCTGTACCGCACCGGCGACGTCGTCACGCTCGGCGCGGATGGCGCGCTGCGCTTCCGCGAGCGCATCGATACCCAGGTCAAGGTCCGG",
       "abbreviation": "A",
       "html_class": "jsdomain-adenylation"
      },
      {
       "type": "PCP",
       "start": 1829,
       "end": 1896,
       "predictions": [],
       "napdoslink": "",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "EALVAGLWRELLHVEDVGVEDDFFNLGGHSILATRMISLLEDRSGLRVPLRTLFAHSVLADFAGHAA",
       "dna_sequence": "GAGGCGCTGGTCGCCGGTCTCTGGCGGGAACTGCTGCATGTCGAGGACGTCGGCGTCGAGGATGACTTCTTCAATCTGGGCGGCCACTCCATCCTGGCCACCAGGATGATCTCCCTGCTCGAAGACCGCTCCGGCCTGCGCGTACCGCTGCGAACCCTGTTCGCCCATTCGGTGCTGGCGGACTTCGCGGGACATGCGGCG",
       "abbreviation": "",
       "html_class": "jsdomain-transport"
      }
     ],
     "modules": [
      {
       "start": 2,
       "end": 742,
       "complete": true,
       "iterative": false,
       "monomer": "mal",
       "multi_cds": null,
       "match_id": null
      },
      {
       "start": 882,
       "end": 1896,
       "complete": true,
       "iterative": false,
       "monomer": "Gly",
       "multi_cds": null,
       "match_id": null
      }
     ]
    },
    {
     "id": "ctg374_2",
     "sequence": "MTVVDLLETLRRLKVSVRANGDKLVIDAPAGVIDETLAGNIRANKYQLLELIRSAGQGEDSSKVELARAPDEDRLSLTQERVWAIHQLDPESSQFNLPGAWWLDGPLDTGALRQAIAAFESHHEIFRRRFVSKDGSPRVSPPEHDGVAFSMTTLGEIGLEAEDTHRLARWFEDISASPFDLAADALLRVVLLRVSETRHLLSVISHSIVWDAWCYDIFLAELGRNYEALLAGEPLAGPDHQYSDFVHWQRADQDRRAAREALQAAIDRLEGHRQRLVLPRTRQSVDPREHSGARFNFDIPVELREALRAFCRQQGVTPFMVFLSSYAYLLCRYAGKGSALITVPLRGRERPEFETIPGPFTKNLFLPVEVEDRSFASLLASVKQETGQAFGGEVPSFERLIEAINQNLADSAFFQLQFSYQNVENRGTEWARGIRMSAGPAHDSDHVHAEISFWMREGRNSMDGAIDYRTSLFDEAFIARFYERLLAVIRAGIATPDAALLDLDIEAPGATTDAPTPPTRIDTLS",
     "domains": [
      {
       "type": "Condensation_LCL",
       "start": 71,
       "end": 370,
       "predictions": [],
       "napdoslink": "https://npdomainseeker.sdsc.edu/cgi-bin/process_request_napdos2.cgi?query_type=aa&amp;ref_seq_file=all_C_190411_273.faa&amp;Sequence=%3Eall_C_190411_273.faa_domain_from_antiSMASH%0D@!sequence!@",
       "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=@!sequence!@&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
       "sequence": "EDRLSLTQERVWAIHQLDPESSQFNLPGAWWLDGPLDTGALRQAIAAFESHHEIFRRRFVSKDGSPRVSPPEHDGVAFSMTTLGEIGLEAEDTHRLARWFEDISASPFDLAADALLRVVLLRVSETRHLLSVISHSIVWDAWCYDIFLAELGRNYEALLAGEPLAGPDHQYSDFVHWQRADQDRRAAREALQAAIDRLEGHRQRLVLPRTRQSVDPREHSGARFNFDIPVELREALRAFCRQQGVTPFMVFLSSYAYLLCRYAGKGSALITVPLRGRERPEFETIPGPFTKNLFLPVEV",
       "dna_sequence": "GAGGACCGGCTCTCACTGACGCAGGAGCGGGTCTGGGCGATCCATCAACTGGACCCGGAGAGCAGCCAGTTCAATCTGCCCGGGGCCTGGTGGCTCGACGGCCCACTGGACACCGGGGCCCTTCGCCAGGCCATCGCGGCGTTCGAGTCCCACCATGAGATCTTCCGGCGACGGTTCGTCTCGAAGGACGGAAGCCCGAGGGTTTCGCCCCCCGAACACGACGGCGTTGCGTTCAGCATGACGACGCTCGGTGAGATCGGGCTCGAAGCCGAAGACACCCACCGCCTGGCGCGGTGGTTCGAGGACATTTCAGCTTCGCCGTTCGACCTGGCCGCCGACGCCTTGCTCCGTGTCGTGCTGCTGCGTGTGAGCGAGACCCGTCACCTGCTCTCGGTCATCAGCCACTCCATCGTCTGGGATGCCTGGTGCTACGACATCTTCCTGGCGGAACTCGGCCGGAACTACGAGGCCCTGCTGGCCGGCGAGCCGCTCGCCGGACCGGACCACCAGTATTCCGACTTCGTGCACTGGCAACGCGCCGACCAGGATCGGCGGGCCGCCCGCGAAGCCCTTCAAGCCGCCATCGACCGTCTCGAAGGCCACCGGCAAAGACTCGTGCTGCCCAGGACCCGGCAGTCGGTCGACCCCCGGGAGCACTCGGGCGCCCGGTTCAATTTCGACATTCCGGTGGAGCTGCGTGAAGCCTTGCGCGCCTTCTGCCGGCAACAGGGCGTCACGCCCTTCATGGTCTTCCTGTCGTCCTACGCCTATCTCCTGTGCCGCTACGCCGGCAAGGGAAGCGCGCTCATCACCGTGCCCCTGCGGGGACGCGAACGACCCGAGTTCGAAACCATCCCCGGACCGTTCACGAAGAACCTGTTTCTCCCGGTCGAGGTG",
       "abbreviation": "C",
       "html_class": "jsdomain-condensation"
      }
     ],
     "modules": []
    }
   ]
  }
 }
};
var resultsData = {
 "r144c1": {
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg144_1": {
     "functions": []
    },
    "ctg144_2": {
     "functions": []
    },
    "ctg144_3": {
     "functions": [
      {
       "description": "PF13471",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg144_4": {
     "functions": [
      {
       "description": "Asn_synthase",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "GATase_7",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1177:asparagine synthase (glutamine-hydrolyzing) ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg144_5": {
     "functions": []
    },
    "ctg144_6": {
     "functions": []
    },
    "ctg144_7": {
     "functions": [
      {
       "description": "NTP_transf_5",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    }
   }
  }
 },
 "r170c1": {
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg170_1": {
     "functions": []
    },
    "ctg170_2": {
     "functions": []
    },
    "ctg170_3": {
     "functions": [
      {
       "description": "APE_KS1",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1022:Beta-ketoacyl synthase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg170_4": {
     "functions": [
      {
       "description": "adh_short",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1001:short-chain dehydrogenase/reductase SDR ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg170_5": {
     "functions": []
    },
    "ctg170_6": {
     "functions": [
      {
       "description": "Glycos_transf_2",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1123:polyprenol-monophosphomannose synthase ppm1 ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg170_7": {
     "functions": []
    },
    "ctg170_8": {
     "functions": [
      {
       "description": "PP-binding",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg170_9": {
     "functions": []
    }
   }
  }
 },
 "r203c1": {
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg203_1": {
     "functions": []
    },
    "ctg203_2": {
     "functions": [
      {
       "description": "DUF692",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg203_3": {
     "functions": []
    },
    "ctg203_4": {
     "functions": []
    },
    "ctg203_5": {
     "functions": []
    },
    "ctg203_6": {
     "functions": []
    },
    "ctg203_7": {
     "functions": []
    }
   }
  }
 },
 "r268c1": {
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg268_1": {
     "functions": [
      {
       "description": "Stand_Alone_Lasso_RRE",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "Lasso_Fused_RRE",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PF05402",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg268_2": {
     "functions": []
    },
    "ctg268_3": {
     "functions": [
      {
       "description": "SMCOG1288:ABC transporter related protein ",
       "function": "transport",
       "tool": "smcogs"
      }
     ]
    }
   }
  }
 },
 "r272c1": {
  "antismash.outputs.html.visualisers.bubble_view": {
   "CC1": {
    "modules": [
     {
      "domains": [
       {
        "name": "A",
        "description": "AMP-binding",
        "modifier": false,
        "special": false,
        "cds": "ctg272_2",
        "css": "jsdomain-adenylation",
        "inactive": false,
        "start": 37,
        "terminalDocking": ""
       },
       {
        "name": "CP",
        "description": "PP-binding",
        "modifier": false,
        "special": false,
        "cds": "ctg272_2",
        "css": "jsdomain-transport",
        "inactive": false,
        "start": 552,
        "terminalDocking": ""
       }
      ],
      "complete": true,
      "iterative": false,
      "polymer": "Val"
     }
    ]
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg272_1": {
     "functions": []
    },
    "ctg272_2": {
     "functions": [
      {
       "description": "PP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "AMP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1002:AMP-dependent synthetase and ligase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg272_3": {
     "functions": [
      {
       "description": "hyb_KS",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PKS_AT",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1093:Beta-ketoacyl synthase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    }
   }
  }
 },
 "r313c1": {
  "antismash.outputs.html.visualisers.bubble_view": {
   "CC1": {
    "modules": [
     {
      "domains": [
       {
        "name": "",
        "description": "A-OX",
        "modifier": false,
        "special": false,
        "cds": "ctg313_2",
        "css": "jsdomain-adenylation",
        "inactive": false,
        "start": 264,
        "terminalDocking": ""
       },
       {
        "name": "CP",
        "description": "PCP",
        "modifier": false,
        "special": false,
        "cds": "ctg313_2",
        "css": "jsdomain-transport",
        "inactive": false,
        "start": 1133,
        "terminalDocking": ""
       }
      ],
      "complete": true,
      "iterative": false,
      "polymer": "X"
     }
    ]
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg313_1": {
     "functions": []
    },
    "ctg313_2": {
     "functions": [
      {
       "description": "PP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "A-OX",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1251:luciferase family protein ",
       "function": "other",
       "tool": "smcogs"
      }
     ]
    }
   }
  }
 },
 "r314c1": {
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg314_1": {
     "functions": []
    },
    "ctg314_2": {
     "functions": []
    },
    "ctg314_3": {
     "functions": []
    },
    "ctg314_4": {
     "functions": []
    },
    "ctg314_5": {
     "functions": []
    },
    "ctg314_6": {
     "functions": []
    },
    "ctg314_7": {
     "functions": []
    },
    "ctg314_8": {
     "functions": []
    },
    "ctg314_9": {
     "functions": []
    },
    "ctg314_10": {
     "functions": []
    },
    "ctg314_11": {
     "functions": []
    },
    "ctg314_12": {
     "functions": []
    },
    "ctg314_13": {
     "functions": []
    },
    "ctg314_14": {
     "functions": []
    },
    "ctg314_15": {
     "functions": [
      {
       "description": "PF00561",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "Peptidase_S9",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      }
     ]
    },
    "ctg314_16": {
     "functions": [
      {
       "description": "PP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "AMP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1002:AMP-dependent synthetase and ligase ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg314_17": {
     "functions": [
      {
       "description": "p450",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1034:cytochrome P450 ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg314_18": {
     "functions": []
    },
    "ctg314_19": {
     "functions": []
    }
   }
  }
 },
 "r374c1": {
  "antismash.outputs.html.visualisers.bubble_view": {
   "CC1": {
    "modules": [
     {
      "domains": [
       {
        "name": "AT",
        "description": "PKS_AT",
        "modifier": false,
        "special": false,
        "cds": "ctg374_1",
        "css": "jsdomain-acyltransferase",
        "inactive": false,
        "start": 2,
        "terminalDocking": ""
       },
       {
        "name": "CP",
        "description": "PP-binding",
        "modifier": false,
        "special": false,
        "cds": "ctg374_1",
        "css": "jsdomain-transport",
        "inactive": false,
        "start": 241,
        "terminalDocking": ""
       },
       {
        "name": "AmT",
        "description": "Aminotran_3",
        "modifier": false,
        "special": false,
        "cds": "ctg374_1",
        "css": "jsdomain-other",
        "inactive": false,
        "start": 422,
        "terminalDocking": ""
       }
      ],
      "complete": true,
      "iterative": false,
      "polymer": "mal"
     },
     {
      "domains": [
       {
        "name": "C",
        "description": "Condensation_LCL",
        "modifier": false,
        "special": false,
        "cds": "ctg374_1",
        "css": "jsdomain-condensation",
        "inactive": false,
        "start": 882,
        "terminalDocking": ""
       },
       {
        "name": "A",
        "description": "AMP-binding",
        "modifier": false,
        "special": false,
        "cds": "ctg374_1",
        "css": "jsdomain-adenylation",
        "inactive": false,
        "start": 1330,
        "terminalDocking": ""
       },
       {
        "name": "CP",
        "description": "PCP",
        "modifier": false,
        "special": false,
        "cds": "ctg374_1",
        "css": "jsdomain-transport",
        "inactive": false,
        "start": 1829,
        "terminalDocking": ""
       }
      ],
      "complete": true,
      "iterative": false,
      "polymer": "Gly"
     }
    ]
   }
  },
  "antismash.outputs.html.visualisers.gene_table": {
   "blast_template": "<a class=\"wildcard-container\" data-wildcard-attrs=\"href\" href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&PROGRAM=blastp&BLAST_PROGRAMS=blastp&QUERY=@!translation!@&LINK_LOC=protein&PAGE_TYPE=BlastSearch\" target=\"_blank\" data-locus=\"@!translation!@\">BlastP</a>",
   "selected_template": "<span class=\"cds-selected-marker cds-selected-marker-@!locus_tag!@\" data-locus=\"@!locus_tag!@\"></span>",
   "orfs": {
    "ctg374_1": {
     "functions": [
      {
       "description": "Condensation",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "AMP-binding",
       "function": "biosynthetic",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PKS_AT",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "Aminotran_3",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "PP-binding",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1013:aminotransferase class-III ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    },
    "ctg374_2": {
     "functions": [
      {
       "description": "Condensation",
       "function": "biosynthetic-additional",
       "tool": "biosynthetic profile"
      },
      {
       "description": "SMCOG1127:condensation domain-containing protein ",
       "function": "biosynthetic-additional",
       "tool": "smcogs"
      }
     ]
    }
   }
  }
 }
};
